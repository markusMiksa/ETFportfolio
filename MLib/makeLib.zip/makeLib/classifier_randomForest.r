#NEU:
#http://www.r-bloggers.com/introducing-parallelrandomforest-faster-leaner-parallelized/

#http://jehrlinger.wordpress.com/tag/randomforestsrc/
  
#install.packages("parallelRandomForest", repos = "c:/Users/markus/Documents/R/win-library/3.0/parallelRandomForest", type="source")


if(F)
{
  library("parallelRandomForest")
  
  'http://www.thertrader.com/2013/09/24/working-with-intraday-data/'
libs <- c('sqldf', 'data.table', 'rbenchmark')
lapply(libs, require, character.only = T)

n <- 1000000
set.seed(1)
ldf <- data.frame(id1 = sample(n, n), id2 = sample(n / 1000, n, replace = TRUE), x1 = rnorm(n), x2 = runif(n))
rdf <- data.frame(id1 = sample(n, n), id2 = sample(n / 1000, n, replace = TRUE), y1 = rnorm(n), y2 = runif(n))

benchmark(replications = 5, order = "user.self",
          noindex.sqldf = (sqldf('select * from ldf as l inner join rdf as r on l.id1 = r.id1 and l.id2 = r.id2')),
          indexed.sqldf = (sqldf(c('create index ldx on ldf(id1, id2)',
                                   'select * from main.ldf as l inner join rdf as r on l.id1 = r.id1 and l.id2 = r.id2')))
)

benchmark(replications = 5, order = "user.self",
          noindex.table = {
            ldt <- data.table(ldf)
            rdt <- data.table(rdf)
            merge(ldt, rdt, by = c('id1', 'id2'))
          },
          indexed.table = {
            ldt <- data.table(ldf, key = 'id1,id2')
            rdt <- data.table(rdf, key = 'id1,id2')
            merge(ldt, rdt, by = c('id1', 'id2'))
          }
)
#("R","h")])

}
# Rattle is Copyright (c) 2006-2013 Togaware Pty Ltd.

#============================================================
# Rattle Zeitstempel: 2013-08-29 10:13:29 x86_64-w64-mingw32 

# Rattle Version 2.6.26 Benutzer 'markus'

# Exportieren Sie diese Log-Textansicht in eine Datei anhand des Buttons 
# Exportieren oder dem Tools-Men�, um ein Log �ber alle Aktivit�ten zu speichern. Dies vereinfacht Wiederholungen. Exportieren 
# in die Datei 'myrf01.R' erm�glicht z. B., dass man in der R-Konsole den 
# Befehl source('myrf01.R') eingeben kann, um den Ablauf automatisch zu 
# wiederholen. Ggf. m�chten wir die Datei f�r unsere Zwecke bearbeiten. Wir k�nnen diese aktuelle Textansicht auch direkt 
# bearbeiten, um zus�tzliche Informationen aufzuzeichnen, bevor exportiert wird. 

# Beim Speichern und Laden von Projekten bleibt dieses Log ebenfalls erhalten.
crs<-new.env()
library(rattle)

# Diese Log zeichnet �blicherweise die Schritte zum Erstellen eines Modells auf. Mit sehr 
# wenig Aufwand kann es aber verwendet werden, um eine neue Datenreihe anzulegen. Die logische Variable 
# 'building' wird verwendet, um zwischen dem Erstellen von Umwandlungen, wenn ein Modell erstellt 
# wird und dem Verwenden von Umwandlungen, wenn eine Datenreihe angelegt wird, umzuschalten.

building <- TRUE
scoring  <- ! building

# Das Paket Colorspace wird verwendet, um die in den Grafiken vorhandenen Farben zu erzeugen.

library(colorspace)

##############################################################################################################
# 
##############################################################################################################

classifier.randomForest.fit<-function(crs,train.data)
{
# Ein vordefinierter Wert wird verwendet, um den zuf�lligen Startwert  zur�ck-zusetzen, damit die Ergebnisse wiederholt werden k�nnen.

mP("classifier.randomForest %d %d",dim(train.data)[1],dim(train.data)[2])
crs$seed <- 42 

#============================================================
# Rattle Zeitstempel: 2013-08-29 10:13:57 x86_64-w64-mingw32 

# Einen R-Datenrahmen laden

crs$dataset <- na.omit(train.data)
# Eine einfache Zuammenfassunf (Struktur) der Datenreihe anzeigen

#str(crs$dataset)

#============================================================
# Rattle Zeitstempel: 2013-08-29 10:13:59 x86_64-w64-mingw32 

# Die Auswahl des Benutzers beachten 

# Die Training-/Validierungs-/Test-Datenreihen erstellen

set.seed(crs$seed) 
crs$nobs <- nrow(crs$dataset) # 1220 observations 
crs$sample <- crs$train <- sample(nrow(crs$dataset), 0.7*crs$nobs) # 854 observations
crs$validate <- sample(setdiff(seq_len(nrow(crs$dataset)), crs$train), 0.15*crs$nobs) # 183 observations
crs$test <- setdiff(setdiff(seq_len(nrow(crs$dataset)), crs$train), crs$validate) # 183 observations

# Die folgenden Variablenauswahl wurde entdeckt.

#crs$input <- c("P.CLOSE.SMA.200", "P.CLOSE.SMA.90", "P.CLOSE.SMA.60", "P.CLOSE.SMA.30",               "P.CLOSE.SMA.10", "atr", "trueHigh", "trueLow",               "dn", "mavg", "up", "ZLEMA.na.omit.p...n...30.","high", "mid", "low", "runSD.p..n...30.",               "SAR.HLC.P.....3..", "williamsAD.HLC.P..", "P.CLOSE_slope90", "P.CLOSE_slope200",               "LAG.P.CLOSE.SMA.200", "LAG.P.CLOSE.SMA.90", "LAG.P.CLOSE.SMA.60", "LAG.P.CLOSE.SMA.30",               "LAG.P.CLOSE.SMA.10", "LAG.atr", "LAG.trueHigh", "LAG.trueLow",               "LAG.dn", "LAG.mavg", "LAG.up", "LAG.ZLEMA.na.omit.p...n...30.",               "LAG.high", "LAG.mid", "LAG.low", "LAG.runSD.p..n...30.",               "LAG.SAR.HLC.P.....3..", "LAG.williamsAD.HLC.P..", "LAG.P.CLOSE_slope90", "LAG.P.CLOSE_slope200")

crs$input<-colnames(crs$dataset)[-1]

#crs$numeric <- c("P.CLOSE.SMA.200", "P.CLOSE.SMA.90", "P.CLOSE.SMA.60", "P.CLOSE.SMA.30",                 "P.CLOSE.SMA.10", "atr", "trueHigh", "trueLow",                 "dn", "mavg", "up", "ZLEMA.na.omit.p...n...30.",                 "high", "mid", "low", "runSD.p..n...30.",                 "SAR.HLC.P.....3..", "williamsAD.HLC.P..", "P.CLOSE_slope90", "P.CLOSE_slope200",                 "LAG.P.CLOSE.SMA.200", "LAG.P.CLOSE.SMA.90", "LAG.P.CLOSE.SMA.60", "LAG.P.CLOSE.SMA.30",                 "LAG.P.CLOSE.SMA.10", "LAG.atr", "LAG.trueHigh", "LAG.trueLow",                 "LAG.dn", "LAG.mavg", "LAG.up", "LAG.ZLEMA.na.omit.p...n...30.",                 "LAG.high", "LAG.mid", "LAG.low", "LAG.runSD.p..n...30.",                 "LAG.SAR.HLC.P.....3..", "LAG.williamsAD.HLC.P..", "LAG.P.CLOSE_slope90", "LAG.P.CLOSE_slope200")

crs$numeric<-crs$input

crs$categoric <- NULL

crs$target  <- colnames(crs$dataset)[1]
crs$risk    <- NULL
crs$ident   <- NULL
crs$ignore  <- NULL
crs$weights <- NULL
Target <- crs$dataset[,1]
#============================================================
# Rattle Zeitstempel: 2013-08-29 10:14:04 x86_64-w64-mingw32 

# Random Forest 

# Das Paket 'randomForest' stellt die Funktion 'randomForest' zur Verf�gung.
#View(crs$dataset[crs$sample,c(crs$target,crs$input)])
require(randomForest, quietly=TRUE)

# Das Random Forest-Modell erstellen

set.seed(crs$seed)

mP("pre forest")
#as.factor(P) -.. macht das Teil zum Klassifikator
crs$rf <- randomForest(as.factor(Target) ~ .,
                       data=crs$dataset[crs$sample,c(crs$input, crs$target)], 
                       ntree=500,
                       mtry=4,
                       importance=TRUE,
                       na.action=na.roughfix,
                       replace=FALSE)


# Die Textausgabe des Modells 'Random Forest' erstellen
crs$model.err = last(crs$rf$err.rate)[1]

mP("after forest - err %f",crs$model.err)

crs$rf
ls(crs$rf)

last(crs$rf$err.rate)


# Die Wicktigkeit der Variablen auflisten

rn <- round(importance(crs$rf), 2)
rn[order(rn[,3], decreasing=TRUE),]

if (F)
{
# The `pROC' package implements various AUC functions.

require(pROC, quietly=TRUE)

# Calculate the Area Under the Curve (AUC).

roc(crs$rf$y, crs$rf$votes)

# Calculate the AUC Confidence Interval.

ci.auc(crs$rf$y, crs$rf$votes)
}

if (F)
{
# Die Wicktigkeit der Variablen auflisten

rn <- round(importance(crs$rf), 2)
wichtigkeit =rn[order(rn[,3], decreasing=TRUE),]
View(wichtigkeit)
}
# Ben�tigte Zeit: 7.25 Sek


#============================================================
#
# Die Modellleistung auswerten 

# Eine Fehlermatrix f�r das Modell Random Forest erstellen

# Die Antwort vom Modell Random Forest erhalten

#gibt die Wahrscheinlichkeit f�r die in Frage kommenden Kategorien
crs$pr <- predict(crs$rf, type="vote",newdata=na.omit(crs$dataset[crs$test, c(crs$input, crs$target)]))

#sagt: welche Kategorie gewinnt
crs$pr <- predict(crs$rf,newdata=na.omit(crs$dataset[crs$test, c(crs$input, crs$target)]))

# Generate the confusion matrix showing counts.

table(na.omit(crs$dataset[crs$test, c(crs$input, crs$target)])$Target, crs$pr,
      dnn=c("Ist", "Vorausgesagt"))

# Generate the confusion matrix showing percentages.

round(100*table(na.omit(crs$dataset[crs$test, c(crs$input, crs$target)])$Target, crs$pr, 
                dnn=c("Ist", "Vorausgesagt"))/length(crs$pr))

# Die allgemeine Fehlerquote berechnen

overall <- function(x)
{
  if (nrow(x) == 2) 
    cat((x[1,2] + x[2,1]) / sum(x)) 
  else
    cat(1 - (x[1,rownames(x)]) / sum(x))
} 

if (T)
  overall(table(crs$pr, na.omit(crs$dataset[crs$test, c(crs$input, crs$target)])$Target,  
              dnn=c("Predicted", "Actual")))

return(crs$model.err)
}

###############################################################################################################
# hol Dir die classification vom randomForest f�r newData (dataCloud) 
#das Ergebnis wird ein 2 dim  xts aus signal und signalsicherheit
###############################################################################################################

classifier.randomForest.predict<-function(crs, newData)
{
newData= na.omit(newData)
# Die Antwort vom Modell Random Forest erhalten
#gibt die Wahrscheinlichkeit f�r die in Frage kommenden Kategorien
crs$pr2 <- predict(crs$rf, type="vote",newdata=newData)
confidence=max(crs$pr2)
#sagt: welche Kategorie gewinnt
crs$pr <- predict(crs$rf,newdata=newData)
#browser(mP("#####"))

#factor -> integer  umrechnen
signal = as.numeric(levels(last(crs$pr)))[last(crs$pr)]
mP("     predict: ")
#das Ergebnis wird ein 2 dim  xts aus signal und signalsicherheit
res=as.xts(data.frame(signal=signal,confidence=confidence,model.err=crs$model.err),index(last(newData)))
print(res)
return (res)
}
