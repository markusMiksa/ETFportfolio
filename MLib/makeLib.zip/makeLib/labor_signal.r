####################################################################################
#beschreibung technischer indikatoren
#Quelle: http://www.broker-test.de/finanzwissen/technische-analyse/volatilitaet/  
#####################################################################################
options(error = quote({
  #  sink(file="error.txt");
  dump.frames();
  print(attr(last.dump,"error.message"));
  traceback();
  #  sink();
}))

options(warn=1)
########################################################################
if (F)
{
  sym="X5YEARNOTE"
  date="2008-09-19"
  w=as.Date(index(dax["2008-09-19"]));visual=T
}


if (F)   #####  die arbeitsbank###############################################
{
  ls(data)
  dax=Cl(data$DAX)
  
  colnames(data$prices)
  sym="JPM"
  dax =data$prices[,sym]
  dax=m.ifna.prev(dax)
  plot(dax)
  len(dax[is.na(dax)])
  dax.frame = sprintf("%s::",as.Date(DateS(dax[which(dax==min(dax))]))-200)
  dax.f = dax[dax.frame]
  #dax.f = dax.f["2005::"]
  #HL=HighLows(dax.f,maxdd=38,visual=T)
  #names(HL)
  
  #hol dir die wendepunkte um ein paar interessante abschnitte im chart zu finden
  fs=fast.smoothing(dax,glaettung = 5,visual=T)
  wendepunkte = as.Date(fs$hl)-20   #ein bischen vor dem wendepunkt
  wendepunkte = wendepunkte[-1]
  
  w<<-as.Date(index(dax[500]))
  w<<-as.Date(index(data$prices[500,sym]));visual=T
  visual=T
  
  posTable <-NULL   #l�sche hiermit die Ergebnistabelle
  #steuer einen interessanten Wendepunkt an
  for(i in 1:len(wendepunkte)) 
  {
    visual=F
    i=2
    w<<-as.Date(wendepunkte[i])-10
    if (i==1)
      w0 = first(dax)
    else
      w0= as.Date(wendepunkte[i-1])+10
    
    plot(dax.w)
    amark(w0)
    amark(w)
    #laufe ab dem Wendepunkt weiter ####################################>>>>
    while (T)
    {
      dax.w = dax[sprintf("%s::%s",w0,w)]
      dax.w = tail(dax.w,1500)
      p=dax.w
      estimate.pos(dax.w,visual=visual)  #der tech-cloud - aufruf
      
      if (DateS(last(dax))==DateS(last(dax.w)))
        break
      w<<-w+1  #tage vorw�rtsgehen   <<<###################################
    }
  } 
  #......... nutze die posTable als technische Umgebung f�r das signal.system:
  # .. getPos
  
  colnames(posTable)
  View(posTable)
  ignoreCols=-c(which(colnames(posTable) %in% spl("date")))
  Pos=xts(posTable[,ignoreCols], order.by=as.Date(posTable[,"date"]))
  
  Signal = xts(posTable[,"itpSum"], order.by=as.Date(posTable[,"date"]))
  signal = sign(Signal+2)   
  
  signal <- Signal;signal[]=0
  i=100
  ########## das heuristische technische System anwenden #####
  #iteriere �ber alle tage  ........................
  last.res<<-1; signal[]=sapply(1:len(Signal),getSig)   #getSig
  
  B=na.omit(merge(dax,signal,Pos))  #datum-align
  B=B[-c(1:100)] #offset
  plotSigPrice(signal=B[,2],prices=B[,1],indi=list(m=merge(B[,"m.orange"],0)))  
  #############################################################################
  
  View(  data.table(posTable)[date=="2008-04-16"])
  plotSigPrice(signal=B[,2],prices=B[,1],indi=list(m=merge(Pos[,"m.red"],Pos[,"m.magenta"],Pos[,"m.orange"],0)))  
  
  write.table(posTable,"posTable_DAX.csv",sep=";",row.names=F)
  plot(p)
  
  batch.Pos()  ########################  im Batch die tech-Cloud erstellen
  
}


########################################################################
#baue die tech-cloud
########################################################################
batch.Pos_ <-function (visual=F,prof=F)
{
  # profiling of running time
  count=0
  
  for (sym in colnames(data$prices))
  {
    itp.PIPES<<-list() #pipe-storage-reset
    # sym="INTERNATIONALEQUITY"
    fname=sprintf("TechCloud/posTable_%s.csv",sym)
    if (file.exists(fname))
      {
      mP("File already exists %s",fname)
      next
    }
    posTable <<-NULL   #l�sche hiermit die Ergebnistabelle
    #steuer einen interessanten Wendepunkt an
    dax = data$prices[,sym]
    visual=T
    visual=F
    pre.wi=0
    
    fs=fast.smoothing(dax,glaettung = 5,visual=T)
    #layout(1)
    wendepunkte = as.Date(fs$hl)-10   #ein bischen vor dem wendepunkt
    w0 = get.Index(dax, as.Date(index(first(dax))))
    w<-w0 +200
    
    #plot(dax,main=sym)
    amark(DateS(dax[w0]),col="green")
    amark(DateS(dax[w]))
    lines(dax,col="red")
    
   
    #laufe ab dem Wendepunkt weiter
    while (T)
    {
      count = count+1
      
      dax.w = dax[w0:w]
      #if (len(dax.w) <200)
      #  dax.w=dax[(w-200):200]
      dax.w = tail(dax.w,500)
      p=dax.w
      if (visual) lines(p,col="blue",lwd=2)
      mP("%d ##### %s sym  ### %s .. %s ###",count,sym,DateS(dax[w0]),DateS(dax[w]))
      p200 =dax[(w-201):w]
  
      mP("shape %d",shape(p)) 
      #browser()
      if(prof && count >= 10)
         Rprof("o:\\R\\Nuggets\\Eckhard\\estimate.pos.out")
      estimate.pos(p,p200,visual=visual)  #der eigentliche cloud bauer
    
      if(prof && count >= 10)
      {        
        Rprof()
        print(summaryRprof("o:\\R\\Nuggets\\Eckhard\\estimate.pos.out"))
        browser(mP("prof#########################"))
        break
      }
      else    
      if (DateS(last(dax))==DateS(last(dax.w)))
        break
      if (prof && count > 10)
         break
      
      w<-w+1   #den tag weiterschalten
      
      if (w >= shape(dax))
        break;
      if (F&& DateS(dax[w])>=as.Date("2009-01-01")) #TEST
          sag("2009",warte=T)
      if (visual) amark(DateS(dax[w]))
      
      #..............................................
      
      if (pre.wi <len(wendepunkte))
      if (DateS(dax[w]) > wendepunkte[pre.wi+1] +60)  #30 Tage �ber den n�chsten Wendepunkt 
      {
  #      browser(mP("neuer wendepunkt"))
        pre.wi=pre.wi+1
      
        w0=get.Index(dax, wendepunkte[pre.wi])
        lines(dax,col="red")
        amark(DateS(dax[w0]),col="darkgreen")
        
      }      
    }
    
  
    # browser(mP("write"))
    write.table(posTable,fname,sep=";",row.names=F)  
  }
}
batch.Pos<-cmpfun(batch.Pos_) #compilier das Teil

if (F)
  {
   batch.Pos()  ########################  im Batch die tech-Cloud erstellen
   batch.Pos(visual=F,prof=T)
}
####################################################################
#passt das vorzeichen der beabsichtigen neuen position res zu den anderen Indikatoren
###################################################################
consistence.check_<-function(i,res,main="")
{
  if (res ==0)
    return(res)
  #return(res)
  cons.syms="itpSum,earlySigSum,uM,loM"
  cons.syms="earlySigSum,uM,loM"
  
  #cons.syms="itpSum,uM,loM"
  
  for (col in spl(cons.syms))
    if (res != sign.val(Pos[i,col]))
    {
      mP("%s to %d : consistence.break on %s",main,res,col)  
      res=0; 
      break
    }
  res
}
consistence.check<-cmpfun(consistence.check_) #compilier das Teil

#..........................................................................
###########################################################################
#ein LongShort-Timing modell - von Hand - welches die technische DataClouds (posTable) auswertet
#mit 
#Signal = xts(posTable[,"itpSum"], order.by=as.Date(posTable[,"date"]))
###########################################################################
getSig<-function(i)
{
  today=DateS(Pos[i,1])
  #browser(mP("%s %d",today,last.res))
  
  if (last.res==0)
    res=0
  else
  {    
    new.res=sign.val(Pos[i,"m.orange"])
    if (new.res != last.res)
    {
      new.res=consistence.check(i,new.res,"pos drehen wollen")
      if (new.res != 0 )
      {
        mP("pos drehen %s to %s",today,res)
        amark(today,col="orange")
        res = new.res
      }
    }
    else
      res = last.res
  }
  sig=nval(Signal[i])
  if (abs(sig) >=  4 && last.res >0 && sign(last.res) != sign(sig))  #crash-stop
  {
    res=0
    mP("stop %s to %s",today,res)
    amark(today,col="red")
  } 
  if (last.res ==0)
    if (abs(sig) < 2 && !Pos[i,"noTrend.i"]    )    #  abs(sig) < 2
    {
      res = sign.val(Pos[i,"SuloM"])
      #res =sign.val(Pos[i,"m.orange"])
      #das signal muss gut passen,
      res =consistence.check(i,res,"reentry wollen")
      
      if (F && today > as.Date("2008-01-01"))  #date debug
      {
        amark(today) 
        browser()
      }
      #sonst lieber wieder auf 0
      if (res !=0)
      {
        mP("reentry %s to %d",today,res)
        amark(today,col="darkgreen")
        #browser()
      }
    }
  last.res<<-res
  res
}
############################################################################
sign.val <-function(x)
{
  if (is.na(x) || is.na(nval(x)))
    return (0)
  return( sign(nval(x)))
}

##############################################################
#beetrachte die Unterschiede der tail der winkel der drei smooth-reihen
#betrachte ihre Vorzeichen
# sum(signals)
#sum(diff(tail(smooths)))   #sum(diff(mROC(tail,smooths)))
#und erkenne STeil-abst�rze   sum(diff(tail(price),tail(smooths)))
#betrachte die quantile dieser differenzen - und sag ab wann ein wert
#�berschritten wird
#betrachte  auch ob sich ein smooth der Hihgs anders verh�lt wie ein smooth der lows.
#gib auch sma 90 und sma200 hinzu  (selffullfillings )
#p ist die zeitreihe seit dem letzten Trend-wechsel
##############################################################
estimate.pos_<-function(p,p200,visual =F)
{
  mP("estimate.pos %s shape  %d ",DateS(last(p)),shape(p))
  # browser()
  p = m.ifna.prev(p)
  x=1:len(p)
  y=coredata(p)
  #damit loess auch prognostizieren kann:
  loess.m <- loess(y ~ x, data.frame(x=x,y=y),span=0.9,control = loess.control(surface = "direct"))
  
  newx=seq(1, 30, 1)
  loess.forec=predict(loess.m, data.frame(x = newx+last(x)),se=T)
  
  x1=c(x,newx+last(x))
  y1=c(y,loess.forec$fit)
  
  if (visual)
  {
    plot(x1,y1,type="n",col="blue")
    lines(x,y,col="black")
    lines(loess.m$x,loess.m$fitted,col="red",lwd=2)
    lines(tail(x1,len(newx)),tail(y1,len(newx)),col="blue",lwd=3)
  }
  ###################################################
  npmodel1 <- lowess(y~x,f=0.1)
  if (visual)lines(npmodel1, col="magenta", lwd=4)
  ys=ksmooth(p,glaettung=6)
  if (visual)lines(1:shape(ys),coredata(ys),col="orange",lwd=3)
  
  #die Zukunft
  #ys=ksmooth(dax,glaettung=3)
  #lines(1:shape(ys),coredata(ys),col="green")
  tlen=2
  
  p.red=nval(loess.m$fitted)
  p.orange=coredata(ys)
  p.magenta=nval(npmodel1$y)
  
  ## hieraus tabelle bauen
  l.red = nval(last(p.red))
  l.orange = nval(last(p.orange))
  l.magenta=nval(last(p.magenta))
  last.p = last(p)
  l.p = nval(last.p)
  l.p.date=DateS(last(p))
  p.90 = last(na.omit(p),90)
  
  #proczentuelle �nderungen
  m.red=m.sig(p.red,tlen); 
  m.orange=m.sig(p.orange,tlen)
  m.magenta=m.sig(p.magenta,tlen)
  
  #kr�mmungen der smoothies
  if (visual)browser(mP("...."))
  k.red=k.orange=k.magenta=last(p.90)
  k.red[]= last(ROC(ROC(last(p.red,11),5),5))*100
  k.orange[]=last(ROC(ROC(last(p.orange,11),5),5))*100
  k.magenta[]=last(ROC(ROC(last(p.magenta,11),5),5))*100
  
  
  sig.red=sign(m.red)
  sig.orange = sign(m.orange)
  sig.magenta = sign(m.magenta)
  sig.sum=sig.red+sig.orange+sig.magenta
  
  d.red= (l.red- l.orange) + (l.red-l.magenta)
  dm.red= (m.red-m.orange) + (m.red-m.magenta)
  dp.red = (l.red - l.p) 
  
  #mchart(merge(p,p.red))
  
  #soll steile price- crashs bemerken
  itp.dp.red=last(in.Trend.pos(last(p-p.red,200),visual=visual,main="itp.dp.red"))
  roc5=mROC(p,5); l.roc5 = last(roc5)
  itp.roc5 = last(in.Trend.pos(last(roc5,200),visual=visual,main="itp.roc5"))
  #  browser(mP("p200"))
  if (shape(p200) < 200)
    browser(mP("p200"))
  faber=p-SMA(p200,200); l.rocfaber5=last(mROC(faber,5))
  itp.faber= last(in.Trend.pos(last(faber,200),visual=visual,main="itp.faber"))
  
  #..................................................................
  #welch steigung hat der long-term-trend und wie ist die itp im Trend
  #layout(1:2)
  m.lm=m.lm.fit(p,getIndex=T,visual=F)
  all.r.squared= m.lm$r.squared
  all.m=m.lm$m
  m.chan=m.predict(m.lm$fit,y=p)
  itp.all=in.Trend.pos(last.p, m.chan[l.p.date])      
  
  #welch steigung hat der 90-er-trend und wie ist die itp im Trend, wie valide ist der trend 
  m.lm.90=m.lm.fit(p.90,getIndex=T,visual=F)
  p.90.r.squared= m.lm.90$r.squared
  p.90.m = m.lm.90$m
  m.chan.90=m.predict(m.lm.90$fit,y=p.90)
  #mchart(merge(p.90,m.chan.90))  
  itp.90=in.Trend.pos(last.p, m.chan.90[l.p.date])  
  
  dm90ALL = xts(nval(all.m-p.90.m),as.Date(l.p.date))
  itp.dm90All = itp.pipe(dm90ALL,30,visual=visual,last=T)
  #plot(p)
  #p.90.m.lowess=m.lm.fit(last(p,200),visual=T,getIndex=T,w="lowess")$m
  #differenz der steigungen zwischen kurs und sma200 muss gro� genug sein, sonst taugt
  
  if (F)  #evtl. nicht n�tig ... ausser es gibt probleme mit der noTrend-Erkennung
  {  
    #faber nicht als signalgeber
    #die steigung des SMA200 �ber 30 Tage regressed
    m.lm.SMA30=m.lm.fit(last(SMA(p200,200),30),visual=F)
    sma.30.r.squared= m.lm.SMA30$r.squared
    sma.30.m = m.lm.SMA30$m
    #die steigung des kurses der letzten 30 Tage
    m.lm.30=m.lm.fit(last(p.90,30),getIndex=T,visual=F)
    p.30.r.squared= m.lm.30$r.squared
    p.30.m = m.lm.30$m
    #differenz der steigungen -> evtl. in noTrend verwenden
    
    sma.dm=p.30.m-sma.30.m
  }
  else
  {
    sma.dm=  p.30.r=p.30.m = m.lm.SMA30=0
  }
  #...........................wie ist die itp im Bollinger Band
  itp.bb=0
  if (F)
  {
    bb=BBands(p200,n=200,maType = "SMA")
    itp.BB=bb[,4]
    itp.bb=in.Trend.pos(last.p,last( bb[,c("mavg","dn","up")]))
    
    if (F&& visual)  #showBB
    {
      mchart(merge(p,bb[,c("mavg","dn","up")]),main="") #mPlots
      itp.bb=in.Trend.pos(p, bb[,c("mavg","dn","up")])
      mchart2(p,itp.bb)
      mPlots(merge(p,bb[,-4]),bb[,"pctB"],itp.bb)
      
    }
  }
  if (shape(p200)<200)
     sag("bug p200",warte=T)
  #......... liegt er in der target.range
  tlen=find.Wlen(p.90,target.range=15) #gehe so lange nach links bis du ein range von 15% hast
  Tlen=xts(nval(tlen),as.Date(l.p.date))
  itp.tlen=  itp.pipe(Tlen,60,visual=visual,last=T)
  
  tlen=max(30,tlen)    
  #auch ein itp der tlen... werte ... die sollten in starken Trends l�nger sein
  
  itpP= na.omit(in.Trend.pos(last(p.90,tlen),visual=visual,main=sprintf("itpP-%d",tlen)))
  
  itp.P= last(itpP)   #wenn itp.P im Intervall 3,-3 liegt - ist das eine
  
  #Indikation f�r Seitw�rtsbewegung:  .. siehe auch range.up, range.low
  if (len(itpP)>=1)
  {
    last.itpP=last(itpP,10)
    nl=min(10,len(last.itpP))
    noTrend=last(EMA(last.itpP,nl))  #in den letzten 10 Tagen war nichts los
    noTrend.i= noTrend >=-3 & noTrend <= 3 & itp.P >=3 & itp.P <= 3   #heute auch nicht
  }
  else
    noTrend.i=NA
  #.......... l�uft der obere kanal anders wie der untere ?
  showTop=visual
  
  #muss hier alles �ber tlen statt p.90 laufen ???
  #tlen=20
  k=max(tlen,20); k=min(50,tlen) 
  K=5
  #  x=coredata(p)
  p.tlen=last(p.90,tlen)   #evtl. hier lieber bei den vollen p.90  bleiben ...?
  y=runquantile(coredata(p.tlen), k, probs=c(0.20,  0.5,  0.80))
  col = c( "red", "green", "blue")
  up.low=merge(p.tlen,p.tlen,p.tlen)
  up.low[,2]=runmean(y[,,1],K)
  up.low[,1]=runmean(y[,,2],K)
  up.low[,3]=runmean(y[,,3],K)
  
  if (visual) {mchart(up.low,main=sprintf("tlen=%d",tlen));points(p.tlen,col="green",lwd=2)}
  
  #lowess regressionen durch die quantile
  mid=up.low[,1] ; mid.fit = m.sig(mid,3)
  #mid.fit=m.lm.fit(mid,visual=visual,getIndex=T,w="lowess")$m
  low=up.low[,2] ; low.fit=m.sig(low,3)
  #low.fit=m.lm.fit(low,visual=visual,getIndex=T,w="lowess")$m
  up=up.low[,3];   up.fit=m.sig(up,3)
  #up.fit=m.lm.fit(up,visual=visual,getIndex=T,w="lowess")$m
  #die summe der Quantiles-Steigungen
  #die Q steigungen: mehrheitsentscheid
  Q.m = xts(sum(sign(mid.fit),sign(low.fit),sign(up.fit)),as.Date(l.p.date))
  #lineare steigung der preise auf dem st�ck
  p.tlen.m = xts(m.lm.fit(p.tlen,visual=visual,getIndex=T,w="")$m,as.Date(l.p.date));colnames(p.tlen.m)=colnames(p.90)
  
  
  #  browser(mP("tlen Q.m %d und p.tlen.m %f",Q.m, p.tlen.m))
  
  
  #  if (visual)mchart(merge(p.90,mid,low,up))
  if (showTop) mchart(merge(p.tlen,mid,low,up),main=sprintf("showTop tlen %d",tlen))
  
  highs <- findpeaks(as.numeric(p.tlen[p.tlen>=up ]) )[,2]
  if (len(highs)< 3)  highs=index(p.tlen[p.tlen>=up ])
  upper=p.tlen[p.tlen>=up ][highs]
  if (showTop) points(upper,col="blue",lwd=1)
  
  lows <- findpeaks(-as.numeric(p.tlen[p.tlen <=low]) )[,2] 
  if (len(lows)< 3)  lows=index(p.tlen[p.tlen<=up ])
  lower = p.tlen[p.tlen <=low][lows]
  if (showTop)points(lower,col="red",lwd=1)
  
  #geringe range.up hei�t:  oben liegt ein deckel drauf
  range.up=range(upper);  range.up=diff(range.up)/range.up[1]*100
  range.low= range(lower); range.low=diff(range.low)/range.low[1]*100
  
  
  #die Steigungen durch die oberen und unteren - separat gefitteten Kan�le
  u.lm=m.lm.fit(upper,visual=F,getIndex=T)
  uM = u.lm$m   #die steigung des oberen Kanals
  if (showTop && !is.na(u.lm$fit))
  {
    upper=p.tlen;   upper[]=predict(u.lm$fit,newdata=data.frame(x=1:len(p.tlen)))#,interval="prediction")
    lines(upper,col= "magenta")
  }
  lo.lm=m.lm.fit(lower,visual=F,getIndex=T)  
  loM= lo.lm$m #die Steigung des unteren Kanals
  if (showTop && !is.na(lo.lm$fit))
  {
    lower=p.tlen; lower[]=predict(lo.lm$fit,newdata=data.frame(x=1:len(p.tlen)))#,interval="prediction")
    lines(lower,col= "brown")
  }
  SuloM = uM+loM
  #..........schreib alles in den posTable data.frame
  
  date=l.p.date
  
  ITP=c(coredata(itp.dp.red),itp.roc5,itp.faber, itp.bb, itp.90,itp.P)
  itpSum= mean(coredata(ITP),na.rm=T) #sehr wichtig !!!
  
  early=as.vector(c(coredata(l.roc5),l.rocfaber5  ,k.red,k.orange,k.magenta, Q.m, p.tlen.m,p.30.m))
  earlySigSum = sum(sapply(coredata(early),sign),na.rm=T)
  
  allSigSum=sum(sapply(
    c(uM,loM,SuloM,sig.red,sig.orange,sig.magenta,sig.sum, itpSum, itp.dp.red,itp.roc5,itp.faber,k.red,k.orange,k.magenta, itp.bb, itp.90,itp.P ,earlySigSum,l.roc5,l.rocfaber5,m.red,m.orange,m.magenta,d.red,dm.red, dp.red,all.m, itp.all,  p.90.m,sma.dm,range.up,range.low,Q.m,p.tlen.m),
    sign),na.rm=T)
  
  target=l.p #nur damit man leichter in xls analysieren kann
  
  #browser(mP("ITP"))
  
  
  appendTable(posTable,date,target,noTrend.i,uM,loM,SuloM,itpSum,sig.red,sig.orange,sig.magenta,sig.sum, itpSum, itp.dp.red,itp.roc5,itp.faber, itp.bb, itp.90,itp.P ,itp.tlen,itp.dm90All,earlySigSum,allSigSum, l.roc5,l.rocfaber5,k.red,k.orange,k.magenta,m.red,m.orange,m.magenta,d.red,dm.red, dp.red,all.m, all.r.squared,itp.all,  p.90.m,p.90.r.squared,p.30.m,Q.m,p.tlen.m,sma.dm,range.up,range.low  )
  
  #itp.tlen,itp.dm90All
  
  mP("sig.sum %s %d",date,sig.sum)
  
  if (visual)
    View(posTable)
  if (visual)
    browser(mP("......................... %s",l.p.date))
  
  sig.sum
}
estimate.pos<-cmpfun(estimate.pos_) #compilier das Teil


m.sig = function(y,tlen=-1)
{
  if (tlen == -1)
    {
      y=na.omit(y)
      tlen= shape(y)
    }
  #y=tail(y,tlen)
  #m=(nval(y[tlen])-nval(y[1]) )/ tlen
  
  #browser(mP("m.sig tlen %d %d",tlen,shape(y)))
  
  tlen=min(shape(y),tlen)
  m=(lag(y,k=tlen)-y)/tlen  
}


##gehe so lange nach links bis du ein range von 15% hast
find.Wlen_<-function(p,target.range=3)
{
  l=len(p)
  res =l
  
  for(w in 2:l)
  { 
    rag=range(p[(l-w):l])
    #rg=diff(rag)/rag[1]*100
    rg = diff(rag)/rag[1]*100
    # mP("%d %f  %f",w, diff(rag),rg)
    if (rg >= target.range)
    {res=max(1,w-1); break}
  }
  #  res = as.xts(as.numeric(res),order.by=as.Date(index(last(p))))
  return(res)
}
find.Wlen<-cmpfun(find.Wlen_) #compilier das Teil



##########################################################
###########################################################

if (F)
{
  plot(dax)
  x=1:shape(dax)
  y=coredata(dax)
  plot(x,y,xlab="log time",ylab="log flux",type="l")
  npmodel1 <- lowess(y~x,f=0.02)
  lines(npmodel1, col=4, lwd=2)
  
  lm=loess.smooth(x,y=y,span=0.02)   #MM_LOESS_SMOOTH
  #grafing in x,y punkten
  plot(x,y,pch=".")
  lines(lm$x,lm$y,col="red",lwd=2)
  
  lm=loess.smooth(x,y=y,span=0.02,family = "gaussian")   #MM_LOESS_SMOOTH
  #grafing in x,y punkten
  #plot(x,y,pch=".")
  lines(lm$x,lm$y,col="blue",lwd=2)
  
  loess.m <- loess(y ~ x, data.frame(x=x,y=y),span=0.02)
  plot(x,y,type="l")
  lines(loess.m$x,loess.m$fitted,col="red",lwd=2)
  len
  
  #damit loess auch prognostizieren kann:
  loess.m <- loess(y ~ x, data.frame(x=x,y=y),span=0.09,control = loess.control(surface = "direct"))
  
  newx=seq(1, 30, 1)
  loess.forec=predict(loess.m, data.frame(x = newx+last(x)),se=T)
  
  x1=c(x,newx+last(x))
  y1=c(y,loess.forec$fit)
  plot(x1,y1,type="n",col="blue")
  lines(x,y,col="black")
  lines(loess.m$x,loess.m$fitted,col="red",lwd=2)
  lines(tail(x1,len(newx)),tail(y1,len(newx)),col="blue",lwd=3)
  ###################################################
  npmodel1 <- lowess(y~x,f=0.1)
  lines(npmodel1, col=4, lwd=2)
  ys=ksmooth(dax,glaettung=3)
  lines(1:shape(ys),coredata(ys),col="green")
  
}
#################################################################################
#################################################################################

signal.TEST.1 <-function(arg, par = mlist( sma.w=c(200,120,220,20)),visual=F,...)
{
  p=mNorm(arg$clos)
  sma200 = bt.apply.matrix(p, SMA, n=as.integer(par$sma.w))
  sma200[is.na(sma200)]<-0
  signal = iif(p >= sma200,1,0)
  
  return(list(Signal=signal, Indi=list(ma=merge(sma200,p))))
}
#......... dynamisches SMA ...

roll.itp.P<-function(i,P,visual=F)
{
  today=DateS(P[i])
  p=P[i]
  itp.p.ALL=itp.pipe(p,50,visual=visual,last=T,opt.getQ="get.Quantile.M") 
  if (visual)
  {
  print(today)
  print(itp.p.ALL)
  }
  crashStop= itp.p.ALL$itp < -3
  
}

#sieht unfassbar super aus
signal.TEST.1.a <-function(arg, par = mlist( sma.w=c(200,120,220,20)),visual=F,...)
{
  p=mNorm(arg$clos)
  sma200 = bt.apply.matrix(p, SMA, n=as.integer(par$sma.w))
  sma200[is.na(sma200)]<-0
  #w=3
  #roc.sma=ROC(sma200,w);
  #itp.p=itp.pipe(roc.sma,50,visual=T,last=F)
  #itp.p.ALL=itp.pipe(p,50,visual=visual,last=F,opt.getQ="get.Quantile.M") 
  
  #roll mal �ber itp  .. dauert ewig lange
  #signal[]=sapply(1:len(p), roll.itp.P,P=p,visual=F)
  #rasend schnell weil voll vector-orientiert
  itp.s= in.Trend.pos(p,visual=F,main=sprintf("itp.pipe %s %d",name,50),last=F,opt.getQ="get.Quantile.M",k=50)
  
  #mchart2(p,-itp.s$Q.m)
  signal = sign(-(itp.s$Q.m[,2]+itp.s$Q.m[,1]))
  #plotSigPrice(signal=signal,prices=dax,indi=list(macd=-itp.s$Q.m))

  return(list(Signal=signal, Indi=list()))#Q.m=-itp.s$Q.m)))
}
#.........................................................................
if (F)
{
  #itp.PIPES$roc.sma)
  x=indi.Generic("signal.TEST.1.a", global_arg, par=list(sma.w=200),visual=T, TRAINSYM ="DAX")
  x=indi.Generic("signal.TEST.1.a", global_arg, par=list(sma.w=300),visual=T, TRAINSYM =-1,experiment="DaxMdax")

  
  itp.PIPES<<-list()
  names(itp.PIPES)
  dim(itp.PIPES$roc.sma)
  dim(itp.PIPES$p)
  
  itp.PIPES
  plot(itp.p)
}



#--------------------------------------------------------------------------------

signal.TEST.1.schrott <-function(arg, par = mlist( sma.w=c(200,120,220,20)),visual=F,...)
{
  p=mNorm(arg$clos)
  sma200 = bt.apply.matrix(p, SMA, n=as.integer(par$sma.w))
  sma200[is.na(sma200)]<-0
  signal = iif(p >= sma200,1,0)
  
  return(list(Signal=signal, Indi=list(ma=merge(sma200,p))))
}

#--------------------------------------------------------------------------------


#.... robFilter wurde aussen schon mal berechnet
signal.TEST.2 <-function(arg, par = mlist( sma.w=c(200,120,220,20)),visual=F,...)
{
  dax=mNorm(arg$clos)
  #rob =get_rob(dax,ow=220)
 # browser()
  macd= rob$filter[,spl("MED,TRM")]
  macd= merge(dax,rob$filter[,spl("MTM")])
  macd[,2] = macd[,2]-0.1
  
  signal= - iif(macd[,1]> macd[,2],-1,1)
  
  return(list(Signal=signal, Indi=list(macd=macd)))
}
  #.........................................................................
  if (F)
  {
    x=indi.Generic("signal.TEST.2", global_arg, par=list(sma.w=200),visual=T, TRAINSYM ="DAX")
    x=indi.Generic("signal.TEST.2", global_arg, par=list(sma.w=300),visual=T, TRAINSYM =-1)
  }   
#...........................................................................
if (F)
{
  wlen=110
  dax = data$prices["SX5R"]
  
  rob =get_rob(mNorm(dax),iw=wlen/2,ow=wlen)
  purePlot(merge(mNorm(dax),rob$filter))
  lines(SMA(mNorm(dax),200),col="orange",lwd=3)
  macd= rob$filter[,spl("MED,TRM")]
  macd= merge(mNorm(dax),rob$filter[,spl("MTM")])
  macd[,2] = macd[,2]-0.1
  
  
  
  purePlot(macd)
  signal= -iif(macd[,1]> macd[,2],-1,1)
  plotSigPrice(signal=signal,prices=dax,indi=list(macd=macd))

  
  sma200=SMA(mNorm(dax),200)
  signal=dax[,1]
  signal[]=rowMeans( bt.apply.matrix(rob$filter,function(x) iif(x>sma200,1,-1)))
  signal[]=rowMeans( bt.apply.matrix(rob$filter,function(x) sign(ROC(x,5))))
  
  signal = iif(abs(signal)<1, 0, sign(signal))
  signal = sign(signal)
  plotSigPrice(signal=signal,prices=dax,indi=list(macd=macd))
  
  
}


