#schau bei #MM_GENERIC
# http://www.rseek.org/
####################################################################################
#beschreibung technischer indikatoren
#Quelle: http://www.broker-test.de/finanzwissen/technische-analyse/volatilitaet/  
#####################################################################################
options(error = quote({
  #  sink(file="error.txt");
  dump.frames();
  print(attr(last.dump,"error.message"));
  traceback();
  #  sink();
}))

options(warn=1)

#library(debug)
#mtrace(f)

######################################################################################
######################################################################################

if (F)
{
  library('doRedis')
  registerDoRedis('jobs')
  startLocalWorkers(n=6, queue='jobs')
  foreach(icount(10),.combine=sum,.multicombine=TRUE,.inorder=FALSE) %dopar%
    4*sum((runif(1000000)^2 + runif(1000000)^2)<1)/10000000
  
  removeQueue('jobs')
}
######################################################################################
###################################################################################### 

GMMA <- function(x) {
  fastMA <- c(3,5,8,10,12,15)
  slowMA <- c(30,35,40,45,50,60)
  x <- sapply(c(fastMA,slowMA),   function(xx) EMA(x,xx))
  return(x)
}

if (F)
{
  require(quantmod)
  require(PerformanceAnalytics)
  
  # Step 1: Get the data
  getSymbols("^GDAXI")
  GSPC=GDAXI
  # Step 2: Create your indicator
  dvi <- DVI(Cl(GSPC))
  
  # Step 3: Construct your trading rule
  sig <- Lag(ifelse(dvi$DVI < 0.5, 1, -1))
  
  # Step 4: The trading rules/equity curve
  ret <- na.omit(mROC(Cl(GSPC))*sig)
  ret <- ret['2005-06-02/2010-09-07']
  
  eq <-mRendite(ret)
  eq <- exp(cumsum(ret))
  plot(eq)
  
  # Step 5: Evaluate strategy performance
  table.Drawdowns(ret, top=10)
  table.DownsideRisk(ret)
  charts.PerformanceSummary(ret)
  
  #########################################################################
  # welcher Return w?rde in R ab Zeitpunkt t gemacht, wenn ich einen maxdrawDown
  # von maxdd in pct hinzunehmen bereit w?r
  #########################################################################
  library(PerformanceAnalytics)
  
  t="2005"
  
  
  
  
  Return.excess(prices, Rf=0)
  
  cumprod(1+na.omit(R))-1
  
  ## Not run: 
  require(tseries)
  prices = as.xts(get.hist.quote("^GDAXI", start = "1999-01-01", quote = "AdjClose", compression = "d"))
  ## End(Not run)
  R = Return.calculate(prices, method="simple")
  
  tail(R)
  cumprod(R[-1]+1)-1
  Return.cumulative(R, geometric = T)
  
  plot(R)
  lines(R,col="green")
  lines(as.zoo(mR),col="red")
  class(R)
  head(mR)
  head(R)
  mR = mROC(as.xts(prices))
  
  str(R.IBM)
  R.IBM = as.xts(R.IBM)
  colnames(R.IBM)="IBM"
  
  x=chart.CumReturns(as.xts(R.IBM),legend.loc="topleft", main="Cumulative Daily Returns for IBM")
  chart.BarVaR(rR)
  
  chart.Drawdown(R)
  chart.VaRSensitivity(R.IBM)
  
  apply.rolling(mR, FUN="mean", width=36)
  
  chart.BarVaR(as.xts(mR), show.clean=TRUE, clean="boudt", lwd=2, methods="ModifiedVaR")
}
#GEMM(Dax)
#####################################################################################
# dispatcher T1-Modell gem. parameter mode
#####################################################################################

#portfolio.returns = weight %*% t(ia$hist.returns)  
#x = compute.drawdowns(portfolio.equity)

#for( i in 1:nrow(weight) ) {  
#  portfolio.equity = cumprod(1 + portfolio.returns[i,])


aTest<-function()
{
  #load.IFO()  #- schreibti die IFO.csv- Reihe
  ta5 <<- T2$new(PortfolioName = "ta5", visual = F ) 
  
  ######################################################################################
  # drawdown-analyse
  #######################################################################################
  
  dax=ta5$mydata$prices["2005::","Dax"]
  prices = dax
  
  undebug(goodReturn)
  goodReturn(prices=dax,  maxdd=5,t= "2009-08-01",visual=T)
  dax
  
  ######################################################################################
  # rolling-window - mit ZigZag-Studie
  #######################################################################################
  
  dat = "2007-01-01"
  for (i in seq(1:700))
  {
    dat = addTime(dat,1,"week")
    f=sprintf("::%s",dat)
    x=ZigZag(prices[f],change=10,percent =T)
    plot(prices[f])
    lines(x,col="blue",lwd=2)
    sag("klick",T)
  }
  
  ######################################################################################
  # die Positionen der ZigZag-Wende-Punkte
  #######################################################################################
  
  oldprices = prices
  prices=oldprices
  #prices=mNorm(prices["2005/2012"])
  thresh= 5  #zigzag-empfindlichkeit
  chartSeries(prices)
  addZigZag(prices[,c("High","Low")],change=thresh,percent =T) 
  
  #####################################################################################
  ################## rolling-window-zigzag-analysisi ##################################
  #####################################################################################
  dat0 = "2006-01-01"
  dat = "2007-01-01"
  dat="2012-01-01"
  step = "week"
  
  for (i in seq(1:700))
  {
    dat0 = addTime(dat0,1,step)
    dat = addTime(dat,1,step)
    f=sprintf("%s/%s",dat0,dat)
    prices = oldprices[f]
    prices=mNorm(prices)
    thresh= 15  #zigzag-empfindlichkeit
    x=na.omit(ZigZag(prices,change=thresh,percent =T,retrace=F))
    
    sig=as.vector(coredata(sign(x-lag(x))))  #segmente positiver und negativer steigung
    enc <-rle(sig)
    len(enc$lengths )# ist die Anzahl der Trades
    
    enc.endidx <- cumsum(enc$lengths)  #ending indices
    enc.startidx <- c(0, enc.endidx[1:(length(enc.endidx)-1)],length(prices))  # starting indices
    zzPoints = prices[enc.startidx]
    
    par(mfrow=c(1,1))
    plot(prices,main=sprintf("ZZ-Analysis %s",dat))
    lines(zzPoints,col="blue",lwd=2)
    
    y=prices
    x=time(prices)
    
    plot(x, y,type="l",main=dat,lwd=2);    grid()
    points(x,y)
    abline(lm(y ~ x), lty = 3, col = "blue")
    Span=0.07
    points(loess.smooth(x, y,span=Span, control = loess.control(surface = "direct")), lty = 6, col = "red",lwd=2)
    lines(loess.smooth(x, y,span=Span, control = loess.control(surface = "direct")), lty = 6, col = "blue",lwd=2)
    lines(lowess(x, y,f=Span), lty = 6, col = "green",lwd=2)
    
    
    Span=0.3
    points(loess.smooth(x, y,span=Span, control = loess.control(surface = "direct"),method="model.frame"), lty = 6, col = "yellow",lwd=2)
    lines(loess.smooth(x, y,span=Span, control = loess.control(surface = "direct")), lty = 6, col = "blue",lwd=2)
    lines(lowess(x, y,f=Span), lty = 6, col = "green",lwd=2)
    
    points(zoo(zzPoints),col="magenta",lwd=4)
    lines(zoo(zzPoints),col="magenta")
    sag("wart",T)
    
    #  plot(prices)
    #  holt()
    #  lines(as.xts(HoltWinters(as.ts(prices),gamma=F,beta=F)$fitted),col="red")
    #markiere die higss- und lows- des zigzag in unterschiedlichen farben
    highx = na.omit(enc.endidx[enc$values > 0 ]) 
    highs = prices[highx] 
    
    
    lowx = na.omit(enc.endidx[enc$values < 0 ]) 
    lows = prices[lowx] 
    
    lines(na.omit(Highs),col="red",lwd=2)
    lines(na.omit(Lows), col="green",lwd=2)
    
    points(highs,col="red",lwd=2)  
    points(lows,col="green",lwd=2)
    
    lmHigh=lm(highs~index(highs))
    lmHigh$coefficients
    plot(lmHigh)
    
    #############<<<<<<<<<####################################################
    #
    len(zzPoints)
    #prices=dax
    ##### k?nnen die zzPoints aus den Preisen erkl?rt werden
    len(prices)
    zzPoints2 = prices; zzPoints2[,1]=NA; zzPoints2=merge(zzPoints2,zzPoints)[,2]
    ln1 = lm(zzPoints2 ~ prices)
    summary(ln1)
    predict(ln1)[1:5]
    ###########################################################
    
    #k?nnen die Highs aus den  preisen erkl?rt werden ?    
    len(Highs);len(zzPoints)
    Highs=prices;  Highs[,1]=NA;   Highs = merge(Highs,highs)[,2]
    Lows= prices ; Lows[,1]=NA;    Lows = merge(Lows,lows)[,2]
    ln2 = lm(Highs ~ prices )
    summary(ln2)
    predict(ln2)[1:5]
    ############################################################
    
    Highs=zzPoints;  Highs[,1]=NA;   Highs = merge(Highs,highs)[,2]
    Lows= zzPoints ; Lows[,1]=NA;    Lows = merge(Lows,lows)[,2]
    
    
    lmHighZ=lm(Highs~zzPoints)
    summary(lmHighZ)
    
    lmLowZ=lm(zzPoints~Lows)
    summary(lmLowZ)
    lmHighLowZ=lm(zzPoints~ Highs+Lows)
    summary(lmHighLowZ)
    len(prices)
    len(zzPoints)
    
    zFac=len(prices) /len(zzPoints)#eine funktion von thresh
    
    histogram(coredata(highs),nint=15)
    histogram(coredata(lows),nint=15)
    histogram(coredata(zzPoints),nint=15)
    histogram(coredata(prices),nint=15)
    
    ##################################################################################
    # def seitw?rtsbewegung  - zur generierung von trainignsdaten f?r die Indikatioren
    ##################################################################################
    # wenn der abstand zweier highs ht und ht-1  zueinander geringer ist als der Abstand 
    # ht-lowt  
    dhigh = mROC(highs)*100 
    dlow = mROC(lows)*100
    dzz = mROC(zzPoints)*100 
    
    histogram(coredata(dhigh),nint=10)
    histogram(coredata(dlow),nint=nrow(dlow))
    histogram(coredata(dzz),nint=10)
    #zum Vergleich 
    
    mi=cbind(prices,prices) ; mi[,1:2]=0
    for(i in  1:nrow(dhigh))
    { 
      t =time(dhigh)[i]
      #t="2007-06-01"
      #  mP("%s %f %f ",t , dhigh[i], dzz[t])
      #    v=abs ( dzz[t,1]) - abs(dhigh[t,1])
      v= sign(dhigh[t,1])  ##/ abs ( dzz[t,1])  #kleine Werte heisse:   horizontalbewegung
      #sag(sprintf("%s %f",t,v) ,T)
      if(length(v)<1) v=NA
      mi[t,1] =  as.numeric(v)    
      mi[t,2] =  "H"
    }
    for(i in  1:nrow(dlow))
    { 
      t =time(dlow)[i]
      #t="2007-06-01"
      # mP("%s %f %f ",t , dlow[i], dzz[t])
      #   v=abs ( dzz[t,1]) - abs(dhigh[t,1])
      v= sign(dlow[t,1])  ##/ abs ( dzz[t,1])  #kleine Werte heisse:   horizontalbewegung
      #sag(sprintf("%s %f",t,v) ,T)
      if(length(v)<1) v=NA
      mi[t,1] =  as.numeric(v)
      mi[t,2] = "L"
    }
    
    Mi = mi[mi[,2] != "0"]
    
    
    #verleiche immer ein HL-Paar und schau ob du eine dispari?t findest:
    #homogen wenn:   wenn Hz steigt, steigt auch Lz - 
    # auch interessant:  laufen beide in die gleiche Richtung wie bisher ?
    #alle Mi-Punkte wo sich Mi von Mi-1 unterscheidet - also alle Disparit?spunkte
    dispari = Mi [ Mi[,1] != lag(Mi[,1] )]    #Mi[,2]=="H" &&
    dispari[dispari[,2]=="L"]
    
    len(Mi);len(dispari)
    Mi
    dispari
    #checke von den Betr?gen (dl/dh ) ob es sich um eine ernsthafte dispari?t hanbdelt - oder 
    #filter gleich alle raus wo abs(dhigh) und abs(lag(dlow)) in summe sehr klein sind
    #evtl. sind diese dispari dann Kr?mmungsindikatoren und taugen als trend-ende -/abfang Indikatoren
    
    
    #############  resistance-Stellen - sind solche wo die linreg- durch fast horizontal ist 
    # ein hohes R2 herrscht (also die werte sehr eng am resistor liegen)
    ####  resitance-lines werden-nach identifikation oft noch mal getestet - und wenn sie dann halten
    # fungieren sie als reflektor.
    
    
    if (F)
      mi=  as.xts(sapply(time(dhigh),FUN=function(t){ 
        v=abs( dzz[t]) - abs(dhigh[t])
        if (length(v)<1)v = NA
        return(v)}), order.by= time(dhigh))
    
    #TODO   hohe Werte des mi-Indikators sprechen f?r eine Seitw?rtsbewegung
    
    #TODO Trading-Strategie:
    #Kr?mmungsindikator:    ,,,,,,,,,,,
    #Der Trend ist intakt so lange das high ?ber dem letzen High liegt && das Low ?ber dem lezten Low
    #wenn eins von beiden nicht mehr stimmt:  Ausstieg (damit ist das lezte Low zugleich trailing-Stop)
    #TODo  Widerstandsakkumulatoren
    
    par(new=TRUE)
    
    plot(mi,main=NA,ylim=range(na.omit(mi)))
    #lines(scaleTo(mi,range(prices)),col="purple")
    
    sag("klick",T)
  }
  
  
  
  mi[mi !=0]
  
  #Target-Segmentierer d?rfen auch nach vorne schauen !!!
  
  
  
  plot(mi)
  sum(mi)
  dhigh
  TTR
  
  ################## abklappern der segmente .. z.B. f?r linReg 
  ###### wenn bei der summer der linreg-Segmente R2 zu schlecht wird, muss  thres um einen punkt verringert
  #werden ....
  # --> neuer Test -... so lange bis passendes  thresh (Aufl?sung der ZigZag- gefunden wurde) ###
  ################################################################################################
  
  clos=prices
  for (i in 1:len(enc$lengths))
  {
    print (i)
    i=15
    starti = enc.startidx[i]
    endi = enc.endidx[i]
    tlen = endi-starti
    startTrade = index(clos)[starti]    
    endTrade = index(clos)[endi]
    pos = enc$values[i]
    dret=mROC(clos[starti:endi])
  }
  
  ############################## IFO DATEN ############################################
  
  ta5
  ifo=ta5$mydata$prices["2005::","IFO"]
  
  ifom = to.monthly(ifo)[,1]
  plot(ifom)
  ifom= ifom-min(ifom)+1
  
  plot(mNorm(ifom))
  
  
  plot(mNorm2(ifom))
  difom=mRendite(mROC(ifom))
  plot(difom)
  head(ifo)
  
  ####################################################################################
  
  
  MplotNormedPrices(ta5$ret)
  
  ifo=mNorm(ta5$mydata$prices["2005::","IFO"])  
  rex=mNorm(ta5$mydata$prices["2005::","Rex"])
  dax = mNorm(ta5$mydata$prices["2005::","Dax"])
  sg2r= mNorm(ta5$mydata$prices["2005::","sg2r"])
  sv2r= mNorm(ta5$mydata$prices["2005::","sv2r"])
  usdeur = mNorm(ta5$mydata$prices["2005::","USDEUR"])
  
  mPlot(mNorm(ta5$mydata$prices))
  mPlot(dax,rex,sg2r,ifo,usdeur)
  mPlot(dax,rex,sg2r)
  
  difo=mROC(ifo)
  
  ddax=mROC(dax)
  drex=mROC(rex)
  drex["2005-01"]
  
  signal=lag(SMA(mROC(dax),20)>SMA(mROC(rex),20))
  g=guv(pRet=ddax,pBenchRet=drex,signal=signal,visible=T)
  plot(mRendite(drex))
  
  mPlot(dax,rex, signal=lag(SMA(mROC(dax),20)>SMA(mROC(rex),20))) 
  mPlot(dax,rex, signal=signal)
  
  #ifo plot 
  #ifo=ta5$getOrgData("IFO",visual =F)["2002::","ifo.Low"]
  
  plot(ifo)
  
  #dax =mNorm (Cl(ta5$mydata[["Dax"]]))
  #ddax = mROC(Cl(ta5$mydata[["Dax"]]))
  ddax = mROC(dax)
  ylim=range(ifo,dax)
  plot( dax,ylim=ylim)
  lines(ifo,col="green")
  
  difom = to.monthly( difo)[,1] #original - Reihe
  Difom=data.frame(difom)
  head(difom)
  visual=F
  opt = data.frame(cbind(i=0,sharpe=0))
  
  
  for (i in 1:50)
  {
    i=1
    signal =na.omit(lag(iif(SMA(sign(difom),i)>0,1,0)  ))
    #falls der ifo am Monatsersten schon kommt, kann man ohne lag arbeiten - dann mit i=2 und besserem Ergebnis
    i=2
    signal =na.omit(iif(SMA(sign(difom),i)>0,1,0)  )
    
    #signal =iif(SMA(sign(difom),i)>=2/i,1,0)
    #signal =sign(iif(SMA(difom,i)>0,1,0))
    
    signal=mto.daily(signal)
    #head(signal)
    guv1= na.omit(merge(ddax,signal))
    guv1=cbind(guv1,ddax*signal)
    
    colnames(guv1)=c("ddax","ifoSignal","guv")
    #head(guv1,50)
    ret = cumsum(guv1)
    
    if (visual)
    {
      mPlot(guv1)
      lines(mNorm(dax))   
      plot( zoo(ret))
    }
    sh=sharpe (as.ts(na.omit( ret[,3])))
    cat( i, "  ",sh)
    rr=c(i=i,sharpe=sh)
    opt=rbind(opt, rr)
  }
  #i=2 ist der beste Wert 
  
  max(opt[,2])
  
  GuVr = mRendite(na.omit(guv1))
  
  guv( ddax, difo,signal,NULL,visible=T,indi=NULL)
  
  len(ddax)
  len(signal)
  #iif( SMA(mROC(ifo),60)> 0,1,0)
  x=mROC(ifo)
  X=data.frame(x)
  SMA(na.omit(x))
  head(mROC(ifo))
  ta5$show()
  ta5$bench
  
  #global_ParTable=NULL  #l?sche das Trainingsged?chtnis
  global_StartDate = 1
  
  heute=Sys.Date()
  heute = fromTo(ta5$mydata$prices)[2]
  heute=as.Date(heute)-2
  ta5$update(heute) #schreibt auch schon mal in den global_ParTable und liefert damit dem TrainIndicator via mlist() notwendige Startwerte
  global_ParTable
  global_StartDate
  #trace(TrainIndicator)
  
  TrainIndicator(heute)
  #trace(mlist)
  global_ParTable
  
  ls(ta5$member)
  ls(ta5$mydata)
  
  head(ta5$mydata[["IFO"]])
  
  x=ta5$getData("IFO",visual =T)
  x=ta5$getOrgData("IFO",visual =F)["ifo.Low"]
  plot(x)
  head(x)
  Ti<<-ta5$member[["IFO"]]
  str(Ti)
  
  Titem = Ti$item
  head(Titem$prices)
  data<<-ta5$mydata
  Ti=gTi; ret = gret;data = gdata
  Ti$name
  
}


###########################################################
# transformiert einen mlist()-Parameter in eine Arg-Vector f?r DEoptim
# ml ist eine Liste von listen/vektoren
#par2Vec gibt einen vector zur?ck der jeweils das erste Element 
#dieser listen enth?lt 
#das Gegenteil von mkArgList()
###########################################################
par2Vec<-function(ml,n=1)
{
  r= sapply(ml,FUN=function(x)as.double(x[n]))
  
  return( as.vector(r))
}
#####################################################################################
# Rekursion:     Portfolios als t1-Objekte:
#  Baue aus der guv-Rendite-Kurve eine t1-Zeitreihe
#####################################################################################

dataFrameOfGuv<-function(Ti)
{
  cat("\ndataFrameOfGuv")
  guvDf= data.frame(matrix(nrow=1, ncol=4))
  #TEST
  print("muss evtl.  Ti$Name heissen !!! ") 
  browser()
  tn =Ti$Name
  colnames(guvDf)=   c( sprintf("%s.Open",tn),sprintf("%s.High",tn),sprintf("%s.Low",tn),sprintf("%s.Close",tn))
  return(guvDf)
}

#debug(Trade1)
#####################################################################################
# Rufe die Indicatoren f?r Trend, Swing, Switch und das TrainlingStop-System
######################################################################################
#BUG: Dax in RenditePlus hat gar kein TrendModell !!!!

Trade1<-function(Ti, Ttype="T1", frame="",data,ret)
{
  #browser()
  #cprices sind Preise
  gdata<<-data
  gret<<-ret
  gTi<<-Ti
  
  #Ti=Ti_$item
  name = Ti$name
  clos = getCol(data$prices, name)
  if (length(clos) == 0)
  {
    cat("\nTrade1 of ",name," scip  because no price is given" )
    return("scipped")
  }
  
  #global_StartDate<<-fromTo(clos)[1]
  
  global_objectId <<- paste("TREND",name,Ti$t1Par$TrendIndi) #versuch eines unique names
  global_Ti <<-Ti
  
  arg =  list( name = Ti$name, bench=Ti$bench, Ti= Ti, clos=clos, dat=data, dclos=ret) #mal ein vollst?ndiges environment
  global_arg <<-arg
  
  ########### update des trend-Models #############
  
  trendIndi = sprintf("indi.%s(arg)",Ti$t1Par$TrendIndi)  
  
  mP("Trade1# update des trend-Models: %s ",trendIndi)
  #browser()
  if (toString(Ti$t1Par$TrendIndi)=="NA")
    mP("####### No TrendModel defined #####")  
  else    
    eval(parse(text=trendIndi)) 
  ########### update des seitw?rts-Models #############  
  swingIndi = sprintf("indi.%s(arg)",Ti$t1Par$SwingIndi)
  ########### update des RegimeSwitch-Models #############   
  tsswitch  = sprintf("indi.%s(arg)",Ti$t1Par$TsSwitch)
  
  
  #t1=switch(model,
  #          buyhold=  c(Cgar= last(cprices,1), Ret=mReturn(cprices)),
  #          meanreverting = t1_meanreverting(cprices,r,type, params)           
  #          )
  
  
  # Trade1.Plot(cprices, t1,model)
  #RET<<-data.frame(t1$Ret)
  #SIGNAL<<-data.frame(t1$Sig)
  #cat("\n  Trade:  ",name," Cgar ", t1$Cgar)
  return(arg)
}

#undebug(mlist)
######################################################################################
#  Indikator Parameter trainieren
#
#setzt voraus dass definiert sind:
#global_objectId," ",global_StartDate)
#und dass bereits ein parameter-set im global_ParTable liegt (der dann mit mlist()  abgerufen wird)
# also nur, dass schon mal ein normaler lauf stattgefunden hat 
#kann kann er die namen der Parameter dem globa_ParTable entnehmen und mit
#mkArgList daraus eine  vector->argList - Transformation machen 
#und damit kann train.Indicator als generische wrapper f?r DEoptim eingesetzt werden
#welches nur Funktionen optimieren kann, deren argumente als vector ?bergeben werden
######################################################################################


#undebug(mlist) 
#undebug(indi.Omega)
#indi.Omega(arg=c(3,3,9))
#####################################################################################
# vector->argList
#das Gegenteil von par2Vec
#####################################################################################

mkArgList <-function(parvec)
{
  parvec = unlist(parvec)
  #  print("mkArgList") 
  s="r1=list("
  i=0
  for (ai in unlist(global_Args)) #die Namen der ini-Parameter-Variablen
  { 
    i=i+1
    if (i > 1) s=paste(s,"",sep=",")
    
    s <- tryCatch({
      res = sprintf( "%s %s=%f",s,ai, parvec[i])   #round()  die von DEoptim gelieferten vector-werte f?r die parameter
      # << #####################
    }, error = function(err) {
      
      mP("Bug at mkArgList")
      browser()
      return(NULL)     }
                  ,finally =function()
                    return(res))
    
    
  }   #TODO  ich mach hier immer  round() obwohl DEOptim  real-zahlen liefert...
  s=paste(s,")")
  
  eval(parse(text=s))   #expression(r1=list( wShort=30.000000, wShort=160.000000 ))
  #browser()
  #print(s)
  return(r1)
  return(list(width=parvec[1], minLevel=parvec[2]))
}
######################################################################################
#setzt voraus dass definiert sind:
#global_objectId," ",global_StartDate))
# ist dann ein generischer Aufruf eines bliebigen Indikators-Parametersatzes
#das ist die Wrapper Funktion f�r jeden Optimierer die parameter nimmt,  ein Workhorse aufruft und einen G�teparameter zur�ckgibt
######################################################################################
train.Indicator_<-function (parvec)
{
  par=mkArgList(parvec)
  
  
  #TODO  um overfitting zu vermeiden (eigentlich ist das ein regions-mittelwert um einen parameter-punkt)
  #TODO wahl ob ?ber viele aktien gleichzeitig gefittet wird ...
  #TODO wahl des Train-Zeitraums -
  #TODO ob  mehrfach - ?ber unterschiedliche Start-Zeiten im Trainings-Zeitraum gefittet werden soll
  
  #sma.short = bt.apply.matrix(prices, SMA, 50)  und dann die mean von ret zur?ckgeben
  
  #  TODO global_arg
  #  was mach ich hier ???
  #  str(global_arg)
  #  head(global_arg,1)
  
  # global_frame="1905-01-01/01-01-2011"
  #  (global_arg$dclos)["2006-01-01/2011-01-01"] 
  
  #ret=indi.MACD(global_arg, par )
  #generisch machen--
  #browser() 
  
  si= strfind(global_indiName,"signal.")
  if (len(si)>0)
    cmd=sprintf("ret=(indi.Generic('%s',global_arg,par))",global_indiName) #, TRAINSYM=1
  else
    cmd=sprintf("ret=(%s(global_arg,par))",global_indiName)
  
  eval(parse( text=cmd))
  
  #mP("train.indicator()")
  #browser()
  
  if (len(ret)>1)
    ret = as.double(ret$Tquality)
  else
    ret = as.double(ret)
  
  
  if (ret > maxRet)
  {
    maxRet<<-ret
    bestPars <<-par
  }
  
  #browser()
  # DEoptim sucht MINIMA (nicht Maxima) .. drum  minus !
  return(-ret)
}

train.Indicator<-cmpfun(train.Indicator_) #compilier das Teil


######################################################################################
######################################################################################

indi.BuyHold<-function(  arg,  par=list(),visual = F,main="")
{
  dclos=arg$dclos
  
  print("############## indi.BuyHold #############")
  
  signal = rep(1,len(dclos))
  indicator=BuyHold<-signal
  
  return(indi.finish(signal,arg$clos,indi="indi.BuyHold",visual=visual, Indi=list(),main=main))
  
}
######################################################################################
######################################################################################
if (F)
  ta5$update()

#####################################################################################
#t1-Trading von mean-revertern
#####################################################################################
t1_meanreverting<-function(cprices, r,type, params)
{
  # Mean-Reversion(MR) strategy - mit RSI
  
  rsi2 = bt.apply.matrix(cprices, RSI, 2)
  dcp = mReturn(cprices)
  
  Signal =  iif(rsi2 < 50, 1, -1)
  #  Signal =  iif( rsi2 <50 , -1, -1)
  #Signal[,1]=rep(-1, nrow(Signal))
  
  ret  =    cumsum(na.omit(Lag(Signal,1)) * dcp)
  #ret = cumsum(-1*dcp)
  t1 =list(Cgar= last(ret,1), Ret=ret, Sig = Signal)
  
  return(t1)
}

#####################################################################################
#Trenderkennender Regime-Switcher 
# Modelle die ihn subscriben schaltet er aus - und erh?lt als Return die gleichgewichtete
#Summe der Subscriber-Modelle 
#type1 arbeitet mit der Vola als Detektor
#####################################################################################

t2_regimeSwitch<-function(cprices, r,type, params)
{
  ret.log = bt.apply.matrix(cprices, ROC, type='continuous')
  hist.vol = bt.apply.matrix(ret.log, runSD, n = 21)
  vol.rank = percent.rank(SMA(percent.rank(hist.vol, 252), 21), 250)
  
  # Regime Switching  Historical
  data$weight[] = NA
  data$weight[] = iif(vol.rank > 0.5, 
                      iif(rsi2 < 50, 1, -1),
                      iif(sma.short > sma.long, 1, -1)
  )
  
  
  t1 =list(Cgar= last(cumsum(cprices),1), Ret=cprices)
  print(str(t1))
  return(t1)
}

#####################################################################################
# aus sysinvestor
#####################################################################################

# Avoiding severe draw downs
# http://engineering-returns.com/2010/07/26/rotational-trading-system/
# Only trade the system when the index is either above the 200 MA or 30 MA


if (F)  ##### wonder
{
  slopes=diff(prices,20)
  
  zlem1= bt.apply.matrix((sign(slopes)), ZLEMA, n=2,ratio=0.9); # 4
  zlem2= bt.apply.matrix((sign(slopes)), ZLEMA, n=10,ratio=0.1); #6
  zlem3= bt.apply.matrix((sign(slopes)), ZLEMA, n=200); #6
  
  signal=iif(zlem1 >=0,1,0)
  signal= iif(abs(slopes)< 1,0,signal)
  plotSigPrice(signal=signal,prices=prices,indi=list(zlem,slopes))  
  
  mzlem=sys.Run(prices,signal,compare=T)
  
  
  strategy.performance.snapshoot(mzlem, T)
  plotbt.custom.report.part1(mzlem)       
  compareViewModels(list(mzlem=mzlem,mzlem2=mzlem2),prices,alloc=T)
  pdf_Report(models,experiment)
  
}
####################################################################################
if (F)
{
  data.Info(data)
  prices=data$prices["2001::",13]
  
  data$prices=data.info(data)
  prices = mNorm(data$prices[,c("Dax","Dow")])  #mNormCleaned()
  mchart(prices)
  global_Targets <<-compute.Targets(prices,0.16,0.05)
  
  frame="2008::2010"
  price = prices[frame,1]
  target = global_Targets[frame,1]
  
  plot(price)
  lines(price,col=(target+3),type="h")
  
  global_arg$clos= prices
  res=signal.wonder(global_arg,list( k=20, zlemaN=60),visual=T)   # 
  signals = res$Signal
}

####################################################################
# vergleiche global_Targets und signals miteinandner
# zum Tag today,    ema- gewichtet
# hiermit wird die G�te des signals durch eine Vergleich mit dem Soll-Target
# verglichen.
####################################################################
evalTargetQuality<-function(prices,signals,today = NULL)
{
  firstD = DateS(first(prices))
  if (is.null(today))
    today= as.Date(index(last((prices))))
  
  res=prices
  res[] = NA
  #f�r jedes sym in prices:
  
  for(sym in colnames(prices))
  {
    #sym= colnames(prices)[1]  #TEST
    m.ps= merge(global_Targets[,sym], signals[,sym])
    check = m.ps[sprintf("%s::%s",firstD,today)]
    #nun vergleiche die beiden spalten in check auf identische Werte
    
    #vergleiche ob der Wert von global_Targets mit dem von signal �bereinstimmt
    comp=iif(check[,1]==check[,2],1,0)
    res= prices[,sym];res[]=NA
    #z�hle die �bereinstimmungen der letzten winLen-Tage
    winLen = 10
    res[winLen:dim(res)[1],sym]=rollsumr(comp,k=winLen)
    #EMA-gewichtet...
    res[,sym]=EMA(res[,sym],n=winLen)
    
  }
  return(res)
}
if (F)
  evalTargetQuality(prices,res$Signal)
##################################################################################################################
# jedes trainierbare indi.<...>()-System endet mti return(indi.finish()).
# Dabei wird eine Liste aus GuV und Signal zur�ckgegeben.
# Somit kommuniziert indi.finish() mit dem Wrapper train.indicator()  der von TrainIndicator() gerufen im Opitimierungslauf
# gerufen wird.   indi.finish() kann mit plotSigPrices sehr gut ein Trading-System visualisieren.
# Ist die globale  global_xMarker mit einer Liste von Dat�mer gef�llt werden diese sogar als gr�ne Linien angezeigt.
###################################################################################################################


indi.finish<-function(signal,prices,indi="???",par=list(),visual=F,Indi=list(),main="")
{ 
  runN<<-runN+1
  sig <- signal
  res  = list()
  res$signal = signal
  if (!exists("global_TrainStyle"))
    global_TrainStyle<<-"GuV" #default-Wert
  if (!exists("global_xMarker"))
    global_xMarker<<- NULL
  
  #if (global_TrainStyle == "Target") 
  mP("indi.finish")
  if (dim(prices)[2]>1)
  {mP("wrong usage:  all indi.<...> methods are uni-variate")
   browser()
  }
  ret <- m.Run(prices,sig)
  nt=  numTrades(sig)$allT
  q= quality(ret)
  
  Transaktionskosten =nt/ncol(prices)/80
  ret[is.na(ret)]=first(ret[!is.na(ret)])
  
  S=compute.sharpe(ret)
  #Transaktionskosten =Transaktionskosten *10.0  #sonst viel zu hoch im optimizer
  mP("%s %s %d:   %d Trades- >q:%f =>%f || %f  ~%f~", indi, toString(par), runN,nt,q,Transaktionskosten,q-Transaktionskosten,S)
  
  #parameter-names im title
  p=sapply(names(mlist()),FUN=function(nam) {sprintf("%s=%s",nam,toString(first(mlist()[[nam]])))})
  title=paste(p,collapse=",")
  title = paste(main,title,sep=": ", toString(as.Date(index(last(prices)))))
  
  if (visual)    
    plotSigPrice(signal=signal,prices=prices,indi=Indi,xMarker=global_xMarker,main=title)  
  
  #compute.sharpe(mROC(prices))/compute.sharpe(ret)
  
  #browser()
  #return (compute.sharpe(ret))
  res$Tquality= q-Transaktionskosten 
  
  return(res )
}
#################################################################################################################

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~   MM_Entwicklung 28.5.2013
#Vorbereitung des Trainings
if (F)   #neues Trainings-Schema.  Das     indi.Generic() -> signal.<...>   -> sys.Run()  - Entwurfsmuster 
  #l�st das indi.<> -> indi.finish() Muster ab
{
  global_arg<<-list(clos=prices[,1:2])  #Definition der Preise
  global_ParTable <<-NULL  
  global_objectId <<-paste("TREND","Dax","signal.SMAzlema")   #Welcher Indikator 
  global_StartDate <<- DateS(last(prices))  #der zeitstempel- zusammen mit globla_objectId der joined key in global_ParTable
  #Parametrisierung des Trainings .. ich leg sogar die increment-Werte f�r den GRID selber fest
  
  mlist(smaN=c(20,10,100,10), zlemaN=c(10,10,90,5), mode="w")   #wenn ich die 
  #So sieht jetzt die global_ParTable aus:
  mlist(mode="R")
  global_ParTable$par
  global_ParTable
  
  #Training aller Zeitreihen durchf�hren  - bei TRAINSYM=0 - bekommen sie einen einheitlichen BestParams - sonjst findet
  #sich f�r jede zeitreihe ein individueller BestParam
  TrainIndicator (opti="GRID",indiName = "signal.SMAzlema",visual=T,TRAINSYM=-1)  
  #und das hat er gefunden:
  global_ParTable
  global_ParTable$par
  
  #Abrufen der Indikatoren mit ihren Bestparam - dannach wird das summensystem mit einem Buy-Hold verglichen
  x=indi.Generic("signal.SMAzlema", global_arg,visual=T, TRAINSYM=0)   #jeder mit gleichen BestParams
  x=indi.Generic("signal.SMAzlema", global_arg,visual=T, TRAINSYM=-1)  #jeder mit seinen eigenen BestParams
}
###########################

library(DEoptim)
#TODO: TimeFrame setzen
##################################################################################################################
#global_StartDate_ setzt einen cursor in die global_ParTable und zeigt damti auf den aktuellen 
#parametersatzt
# der TimeFrame liegt zeitlich vor diesem Datum (ich kann logisch nur daten trainieren die vorher lagen)
#global_objectId_ = "TREND sx5r MACD"
#################################################################################################################

TrainIndicator<-function(data=NULL, global_StartDate_=NULL, objectId_ = NULL, opti="noDEoptim", frame ="", indiType ="TREND", indiName="",visual=F, TRAINSYM=0)  
{
  
  if (!is.null(data) && (!exists("global_arg") || is.null(global_arg)))
    global_arg<<-list(clos=data.info(data,visual =F)[frame,],dat = data)  #Definition der Preise
  
  if (!exists("global_ParTable"))
    global_ParTable <<- NULL
  
  if (!is.null(global_StartDate_))
    global_StartDate<<-global_StartDate_
  
  
  if (!exists("global_StartDate") || is.null(global_StartDate) && len(global_arg$clos)>0)
    global_StartDate <<- DateS(last(global_arg$clos[train.frame])) 
  
  mP("TrainIndic")
  
  
  if (!is.null ( objectId_ ) )
    global_objectId <<- objectId_
  
  if (indiType != "") 
    global_objectId <<-paste(indiType,"Dax",indiName)
  
  
  if (!is.null ( frame ) )
    global_frame <<- frame
  else
    global_frame = paste("1905-01-01",global_StartDate,sep="/")
  
  maxRet <<- -1000  #ebenfalls eine globale
  
  print("######### TrainIndicator #########")
  print(global_ParTable)
  print(paste(global_objectId," ",global_StartDate)) #damit steht genau fest welcher Indicator optimiert werden soll
  
  #entnimm aus der global_objectId den Namen des zu optimierenden inidcators
  #und hinterleg ihn f?r  train.indicator() in global_indiName
  # TODO
  #global_indiName <<- "indi.MACD"
  
  merk_global_objectId = global_objectId
  
  merk_global_arg = global_arg
  merk_ml=mlist(mode="R")
  
  
  # browser()  #######
  
  if (is.null(global_ParTable) || len(merk_ml) ==0)
  {
    mP("TrainIndicator:  Sorry1 - You didn't write any par to global_ParTable, first call mlist(w)")
    this_arg = global_arg
    this_arg$clos = global_arg$clos[,1]
    
    indi.fn = match.fun(indiName) 
    indi.fn(this_arg)  #damit der signal.<> via seinem mlist()Aufruf seinen default-parameter nach global_ParTable schreibt.
    #indi.Generic(arg= this_arg, signal.fun=indiName,visual=F,TRAINSYM=1)
    #browser() 
    merk_ml=mlist(mode="R")
    
  }
  
  if (!exists("globalTrainLevel")) 
    globalTrainLevel<<-10
  
  if (!exists("global_commission"))
    global_commission <<- 0.00001
  
  if (TRAINSYM ==-1)
    TRAINSYM =pureColnames(global_arg$clos)   #Trainiere alle Zeitreihen, aber finde separate BestParams
  
  if (TRAINSYM != 0 && is.numeric(TRAINSYM) )   #trainiere nur eine ausgw�hlte Zeitreihe
  {
    TRAINSYM=pureColnames(global_arg$clos)[TRAINSYM]
  }
  
  #.....................................................................
  
  while (T)   #alle symbole trainieren  (Ausstieg via break - ganz unten)
  {
    
    if (TRAINSYM !=0)  #trainiere in einer  schleife viele Zeitreihen separat
    {
      mP("................. NEW sym: %s",TRAINSYM[1])
      #browser()
      
      global_arg$clos <<-merk_global_arg$clos[,TRAINSYM[1]]
      #global_arg$dat$symbolnames = TRAINSYM[1]
      # head(global_arg$clos)
      #erzeuge einen symbol-spezifischen  objectId
      goi =spl(merk_global_objectId,delim=" ")
      New_objectId = sprintf("%s %s %s",goi[1],TRAINSYM[1],goi[3])
      global_objectId <<- New_objectId
      if (len(mlist())==0)
        mlist(merk_ml,mode="w")  #kopiere den init-wert in die global_ParTable (unter neuem objectId)
      
    }
    else
    {
      TRAINSYM = "AllSymbols"
      #New_objectId = sprintf("TREND %s %s","AllSymbols",indiName)
      New_objectId <<-paste("TREND","AllSymbols",indiName)
      
      global_objectId <<- New_objectId
      
      if (len(mlist())==0)
        mlist(merk_ml,mode="w")  #kopiere den init-wert in die global_ParTable 
    }
    
    global_indiName <<- indiName
    
    ml=mlist(mode="R")
    #browser()    
    global_Args<<-attributes(ml) #macht die Parameter-Variablennamen f?r mkArgList() lesbar
    
    
    #res<-DEoptim(fn=train.Indicator,lower=c(-5,-5),upper=c(5,5),control=list(storepopfrom=1,itermax=10))
    #TODO:  wie sagt man DEoptim wenn Parameter  ganzzahlig sein m?sse  
    #global_defaultPar
    #browser()
    
    # ml= list(wShort=50 , wLong=200)
    
    #ml= list(wShort=c(50,30,70) , wLong=c(200,160,250))
    #Anzahl an Genen
    
    NumPart = length(ml)*10 #heuristik:  10 mal mehr in der population wie wir parameter haben
    #f?r jede Variable die untere und obere Grenze definieren 
    lower = par2Vec(ml,2)
    upper = par2Vec(ml,3)
    
    if (is.na (lower[1])) #es wurden keine min,max definiert:  ml= list(wShort=50 , wLong=200)
    {
      #definiere  die min,max automatisch als 60% und 140% des ml-wertes
      lower= sapply(ml,FUN=function(x,pct=60) x[1]*pct/100)
      upper= sapply(ml,FUN=function(x,pct=140) x[1]*pct/100)
    }
    
    
    #TODO   setze  intialpop auf den gegenw?rtigen Wert (startpunkt f?r den Optimierer .. damit er nicht zu viel ?ndert)
    #startvector aus bisherigem vector konstruiieren
    initPop = par2Vec(ml)
    #fuer jedes gen einen startvector
    pop=matrix(0,nrow=NumPart,ncol=length(upper))    
    
    #runif(10,5,6)
    #floor(10*runif(10))
    #ToDo  pop auf Zufalls-Wert um initPop setzen, dabei auch auf die Kanten gehen !!!
    
    for(i in 1:NumPart) pop[i,]= initPop;    #Starting guesses:  the last known-par-state
    #browser()
    
    ## optimiser vergleich :  http://cnr.lwlss.net/GlobOptR
    #integer optimizer:  http://stackoverflow.com/questions/3234935/non-linear-integer-programming
    #Rsolnp  http://rgm2.lab.nig.ac.jp/RGM2/func.php?rd_id=Rsolnp:solnp
    if (T)  #PRODUCTION    bevorzuge DEoptim #################################################
{
  #t1=switch(model,
  #          buyhold=  c(Cgar= last(cprices,1), Ret=mReturn(cprices)),
  #          meanreverting = t1_meanreverting(cprices,r,type, params)           
  #          )
  
  if (opti=="DEoptim") #...............................................................................................
  { 
    control=list(itermax=200,F=2, steptol=10, reltol=0.1, NP=NumPart,trace=1)
    r<-DEoptim(fn=train.Indicator, lower=lower, upper=upper, control)
    bestArg =mkArgList(r$optim$bestmem)
    
    plot(r, type = 'b')
    plot(r, plot.type = "bestvalit", type = 'l')
    
  }
  if (opti=="GRID")    #...............................................................................................
  {
    #browser()
    if(exists("runs") )  
      mP("Expect time for %d runs ",runs)
    
    if (is.null(global_ParTable) || len(ml) ==0)
    {
      mP("TrainIndicator:  Sorry - You didn't write any par to global_ParTable, first call mlist(w)")
      browser()  
      indi.Generic(arg= global_arg, signal.fun=indiName,visual=F,TRAINSYM=1)
      ml= mlist("R")
      
    }
    #  browser()
    if (len(ml[[1]]) > 3)  #in der mlist() wurden auch increment -Werte �bergeben - also kann man eine level-list bauen:
    { 
      #ml= mlist(smaN=c(20,20,100,3), zlemaN=c(10,10,90,5), mode="w")
      
      #lev=list(seq(10,100,10),  seq(2,30,2),1:2)
      #runs = len(combine2(combine2(seq(10,100,10), seq(2,30,2)),1:12))
      
      #global_FastTrain=5
      #ich kann das Training gr�ber oder feiner gestalten indem ich die Variable
      #global_FastTrain > 0 setzte. dies ist dann die Anzahl der Zwischenschritte pro Dimension
      
      lev=lapply(ml,function(x) 
      { 
        von=x[2]; bis=x[3]; inc=x[4] 
        if (exists("global_FastTrain") && global_FastTrain > 0 )
          inc=(bis-von)/global_FastTrain
        #browser()
        seq(von,bis,inc)
      }  )  
      ores <<- gridSearch(train.Indicator, levels=lev)
    }
    else
      ores <<- gridSearch(train.Indicator, lower=lower, upper=upper, npar=length(ml),n=globalTrainLevel)
    #MM1
    ovalues<<-ores$values[is.finite(ores$values)]
    
    #browser()
    if (visual) plot(ovalues,main=TRAINSYM[1]) #...........
    
    besti=which.min(ovalues)  #Minima suchen
    
    best=ores$values[besti]
    bestArgs = unlist(ores$levels[besti])
    
    mP("#########################BestVal %f",best)
    print(bestArgs)
    bestArg =mkArgList(bestArgs)
    
  }
  else
  {
    r <- genoud(starting.values= initPop, fn=train.Indicator, nvars=length(upper), max=FALSE,pop.size=NumPart,
                max.generations =200,data.type.int=T, boundary.enforcement  = T,
                Domains=cbind(lower,upper))
    
    bestArg =mkArgList(r$par)
  }
}
    else  ################## teste einige optimierer
    {    
      library(Rsolnp)    
      sag("Y0 solnp:",T)
      #der kann auch noch constrains verkraften 
      Y0 <<-solnp(initPop, fun = train.Indicator, LB=lower,UB=upper )
      print (Y0)
      sag("Y0 optim L-BFGS-B:",T)
      #der klassische gradienten-sucher
      Y1 <<- optim( par = initPop, fn=train.Indicator, method="L-BFGS-B", lower=lower, upper=upper)
      print (Y1)
      print("\nOptim -BFGS-->")
      #  r=optim(runif(2,20,220),fn=train.Indicator, method="L-BFGS-B",control=list(maxit=200))
      #r=optim(runif(2,20,220), fn=train.Indicator, NULL, method = "L-BFGS-B",
      #   lower=rep(20, 60), upper=rep(90, 220),control=list(maxit=2000)) # par[24] is *not* at boundary
      
      Y1b <- optim(par=initPop, fn=train.Indicator, method="BFGS",      control=list(maxit=4000))
      print (Y1b)
      
      #$par    [1] 69.09038 79.97485    $value    [1] -1.327095  
      sag("nlminb:",T)
      Y2 <<- nlminb(start=initPop, obj=train.Indicator, lower=lower, upper=upper)
      print (Y2)
      #$par [1] 69.09038 79.97485     $objective     [1] -1.327095
      #mischung aus newton und genetic, kann auch ganzahlige variable mit data.type.int=TRUE
      # http://sekhon.berkeley.edu/rgenoud/genoud.html  tip: http://stackoverflow.com/questions/3234935/non-linear-integer-programming
      # kann auch multicore !
      sag("genoud:",T)
      
      library(rgenoud)
      Y3 <<- genoud(starting.values= initPop, fn=train.Indicator, nvars=length(upper), max=FALSE,pop.size=NumPart,
                    max.generations =200,data.type.int=T, boundary.enforcement  = T,
                    Domains=cbind(lower,upper))
      print (Y3)
      #Solution Fitness Value: -1.327095e+000
      #Parameters at the Solution:
      #X[ 1] :  6.900000e+001
      #X[ 2] :  8.000000e+001
      
      
      #DEoptim mit reltol und steptol so parametrisieren dass es auf?rt wenn sich nichts mehr tut
      # steptol ist etwa die mindest-iterations-anzahl - reltol sagt ab welcher dif ergebnisse als unver?ndert gelten f?r fr?her abbruch nach mindestens steptol schritten
      #TODO:  teste  verschiedene strategy [1..6] Werte
      #initialpop = pop,
      #initPop = c(50,180)
      sag("DEoptim:",T)
      control=list(itermax=200,F=2, steptol=10, reltol=0.1, NP=NumPart,trace=1)
      Y4 <<- r<-DEoptim(fn=train.Indicator, lower=lower, upper=upper, control)
      #  best member   :  68.93617 79.72697  best value -1.3271
      summary(Y4)
      wait()
      #par(mfrow = c(2,1))
      plot(r, type = 'b')
      plot(r, plot.type = "bestvalit", type = 'l')
      
      print ("############## ml ")
      print (ml)
      
      
    } ###################### TEST-Ende
    
    cat("\nbest vals: ",maxRet, " at \n")
    print(bestPars)
    
    # ausw?hlen und abspeichern des besten wertes 
    ########################## ?berschreiben im global_ParTable mit neu gefundenem Wert
    #l=portfolioTicks("RenditePlus")$Name
    #l1=l[-which(l=="EUR")]
    #Bookkeeping:   gibst den Eintrag schon, 
    
    #browser()  #MM2  PROBLEM    bestArg ist noch nicht im richtigen Format
    # .. evtl. sollte der Eintrag auch nicht entfernt sondern nur gepatched werden !!
    #den eintrag in dei global_ParTable mit mlist() vornehmen
    
    aktuell=mlist(mode="R")
    newPar = aktuell
    cat("#################################################################################")
    cat("\n TrainIndicator - found bestArg: ")
    cat("#################################################################################")
    # mP(" post  mlist w")
    #browser()
    #patch die neuen Werte rein, ohne die optimierungs-parameter zu ver�ndern
    for (pars in ls(bestArg))
    {
      newPar[[pars]][1]=as.double(bestArg[[pars]] ) 
    }
    
    mlist(newPar,mode="w")
    
    mP(" post  mlist w")
    #global_ParTable
    #browser()
    
    if (visual)  
      train.Indicator(parvec=par2Vec(mlist(),1))
    
    #mP("+++~~~~~~++++")
    #browser()
    
    if (  TRAINSYM ==0)
      break;
    if (len(TRAINSYM)==1)  #letzte Zeitreihe wurde trainiert
      break;
    
    TRAINSYM = TRAINSYM[-1]  #erstes Symbol abschneiden
    
    #global_arg$clos <<-merk_global_arg$clos 
  } ##while ... evtl. nachste Zeitreihe, falls die prices separat trainiert werden sollen.
  #mlist(mode="R")
  
  if (TRAINSYM !=0)
  {
    global_arg<<-merk_global_arg #wieder  zur�cksetzen
    global_objectId <<- merk_global_objectId
    
  }
  return (newPar)
}  


if (F)
{
  TrainIndicator()
  #mtrace(train.Indicator)
  train.Indicator(c(32.7, 113),"indi.ZlemaDif")
}
#MM_GENERIC
#####################################################################################
##########################################################
#sys.Run() ein super leichtes PM-System: f�r Timing-Modelle(signal gegeben) ret=  prices*Signal f�r viele #MMA
#Aktienin den Prices+Signal-Spalten gleichzeitig
#Sysinvestor sei Dank
#prices und signal d�rfen multidimensional sein
#dies  ersetzt die indi.finish()- funktion f�r die signal.<...>  Systeme die ja alle mit indi.generic()
#laufen und dank sys.Run() multi-asset-tauglich sind.
#wenn experiment != "" wird intensiv reported (xls+pdf)
##########################################################
  
  #####################################################################################
  signal.wonder<-function(arg, par = mlist( k=c(20,10,40), zlemaN=c(20,10,40)),visual=F,...)
  {
    slopes=diff(arg$clos,as.integer(par$k))
    zlem= bt.apply.matrix((sign(slopes)), ZLEMA, n=as.integer(par$zlemaN))#,ratio=0.1) #6
    signal=iif(zlem >=0,1,-1)
    
    return(list(Signal=signal, Indi=list(zlem)))
  }
  
  if (F)
  {  
    global_ParTable=NULL
    clos=prices[,2:2]
    colnames(clos)
    HotLags(clos,n=20,visual=T)
    
    global_arg = list(clos=clos)
    global_arg<<-list(clos=data.info(data),dat=data)  #MANDATORY !!!!!
    global_commission = 0.00001   #sys.Run() nimmt diese commission !!!!
    
    global_ParTable <<-NULL
    #global_objectId <<-paste("TREND","DAX","signal.SMAzlema")
    globalTrainLevel <<-10
    
    res=signal.wonder(global_arg)   # DOW: 10,150
    res=signal.wonder(global_arg,list( k=10, zlemaN=150),visual=T)   # DOW: 10,150
    res=signal.wonder(global_arg,list( k=76, zlemaN=2),visual=T)   # DOW: 10,150
    
    res=signal.wonder(global_arg,list( k=10, zlemaN=210),visual=T)   # Dax:   10,  210  und  154, 4
    res=signal.wonder(global_arg,list( k=154, zlemaN=4),visual=T) 
    
    #das ganze mit chart und Auswertung
    x=indi.Generic("signal.wonder", global_arg, list( k=154, zlemaN=4), visual=T, TRAINSYM=0)   #jeder mit gleichen BestParams
    x=indi.Generic("signal.wonder", global_arg,list( k=154, zlemaN=4), visual=T, TRAINSYM="DAX")  
    x=indi.Generic("signal.wonder", global_arg,list( k=154, zlemaN=4), visual=T, TRAINSYM=-1)  
    
  }
  
  if (F)
  {
    ###########################  TRAINING !!! 
    test.system = "signal.wonder"
    global_arg<<-list(clos=prices[,1:2])  #Definition der Preise
    global_ParTable <<-NULL  
    global_objectId <<-paste("TREND","Dax",test.system)   #Welcher Indikator 
    global_StartDate <<- DateS(last(prices))  #der zeitstempel- zusammen mit globla_objectId der joined key in global_ParTable
    #Parametrisierung des Trainings .. ich leg sogar die increment-Werte f�r den GRID selber fest
    
    mlist( k=c(20,10,30,2), zlemaN=c(20,10,150,10))
    #So sieht jetzt die global_ParTable aus:
    mlist(mode="R")
    global_ParTable$par
    global_ParTable
    
    #Training aller Zeitreihen durchf�hren  - bei TRAINSYM=0 - bekommen sie einen einheitlichen BestParams - sonjst findet
    #sich f�r jede zeitreihe ein individueller BestParam
    TrainIndicator (opti="GRID",indiName = test.system,visual=T,TRAINSYM=0)  #ein Bestparam f�r alle wertpapiere  
    TrainIndicator (opti="GRID",indiName = test.system,visual=T,TRAINSYM=-1)  
    #und das hat er gefunden:
    global_ParTable
    global_ParTable$par
    
    #Abrufen der Indikatoren mit ihren Bestparam - dannach wird das summensystem mit einem Buy-Hold verglichen
    x=indi.Generic(test.system, global_arg,visual=T, TRAINSYM=0)   #jeder mit gleichen BestParams
    x=indi.Generic(test.system, global_arg,visual=T, TRAINSYM=-1)  #jeder mit seinen eigenen BestParams
    
    
    ###########################
    
  }
  ####################################################################################
  #Betrachte die ROC-Differenzen auf f�r Differenzen die den 10 wichtigsten HotLags
  #entsprechen und handle in Richtung der gewichteten momentum-Summe dieser Differenzen.
  #sehr viele Trades.
  #FAZIT:  f�r Dax und Dow l��t sich jeweils ein anderer Parameter-Satz finden der bei
  #hf-trading (ca 4 Tage Haltedauer) gut aussieht - aber eben KEIN gemeinsamer SATZ.
  
  ####################################################################################
  signal.hotLags<-function(arg, par = mlist(zlemaN=c(20,10,40,10)),visual=F,...)
  {
    symi=1   #w�hle hier, welches Sympol des xts-pakets du sehen m�chtest
    
    clos= arg$clos[,symi]   #univariat
    zlemaN = as.integer(par$zlemaN)
    
    resHOT__ <<- clos;resHOT__[]=0  #hier wird die Anzahl der HotLags reingeschrieben.
    #auch die HotLags d�rfen nur f�r die bereits verangene Zeitreihe berechnet werden (future-danger)
    
    slopes= rollapplyr(clos,width=100,FUN=
                         function(close) { 
                           today = DateS(last(close))
                           hotLag2 = HotLags2(close,n=100-1)  #schau Dir die letzten 100 Tage an
                           resHOT__[today]<<-sum(hotLag2$lag)
                           mP("%s %s ",today,toString(hotLag2$lag))
                           maxL = min(len(hotLag2$lag),10)  #maximal 10 HotLags-Werte ber�cksichtigen
                           diffLag = lapply(c(1:maxL),
                                            function(x) 
                                            {LAG = hotLag2$lag[x]; VAL = hotLag2$value[x];
                                             if (sum(hotLag2$lag) < 2 && LAG==1) LAG=zlemaN  #oft gibts nur den HotLag 1 .. dann muss ein anderer Wert ran... 
                                             momentum(close,n=abs(LAG))* -VAL  #gewichtet mit der Wichtigkeit es Lags
                                             #ROC(ZLEMA(close, lag=abs(LAG))) * -VAL
                                             #bad: ROC(ZLEMA(close, lag=abs(LAG)),n=abs(LAG)) * -VAL
                                            })
                           #bilde �ber alle Lag-Momentum-Werte die (data.frame)-Row-Summe
                           res = na.omit(as.xts(data.frame(diffLag)))
                           res[] = rowSums(res)
                           res = last(res[,1]) },    by.column=T)
    
    
    zlem = slopes
    
    #zlem=ZLEMA(slopes,n=5)
    #zlem= bt.apply.matrix(slopes, ZLEMA, n=15)#,ratio=0.1) #6
    
    #zlem= bt.apply.matrix((sign(slopes)), ZLEMA, n=3)#,ratio=0.1) #6
    
    signal=iif(zlem >=0,1,-1)
    
    
    
    #  ZLEM= bt.apply.matrix(clos, ZLEMA, 5)#n=as.integer(par$zlemaN))
    #  dZLEM =-diff(ZLEM)
    #  signal = iif(resHOT__< 2, sign(dZLEM) ,signal)
    #  signal = sign(dZLEM)
    if (visual)
    {
      symi=1   #w�hle hier, welches Sympol des xts-pakets du sehen m�chtest
      plotSigPrice(signal=signal[,symi],prices=arg$clos[,symi],indi=list(zlem[,symi],resHOT__),xMarker=list(),main=Title("signal.hotLags",arg,par))  
    } 
    return(list(Signal=signal, Indi=list(zlem)))
  }
  if (F)
    res=signal.hotLags(global_arg,list( zlemaN=3),visual=T) 
  
  
  ####################################################################################
  #ein sehr einfaches System mit dem ich den Optimierer teste
  ####################################################################################
  signal.SMAzlema<-function(arg,par = mlist(smaN=c(20,20,100,10), zlemaN=c(10,10,90,10)),visual=F,...)
  {
    clos= arg$clos   #multivariat
    # browser()
    smaN = as.integer(par$smaN)
    zlemaN = as.integer(par$zlemaN)
    
    SMA.val =  bt.apply.matrix(clos, SMA, smaN)
    ZLEMA.val = bt.apply.matrix(clos, ZLEMA, zlemaN)
    
    signal=iif(SMA.val - ZLEMA.val <= 0, 1,-1)
    
    return(list(Signal=signal, Indi=list(merge(SMA.val,ZLEMA.val))))
  }
  
  if (F)
  {
    res=signal.SMAzlema(global_arg,list(smaN=20, zlemaN=110),visual=T) 
    indi.Generic("signal.SMAzlema", global_arg,  list(smaN=20, zlemaN=110), visual=T,TESTE=1)$Tquality   
    global_arg<<-list(clos=data.info(data),dat=data)  #MANDATORY !!!!!
    global_commission = 0.00001   #sys.Run() nimmt diese commission !!!!
    
    global_ParTable <<-NULL
    global_objectId <<-paste("TREND","DAX","signal.SMAzlema")
    globalTrainLevel <<-10
    
    indi.Generic("signal.SMAzlema", global_arg)
    TrainIndicator(global_StartDate_ = DateS(last(prices)), opti="GRID",indiName = "signal.SMAzlema",visual=F,TRAINSYM="DAX")  
    
    
    i.system=indi.Generic("signal.SMAzlema", global_arg, par = list(bbM=100,smaN=30, zlemaN=80) ,visual=T, TRAINSYM=-1,do.assemble.Signals=F)  #jeder mit seinen eigenen BestParams
    
  }
  
  ###################################################################################
  #versuch eines technischen stop-systems
  ###################################################################################
  
  
  signal.OLDtechStops<-function(arg,par = mlist(bbM=c(100,100,300,150),smaN=c(20,20,120,60), zlemaN=c(5,4,10,5)),visual=F,...)
  {
    bbM= as.integer(par$bbM)
    zlemaN= as.integer(par$zlemaN)
    smaN = as.integer(par$smaN)
    #symbols = colnames(arg$clos)
    symbols = toupper((colnames(arg$clos)))
    
    #mP("signal.techStops-----")
    #browser()
    frame = fromToS(arg$clos)
    
    #price = arg$clos
    #z=Cl(price)
    clos=m.apply(arg$dat, onlysym=symbols, PreFun=Cl,frame=frame)
    
    #  browser()
    
    ##bb=  BBands(HLC(arg$dat),n=as.integer(par$bbM), maType = SMA)
    
    #  bb.dn=m.apply(arg$dat,onlysym=symbols,Fun=BBands, PreFun=HLC, n=bbM ,maType = SMA,frame=frame)[,"dn"]
    
    bb.dn=m.apply(arg$dat,onlysym=symbols,Fun=BBands, PreFun=HLC, n=bbM ,maType = SMA,frame=frame,select="dn")
    
    #z=ZLEMA(Lo(price),n=zlemaN)
    z=m.apply(arg$dat,onlysym=symbols, Fun=ZLEMA, PreFun=Lo, n=zlemaN ,frame=frame)
    
    #sma=SMA(Cl(price),n=smaN)
    sma=m.apply(arg$dat,onlysym=symbols, Fun=SMA, PreFun=Cl, n=smaN ,frame=frame)  
    
    #rL=runLengthEnc2(iif(mROC(Cl(price))>=0,1,-1))
    rL=m.apply(arg$dat,onlysym=symbols, Fun=function(x,...)runLengthEnc2(iif(mROC(Cl(x))>=0,1,-1)) ,PreFun=Cl, n=smaN ,frame=frame)  
    
    sz = z-sma
    cudLos = iif( (sz < 0  & rL >3 ) | sz >=0, 1,0)  
    Tstops= iif(sz <0  ,0 ,1) #z < bb[,"dn"] || cudCl <= -3
    head(Tstops)
    #Tstops=EMA(Tstops ,n=100)
    Tstops = iif(Tstops <0.5 | rL< (-4) | z < bb.dn,0, 1) #  & cudLos==0 | rL < 
    signal = Tstops
    return(list(Signal=signal, Indi=list(z_sma=merge(z,sma),cudLos=rL,bb_dn=merge(clos,bb.dn))))
    
    return(list(Signal=signal, Indi=list(merge(bb.dn,z,sma),cudLos)))
  }
  
  
  signal.techStops<-function(arg,par = mlist(bbM=c(100,100,300,150),smaN=c(20,20,120,60), zlemaN=c(5,4,10,5)),visual=F,...)
  { 
    bbM= as.integer(par$bbM)
    zlemaN= as.integer(par$zlemaN)
    smaN = as.integer(par$smaN)
    
    #  colnames(prices)
    symbols = toupper((colnames(arg$clos)))
    ls(global_arg$dat)
    frame = fromToS(arg$clos)
    
    #cat(symbols)
    #browser()
    #  lapply(arg$dat, function(x)print(colnames(x)))
    
    clos=m.apply(global_arg$dat, onlysym=symbols, PreFun=Cl,frame=frame)
    lo=m.apply(global_arg$dat, onlysym=symbols, PreFun=Lo,frame=frame)
    #browser()
    bb.dn=m.apply(arg$dat,onlysym=symbols,Fun=BBands, PreFun=HLC, n=bbM ,maType = ZLEMA,frame=frame,select="dn,up")
    
    #browser()
    z=m.apply(arg$dat,onlysym=symbols, Fun=ZLEMA, PreFun=Lo, frame=frame,n=zlemaN )
    sma=bt.apply.matrix(clos,SMA,n=smaN)
    
    rL=bt.apply.matrix(clos, function(x) {runLengthEnc2(iif(ROC(x,n=1,type="discrete")>=0,1,-1))} )  
    
    sz = z-sma
    cudLos = iif( (sz < -3  & rL >3 ) | sz >=0, 1,0)  
    Tstops= iif(sz <0  ,0 ,1) #z < bb[,"dn"] || cudCl <= -3
    #head(Tstops)
    #Tstops=EMA(Tstops ,n=100)
    
    rL=bt.apply.matrix(bb.dn[,1], function(x) {runLengthEnc2(iif(ROC(x,n=1,type="discrete")>0,1,-1))} )  
    #Tstops = iif(Tstops <0.5 | rL< (-4) | z < bb.dn,0, 1) #  & cudLos==0 | rL < 
    Tstops = iif( z < bb.dn[,1] | rL <= -3,  0, 1) #  & cudLos==0 | rL < 
    
    #Tstops = iif( lo <= bb.dn[,1] ,  -1, 1) #  sehr schnell - gut gegen steil-sturz
    #Tstops = iif( sz <= 0 ,  -1, 1) #  slow
    
    Tstops = iif( sz <= 0 ,  -1, Tstops) #  slow
    md= abs(diff(sma,3))
    #plot(md)
    # Tstops = iif (md > 15,Tstops,0) 
    #
    #Tstops = iif(rL  > 2 ,1,lag(Tstops))  #schneller einschalten ...f�hrt zu viele minis...
    signal = Tstops
    
    #  cudLos=rL,
    return(list(Signal=signal, Indi=list(z_sma=merge(z,sma),bb_dn=merge(lo,bb.dn))))
    
    
    
    # mchart(merge(z,sma))  
    sz = z-sma
    cudLos = iif( (sz < 0  & rL >3 ) | sz >=0, 1,0)  
    Tstops= iif(sz <0  ,0 ,1) #z < bb[,"dn"] || cudCl <= -3
    Tstops =  bt.apply.matrix(Tstops, EMA, n=smaN)
    
    Tstops = iif(Tstops <0.5 | rL< (-4) | z < bb.dn,0, 1) #  & cudLos==0 | rL < 
    
    Tstops = cudLos
    #  Tstops =  bt.apply.matrix(Tstops, EMA, n=100)
    
    #browser()
    Tstops = iif (z-sma < 0, 0, 1)   #zlema-macd   
    
    rL=bt.apply.matrix(Tstops, function(x) runLengthEnc2(x))
    
    #Tstops = iif(rL > 3, Tstops,0 ) 
    
    signal = Tstops
    mP("signal.techStops  <<<")
    
    return(list(Signal=signal, Indi=list(z_sma=merge(z,sma),cudLos=rL,bb_dn=merge(clos,bb.dn))))
  }
  
  
  
  if (F)
  {
    
    prices=data.info(data)
    
    global_arg<<-list(clos=prices,dat=data)  #MANDATORY !!!!!
    global_commission = 0.00001   #sys.Run() nimmt diese commission !!!!
    #global_FastTrain=5
    #ich kann das Training gr�ber oder feiner gestalten indem ich die Variable
    #global_FastTrain > 0 setzte. dies ist dann die Anzahl der Zwischenschritte pro
    global_ParTable <<-NULL   #leere Parameter-Tabelle vorbereiten
    global_StartDate <<-  DateS(last(prices))
    globalTrainLevel <<-10   
    global_objectId <<-paste("TREND","DAX","signal.techStops") 
    global_xMarker<<-list()
    
    TrainIndicator( opti="GRID", indiName = "signal.techStops",  visual=T, TRAINSYM = "DAX")
    #(TRAINSYM=0:  alle gleich trainieren = default,  
    # TRAINSYM = 1..:  trainiere nur die Zeitreihe 1..)
    i.system=indi.Generic("signal.techStops", global_arg, par = list(bbM=100,smaN=80, zlemaN=9) ,visual=T, TRAINSYM="DAX",do.assemble.Signals=F)  #jeder mit seinen eigenen BestParams
    
    i.system=indi.Generic("signal.techStops", global_arg, par = list(bbM=100,smaN=80, zlemaN=9) ,visual=T, TRAINSYM=-1,do.assemble.Signals=F)  #jeder mit seinen eigenen BestParams
    
    i.system=indi.Generic("signal.OLDtechStops", global_arg, par = list(bbM=100,smaN=80, zlemaN=9) ,visual=T, TRAINSYM=-1,do.assemble.Signals=F)  #jeder mit seinen eigenen BestParams
    
    
    i.system=indi.Generic("signal.techStops", global_arg, par = list(bbM=166,smaN=20, zlemaN=6) ,visual=T, TRAINSYM="GOLD",do.assemble.Signals=F)  #jeder mit seinen eigenen BestParams
    
    
    
    signal.techStops(global_arg)
    i.system=indi.Generic("signal.techStops", global_arg,visual=T, TRAINSYM=1,do.assemble.Signals=T)  #jeder mit seinen eigenen 
    i.system=indi.Generic("signal.techStops", global_arg,visual=T, TRAINSYM=-1)  #jeder mit seinen
  }
  #######################################################################################
  #Wenn sich der Down-Trailing-Stop ddma  mit dem Up-Trailing-Stop  ddmi kreuzt entsteht
  #f�r viele Titel ein interessanter Schnittpunk f�r Entry-Exit...
  #muss aber individuell trainiert werden
  #######################################################################################
  
  signal.drawDown<-function(arg, par = mlist(runMa=c(250,50,500,50),runMi=c(250,50,500,50) ,levelMi=c(0.5,0.1,1,10)),visual=F,...)
  {
    #browser()
    par$zlemaN=11 #fix
    levelMi=par$levelMi
    
    zlem= bt.apply.matrix(mNorm(na.omit(arg$clos)), ZLEMA, n=as.integer(par$zlemaN))
    
    p=mNorm(na.omit(arg$clos))
    ret = na.omit(mROC(p))
    
    ddma=bt.apply.matrix(zlem, runMax, n=as.integer(par$runMa));ddma=ddma-p
    ddmi=bt.apply.matrix(zlem, runMin, n=as.integer(par$runMi));ddmi=p-ddmi
    
    #plot(ddma)
    #browser()
    #ddma=iif(ddma< levelMi,0,ddma)
    #ddmi=iif(ddmi< levelMi,0,ddmi)
    
    signal=arg$clos; signal[]=NA
    signal[]=merge(signal[,1], iif(ddmi <ddma ,0,1))[,2]
    
    #browser()
    
    #zlemDD=merge(zlem,ddma,ddmi)
    #mchart(zlemDD)
    #  plotSigPrice(signal=na.omit(signal),prices=arg$clos,indi=list(zlemDD=merge(zlem,ddma,ddmi)))#merge(bb[,"dn"]
    
    return(list(Signal=signal, Indi=list(zlemDD=merge(zlem,ddma,ddmi))))
  }
  #+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  if (F)
  {  
    global_ParTable=NULL
    global_arg = list(clos=data$prices, dat=data)
    
    #clos=prices[,2:2]
    
    res=signal.drawDown(global_arg)   # DOW: 10,150
    res=signal.drawDown(global_arg,list( k=10, zlemaN=150),visual=T)   # DOW: 10,150
    res=signal.drawDown(global_arg,list( k=76, zlemaN=2),visual=T)   # DOW: 10,150
    #das ganze mit chart und Auswertung
    
    x=indi.Generic("signal.drawDown", global_arg, visual=T, TRAINSYM="DAX")  
    
    prices=data.info(data)
    
    global_arg<<-list(clos=data.info(data),dat=data)  #MANDATORY !!!!!
    global_commission = 0.00001   #sys.Run() nimmt diese commission !!!!
    #global_FastTrain=5
    #ich kann das Training gr�ber oder feiner gestalten indem ich die Variable
    #global_FastTrain > 0 setzte. dies ist dann die Anzahl der Zwischenschritte pro
    global_ParTable <<-NULL   #leere Parameter-Tabelle vorbereiten
    
    globalTrainLevel <<- 5   
    
    i.system=indi.Generic("signal.drawDown", global_arg, par = list(runMa=100,runMi=50,levelMi=0.2) ,visual=T, TRAINSYM=-1,do.assemble.Signals=F)  #jeder mit seinen eigenen BestParams
    
    
    #und jetzt f�r alle Zeitreihen als gleichgewichtetes Portfolio
    x=indi.Generic("signal.drawDown", global_arg, visual=T, TRAINSYM="DAX")   #jeder mit gleichen BestParams
    global_FastTrain<<- -1
    TrainIndicator (opti="GRID",indiName = "signal.drawDown",visual=T,TRAINSYM="DAX")  
    
    x=indi.Generic("signal.drawDown", global_arg, visual=T, TRAINSYM="DAX")   #jeder mit gleichen BestParams
    
    
  }
  
  #########################################################################################
  #statt immer die gleichen  indi.SMA,  indi...  Teile zu schreiben (die auch nur single-Asset tauglich sind)
  #schreib ich in in Zukunft nur noch  signal.wonder, signal.SMA, signal.... Teile. 
  # die sind k�rzer und Multi-Asset-tauglich.
  #Wichtig:  indi.Generic  wird auch von TainIndicator() aufgerufen - (via train#.Indicator() )
  #do.assemble.Signals = T hei�t: gehe in global_ParTable durch s�mtliche trainierten Parameter durch und bau
  #ein Gessamt-Signal aus den sequenzen der der Einzel-Systeme. ..
  #nTop ist der Quotinen:  n.top = nsymbols/nTop  # bei nTop = 1 gehen alle symbole
  #########################################################################################
  indi.Generic<-function(signal.fun="SMA", arg,xarg=NULL, par=NULL,visual=F,main="",commission=0.1,TRAINSYM=0,do.assemble.Signals =F,stopSys="",nTop=1,safe="",experiment="",T.arg=list(),S.arg=list(),A.arg=list())#trailing.stop
  {  
    #browser(mP("ini.Generic"))
    orgTrainsym = TRAINSYM
    indi.fn = match.fun(signal.fun) #sprintf("signal.%s",signal.fun)) 
    #sym = colnames(arg$clos)
    if (len(colnames(arg$clos)) ==1)
      TRAINSYM=1
    
    
    #browser(mP("indi.Generic"))
    if (!exists("global_objectId"))
      global_objectId<<-paste("TREND",sym,sprintf("signal.%s",signal.fun))
    
    if (is.null(par)) #wird gebraucht, wenn man unbedingt �ber Leer-Aufuf von indi.fn() die mlist()-Werte nach gloabl_par-Table transportieren will
    {
      par1 = mlist()
      if (is.null(global_ParTable)  || len(par1)==0)
      {
        this_arg = global_arg
        this_arg$clos = global_arg$clos[,1]
        
        mP("init mlist()")
        indi.fn(this_arg)  #damit der signal.<> via seinem mlist()Aufruf seinen default-parameter nach global_ParTable schreibt.
        #return(list())
      }
    }
    
    #.....................................................................
    
    if (TRAINSYM ==-1)
      TRAINSYM =pureColnames(global_arg$clos)   #Teste alle Zeitreihen, aber finde separate BestParams
    
    if (TRAINSYM != 0 && is.numeric(TRAINSYM) && len(TRAINSYM)==1)   #teste nur eine ausgw�hlte Zeitreihe
    {
      TRAINSYM=pureColnames(global_arg$clos)[TRAINSYM]
    }
    
    
    if (len(TRAINSYM)==1 &&  TRAINSYM != -1 && TRAINSYM != 0)   #teste nur eine ausgw�hlte Zeitreihe
    {
      arg$clos = arg$clos[,TRAINSYM]
      
    }
    
    org.arg = arg
    merk_global_objectId = global_objectId
    sym="Allsymbols"
    Signals.all = NULL
    org.par = par
    
    orgTrainsym = TRAINSYM
    
    singleResults = list()
    #.....................................................................
    
    pdf =NULL
    if (experiment !="")
    {
      pdf =sprintf("Models/%s/%s_universe.pdf", dataSet, experiment)
      mP("Write Data Charts to %s",pdf)
      dir.create(dirname(pdf),recursive=T)
      
      pdf(file = pdf, paper="a4r",width=0, height=0)#width=15, height=10)
      if (!is.null(data)) 
      { 
        data.info(data,visual=F)
        plot.table(as.matrix(DataInfo))
        purePlot(mNorm(data$prices)) 
      }
      
    }
    while (T)   #alle symbole testen  (Ausstieg via break - ganz unten)
    {           #Baue das multi-var-SignaleAll -xts dass, aus evtl. ganz unterschiedlich parametrisierten Teilsystemen generiert wird.
      
      if (TRAINSYM !=0)  #trainiere in einer  schleife viele Zeitreihen separat
      {
        sym = TRAINSYM[1]
        if (len(colnames(org.arg$clos))>1)   #wahrscheinlich im Trainings-Mode..
          mP("................. Test sym: %s",sym)
        #browser()
        
        arg$clos <-org.arg$clos[,sym]
        
        if(is.null(org.par)) #lies den aktuellen mlist-Wert aus global_ParTable
        {
          #erzeuge einen symbol-spezifischen  objectId zur richtigen Adressierung mit mlist()
          goi =spl(merk_global_objectId,delim=" ")
          New_objectId = sprintf("%s %s %s",goi[1],sym,signal.fun)
          #browser()
          #New_objectId = sprintf("%s %s %s",goi[1],sym,goi[3])
          global_objectId <<- New_objectId
          #nun ist global_objectId f�r die addressierung in mlist( )fertig: gibts denn in der global_ParTable schon Werte?
        }
      }
      else
      {
        # mP("........ >>")
        # browser()
        goi =spl(merk_global_objectId,delim=" ")
        global_objectId <<- sprintf("%s %s %s",goi[1],"AllSymbols",signal.fun)
        
      }
      
      #...................................................................
      #  MM_TODO  damit ein Indikator, der eine Trainingsgeschichte hat, korrekte    signale liefert m�ssen diese - auch beim Abruf korrekt zusammengesetzt werden.
      
      #Aufruf  der signal.<-Methode>()
      #w�hle ob inkrementell oder komplett mit einem Par-Satz gearbeitet wird
      #browser()
      if (len(org.par) ==0)   #sollen Parameter aus global_ParTable benutzt werden?
      {
        #par = mlist()  #falls vorhanden wird hier der zum TRAINSYM[1]#global_StartDate  passende parameter-Satz aus global_ParTable gelesen
        last.trainDay  =""   #signale zusammensetzen aus den jeweiligen - par S�tzen unterschiedlicher Traingstage in global_ParTable
        last.possible.Day = DateS(last(arg$clos))
        
        #global_xMarker  as.list(global_xMarker)
        
        if (!do.assemble.Signals  )
        {
          #browser()
          par = mlist() 
          if (len(par)==0)
          {
            mP("Sorry0- there are no parameters  at global_ParTable given for %s",global_objectId) 
            return(list())
          }
          title=Title(signal.fun,arg,par,sym=sym)
          mP(sprintf("use org par %s",title))
          signal.ret = indi.fn(arg,par,visual,xarg,main=sprintf("%s %s ",main,title) )
          
        }
        else
          #signal-Assembler  ...  ruft den signal.<> .. mit unterschiedlichen bestParams-  zu den zeiten wie sie in global_ParTable stehen
        {
          #browser()
          for (trainDay in global_ParTable[objectId==global_objectId]$time)
          {
            if (trainDay > last.possible.Day)  
              break;
            
            par = global_ParTable[time==trainDay & objectId==global_objectId]$par[[1]] 
            par = lapply(par,function(x)first(x))
            mP(".signal-Assembler.%s.%s     (%s)",global_objectId,trainDay,toString(par))
            
            #Berechne die Signale bis zum kommenden       
            if (len(par)==0)
            {
              mP("Sorry1- there are no parameters  at global_ParTable given") 
              return(list())
            }
            #...................................................................
            title=Title(signal.fun,arg,par,sym=sym)
            mP(title)
            
            # aufruf des Signal-Generators
            if (dim(arg$clos)[2]> 1)
              mP("%s----->>>>>>>>>>>%d symbols >>>>>>>>>>>>",signal.fun,dim(arg$clos)[2])
            
            sig = indi.fn(arg,par,visual,xarg,main=sprintf("%s %s ",main,title) )  #die signal.<..> methode liefert "$Indi" +   "$Signal"
            
            if (last.trainDay =="")
              signal.ret = sig  #es gab vorher noch keinen Trainingstag, dies ist der erste
            else  # nur einen Teil der signal-Ergebnisse verwenden .. nn�..
            {
              signal.ret$Signal = rbind(signal.ret$Signal[sprintf("::%s",as.Date(last.trainDay)-1)] , sig$Signal[sprintf("%s::",last.trainDay)]) #zusammenbasteln
              signal.ret$Indi[[1]] = rbind(signal.ret$Indi[[1]][sprintf("::%s",as.Date(last.trainDay)-1)] , sig$Indi[[1]][sprintf("%s::",last.trainDay)]) #zusammenbasteln
            }
            last.trainDay  = trainDay #weiterschalten
            
          }
        }
      }  #parameter werden via kommandozeile ausdr�cklich mitgegeben .. sollen also nicht aus global_ParTable gelesen werden
      else
      {
        title=Title(signal.fun,arg,par,sym=sym)
        mP(sprintf("use org par %s",title))
        par=org.par
        # aufruf des Signal-Generators
        if (dim(arg$clos)[2]> 1)
          mP("%s----->>>>>>>>>>>%d symbols >>>>>>>>>>>>",signal.fun,dim(arg$clos)[2])
        signal.ret = indi.fn(arg,par,visual=visual,xarg,main=sprintf("%s %s ",main,title) )
      }
      
      #  mP("TestSignals %s  ",global_objectId)
      # browser()
      if (F) #old
      {
        par = mlist() 
        title=Title(signal.fun,arg,par,sym=sym)
        mP(sprintf("use org par %s",title))
        signal.ret = indi.fn(arg,par,visual,xarg,main=sprintf("%s %s ",main,title) )
        
        plot(signal.ret$Indi[[1]])
        
        purePlot(signal.ret$Indi[[1]])
        colnames(signal.ret$Indi[[1]])
      }
      ### nun liegen die signale vor und man kann eine single -modell-system bewertung vornehmen
      # sys.Run() ist das "indi.finish() f�r  die signal.<...>-systeme: sorgt also f�r chart und perfauswertung.
      
      mP("..................>>> pre test singelSys:  sys.Run")
      
      if (do.assemble.Signals)
      {
        mP(" do.assemble.Signals  ")
        global_xMarker <<-as.list(global_ParTable[objectId==global_objectId]$time)
      }
      else 
        global_xMarker<<- NULL
      #browser(mP("TEST"))
      if (TRAINSYM !=0 )
      {    
        model=sys.Run(prices=arg$clos,signal=signal.ret$Signal ,compare=visual,viewLevel=spl("timingsys"),main=title, hilfs.Indi=list(signal.ret$Indi),stopSys,signal.fun=signal.fun,data=arg$dat,T.arg=T.arg,S.arg=S.arg,A.arg=A.arg)
        
        #Ergebnissicherung
        if (len(colnames(arg$clos))==1)
          singleResults[[sym]] = list(equity=model$equity, Tquality=model$Tquality)
      }
      
      if (is.null(Signals.all))
        Signals.all = signal.ret$Signal
      else
        Signals.all = merge(Signals.all, signal.ret$Signal )
      
      
      if (TRAINSYM ==0)
        break;
      if (len(TRAINSYM)==1)  #letzte Zeitreihe wurde trainiert
        break;
      TRAINSYM = TRAINSYM[-1]  #erstes Symbol abschneiden
      
    } ##while ... evtl. nachste Zeitreihe, falls die prices separat trainiert werden sollen.
    if (!is.null(pdf)) 
      dev.off()
    
    #browser()
    #........................... Es jetzt liegen die Signale der evtl. unterschiedlich parametrisierten Indikatoren vor:
    #mP("pre sys.Run"); browser()
    
    #sys.Run kann auch ganze Portfolios auswerten, da es auf bt.run des sysinvestors basiert
    if ( len(colnames(org.arg$clos))>1  )
    {  
      mP("---------------------  PORTFOLIO  sys.Run ----------------------- ")
      #priceSyms(Signals.all)
      
      if (orgTrainsym <=0  )
        model=sys.Run(prices=org.arg$clos,signal=Signals.all ,compare=visual,viewLevel=spl("portfolio"), nTop=nTop,safe=safe,experiment=experiment,signal.fun=signal.fun,data=arg$dat,T.arg=T.arg,S.arg=S.arg,A.arg=A.arg)
      else
        model=sys.Run(prices=org.arg$clos[,orgTrainsym],signal=Signals.all ,compare=visual,viewLevel=spl("portfolio"), nTop=nTop,safe=safe,experiment=experiment,signal.fun=signal.fun,data=arg$dat,T.arg=T.arg,S.arg=S.arg,A.arg=A.arg)
      model$singleResults = singleResults
      mP("sys.Run ready - need more analysis ?");  
      #browser()
    }
    #............................................................................................
    if (F)
    {
      #*****************************************************************
      # Create Report
      #******************************************************************    
      
      #  model$trade.summary
      strategy.performance.snapshoot(model, T)
      plotbt.custom.report.part1(model)       
      compareViewModels(list(model=model),prices,alloc=T)
      pdf_Report(list(model=model),experiment)
      
      # Plot Portfolio Turnover for each strategy
      layout(1)
      barplot.with.labels(sapply(models, compute.turnover, data), 'Average Annual Portfolio Turnover')
      
      pdf_Report(experiment)
      dev.off()
      
      #return(indi.finish(signal=signal.ret$Signal,prices=arg$clos,indi=signal.fun,par=list(par),visual=visual, Indi=signal.ret$Indi,main=main))
    }
    
    global_objectId <<- merk_global_objectId
    return(model)
  }
  
  if (F)
  {
    global_arg<<-list(clos=prices[,1:1])
    res= indi.Generic("wonder", global_arg,  list( k=20, zlemaN=60), visual=F,commission=0.00001)   
    
    global_ParTable <<-NULL
    global_objectId <<-paste("TREND","Dax","signal.wonder")
    globalTrainLevel <<-10
    mlist()
    global_objectId <<-paste("TREND","Dax","indi.SMA")
    
    indi.SMA(global_arg)
    TrainIndicator(global_StartDate_ = DateS(last(prices)), opti="GRID",indiName = "signal.wonder",visual=F)  
    
    #tune.monthly(prices, symbol="TECDAX", indiName="indi.ZlemaDif",wlen=200,opti="GRID",trainLevel = 100)
    #tune.Generic(prices, endpoints,indiName="wonder",wlen=200,opti="GRID",trainLevel = 100)
    
  }
  
  ######################################################################################################
  indi.ZlemaDif<-function(arg,par = mlist( k=c(29,30,40), kd=c(2,2,40)),visual=F,main="")
  {
    
    #  print("indi.ZlemaDif"); browser()
    prices = arg$clos
    today = as.Date(index(last(prices)))
    kd = round(par$kd)
    # minSig=par$minSig
    k=round(par$k)
    
    
    #cat ("#", toString(today),"\n  ZlemaDif: minSig", par$minSig," k ",par$k)
    mP(Title("ZlemaDif",arg,par))
    
    scdfast=score.diff(ZLEMA(prices,n=k),k=kd)  #XOFF = 2*k
    scdfast[is.na(scdfast)] <-0
    # if (minSig==0)
    signal = iif( sign(scdfast[,1])>0 ,1,-1)
    #else
    #   signal = iif( sign(scdfast[,1])>0  & abs(scaleTo(scdfast[,1],c(-1,1)))>minSig,1,-1)
    #main=sprintf("%s %s  winLen %s", main,colnames(clos)[1], toString(par$winLen)) 
    
    # plotSigPrice(signal=signal,prices=arg$clos,indi=list(merge(ZLEMA(prices,n=k),scdfast)),xMarker=global_xMarker,main=main)  
    #browser()
    return(indi.finish(signal,prices,indi="indi.ZlemaDif",par=list(par),visual=visual, Indi=list(ZLEMA(prices,n=k),scdfast),main=main))
    
  }
  if (F)
    res= indi.ZlemaDif(global_arg,  list( k=30, kd=2), visual=T)   
  
  ####################################################################################################
  
  
  indi.SMA<-function(arg,par=mlist(winLen=c(40,10,200)),visual = F,main="")
  {
    clos=arg$clos
    winLen = as.integer(par$winLen)
    sma = tryM(SMA(clos,winLen) )
    
    # if (BUG==1)    browser()
    
    signal = iif(clos >= sma  , 1, 0)
    
    mP(Title("SMA",arg,par))
    #browser()
    return(indi.finish(signal,clos,indi="indi.SMA",par=list(par),visual=visual, Indi=list(merge(sma,clos)),main=main))
    
    #return(indi.finish(signal,arg))
  }
  if (F)
    indi.SMA(global_arg,  list(winLen=15), visual=T)   
  
  ##################################################################################################
  
  
  #####################################################################################
  # aus sysinvestor
  #####################################################################################
  
  indi.TSI<-function(arg,par=mlist(tsin=13, w2=2),visual = F,main="")
  {
    dat =arg$dat
    tsi = TSI(HLC(dat),par$tsin)
    sma = SMA(tsi, par$w2)
    signal = iif(tsi >= sma && tsi >0 , 1, 0)
    
    mP(Title("TSI",arg,par))
    
    return(indi.finish(signal,arg$clos,indi="indi.TSI",par=list(par),visual=visual, Indi=list(merge(tsi,sma,arg$clos)),main=main))
  }
  #####################################################################################
  # aus sysinvestor
  #####################################################################################
  
  # Mean-Reversion(MR) strategy - RSI2
  indi.RSI<-function(arg,par = mlist(rsiL=c(2,2,20), rsiThres=c(50,10,90), zlemaN=c(30,0,50)),visual = F,main="")
  {
    mP(Title("RSI",arg,par))
    #browser()
    zlemaN=round(par$zlemaN)
    clos=arg$clos
    #  rsi2 = bt.apply.matrix(prices, RSI, 2)  
    rsi2 = RSI(clos, round(par$rsiL))  
    #  signal= iif(rsi2 < par$rsiThres, 1, -1)
    signal= iif(rsi2 < par$rsiThres, -1, iif(rsi2 > 100-par$rsiThres,1,0))
    
    if (zlemaN >0)
      signal = ifelse(ZLEMA(signal,n=zlemaN) >= 0, 1,-1)
    
    #plotSigPrice(signal=signal,prices=clos,indi=list(merge(rsi2,par$rsiThres,100-par$rsiThres)),xMarker=global_xMarker,main=main)  
    #browser()
    
    #main=sprintf("%s %s  rsiL %s rsiThres %s, zlemaN %s", main,colnames(clos)[1], toString(par$rsiL),toString(par$rsiThres),toString(par$zlemaN))
    
    return(indi.finish(signal,arg$clos,indi="indi.RSI",par=list(par),visual=visual, Indi=list(merge(rsi2,par$rsiThres,100-par$rsiThres)),main=main))
  }
  if (F)
  {
    indi.RSI(global_arg)
    x=indi.RSI(global_arg,  list(rsiL=2,rsiThres=20,zlemaN=30), visual=T)     #spannend
    x=indi.RSI(global_arg,list(rsiL=2,rsiThres=45,zlemaN=170),visual=T ) 
  }
  #####################################################################################
  #####################################################################################
  
  indi.Omega<-function(  arg,  par =  mlist(width=c(25,10,100), minLevel =c(1.5,0,3)),visual = F,main="")
  {
    w=round(par$width)
    clos=arg$clos
    
    mP(Title("Omega",arg,par))
    ret=mROC(clos)
    Omega<-apply.rolling(ret,FUN="Omega",width=par$width)
    #signal = rep(1,len(dclos))
    #indicator=Omega<-signal
    #lag the data by 1
    signal=iif(Omega > par$minLevel, 1 ,0) #zus?tzliche Gl?ttung
    
    #signal<-lag(signal,k=1)  #ohne das wirds super "vorhersehend" ?????
    #signal[is.na(signal)]<-0
    return(indi.finish(signal,arg$clos,indi="indi.Omega",par=list(par),visual=visual, Indi=list(merge(Omega,par$minLevel)),main=main))
    
  }
  if (F)
    indi.Omega(global_arg,  list(width=24,minLevel=1.5), visual=T)     #spannend
  
  #####################################################################################
  # aus sysinvestor
  #####################################################################################
  
  # Trend Following(TF) strategy - MA 50/200 crossover
  indi.MACD<-function(arg,par = mlist(wShort=c(50,30,70) , wLong=c(200,160,250)),visual = F,main="")
  {
    # browser()
    #sma.short = bt.apply.matrix(prices, SMA, 50)
    #sma.long = bt.apply.matrix(prices, SMA, 200)
    #data$weight[] = NA
    #data$weight[] = iif(sma.short > sma.long, 1, -1)
    
    #print("############## indi.MACD #############")
    #  cat ("\n MACD: wShort",par$wShort[1]," wLong ",par$wLong[1])
    mP(Title("MACD",arg,par))
    
    smaShort = SMA(arg$clos, n= round(par$wShort))  
    smaLong = SMA(arg$clos, n= round(par$wLong))
    
    signal= iif(smaShort > smaLong, 1, -1)
    #  browser()  
    
    return(indi.finish(signal,arg$clos,indi="indi.MACD",par=list(par),visual=visual, Indi=list(merge(smaShort,smaLong,arg$clos)),main=main))
    
  }
  
  
  if (F)
    TrainIndicator()
  #####################################################################################
  # aus sysinvestor
  #####################################################################################
  
  #*****************************************************************
  # Regime Switching  Historical
  #****************************************************************** 
  #classify current volatility by percentile using a 252 day lookback period
  #The resulting series oscillate between 0 and 1, and is smoothed using a 21 day 
  #percentrankSMA (developed by David Varadi) using a 252 day lookback period.
  #percentrank(MA(percentrank(Stdev( diff(log(close)) ,21),252),21),250)
  #
  #Generell sind starke Aufw?rtstrends mit einer Abnahme der Volatilit?t zu erkl?ren, starke Abw?rtsbewegungen f?hren zu einer Ausweitung/Steigerung der Volatilit?t
  #Das Ph?nomen eines "Reversals" tritt gew?hnlicherweise dann auf, wenn die Volatilit?t pl?tzlich zunimmt.
  #Quelle: http://www.broker-test.de/finanzwissen/technische-analyse/volatilitaet/
  
  indi.RegimeSwichtCol<-function(arg,par = mlist( SDn=21,w1=252,w2=250,rsiT=50,volRank=0.5),visual = F,main="")
  {
    ret.log = ROC(arg$clos, type='continuous')
    hist.vol = runSD(ret.log, n = par$SDn)
    vol.rank = percent.rank(SMA(percent.rank(hist.vol, par$w1), par$SDn), par$w2)
    
    smaShort = SMA(arg$clos, n= round(par$wShort))
    smaLong = SMA(arg$clos, n= round(par$wLong))
    
    rsi2 = RSI(arg$clos, par$rsiL)  
    
    # Regime Switching  Historical  
    signal = iif(vol.rank > par$volRank, 
                 iif(rsi2 < par$rsiT, 1, -1),
                 iif(sma.short > sma.long, 1, -1)
    )
    
    return(indi.finish(signal,arg$clos,indi="indi.RegimeSwichtCol",par=list(par),visual=visual, Indi=list(),main=main))
  }
  
  #####################################################################################
  # aus sysinvestor
  #####################################################################################
  #sma-vergleich:  RSIlevy - zur Benchmark
  indi.BenchCompare<-function(arg,par=mlist(winLen=200, compareTo ="Rex"),visual = F,main="")
  {
    clos=arg$clos
    
    sma1 = SMA(clos,par$winLen)
    compTo = getCol(arg$data$prices, compareTo)
    sma2 = SMA(compTo,par$winLen)
    signal = iif(sma1 > sma2 , 1, 0)
    
    return(indi.finish(signal,arg$clos,indi="indi.BenchCompare",par=list(par),visual=visual, Indi=list(),main=main))
    
  }
  ####################################################################################################################################################################
  indi.HOLTW<-function(arg,par = list())
  {
    mP(Title("HOLTW",arg,par))
    prices=par$clos
    slopes <- rollapplyr(prices, width=60, FUN=roll.HOLTW, by.column=FALSE, align = "right")  
    #Align-Signals
    block=mmerge(slopes,prices)
    slopes= block[,1]
    prices= block[,2]
    #new_Win(1)
    signal = sign(slopes)
    
    #signal = ifelse(ZLEMA(sign(slopes),na.rm=T,n=20) >= 0,1,-1)
    #signal=ifelse(abs(slopes)*10000<1, 0,signal)
    
    if (visual)
      plotSigPrice(signal=signal,prices=arg$clos,indi=list(merge(smaShort,smaLong)))  
    
    
    return(indi.finish(signal,prices,indi="indi.HOLTW",par=list(par),visual=visual, Indi=list(scdfast),main=main))
    
  }
  
  #####################################################################################
  #
  #####################################################################################
  
  indi.finishOLD<-function(signal,arg)
  {
    signal<-lag(signal,k=1)
    signal[is.na(signal)]<-0
    
    this_dclos= getCol(arg$dclos, arg$Ti$name)
    
    guv = cumsum(signal*this_dclos)
    #  indicator = merge(clos,sma)
    #browser() 
    ret =as.numeric(last(guv))
    print(ret)
    return (ret)
  }
  
  #####################################################################################
  #  siehe nile  kalman-beispiel aus dlm paket -doku
  #####################################################################################
  
  library(dlm)
  
  nileBuild1 <- function(par) {
    #random walk with white noise
    dlmModPoly(1, dV = .3, dW = .01)
    #  dlmModPoly(1, dV = exp(par[1]), dW = exp(par[2]))
    dlmModPoly(1, dV = .9, dW = .11)
    
  }
  
  nileBuild2 <- function(par) {
    #random walk with white noise
    #dlmModPoly(1, dV = .99, dW = .20)
    dlmModPoly(1, dV = exp(par[1]), dW = exp(par[2]))
  }
  #####################################################################################
  #  siehe nile  kalman-beispiel aus dlm paket -doku
  #####################################################################################
  
  #####################################
  #Combining auto.arima() and ets() from the forecast package
  #I've been using the ets() and auto.arima() functions from the forecast package to forecast a large
  auto.ts <- function(x,ic="aic") {
    XP=ets(x, ic=ic) 
    AR=auto.arima(x, ic=ic)
    
    if (get(ic,AR)<get(ic,XP)) {
      model<-AR
    }
    else {
      model<-XP
    }
    model
  }
  
  #str(forecast(fit,1))
  
  #aam<-function(c){fit<-auto.arima(ts(arg$clos),ic="aic");  return(forecast(fit,1))}
  
  #aam()
  
  indi.Kalman<-function(arg=list(clos=clos), par = list(dv=.3, dw =.01,w=120))
  {
    #smaShort = SMA(arg$clos, par$wShort)
    Clos = ts(arg$clos)
    #  smaLong = ets(Clos)
    #  fit <- ets(Clos)
    signal<-apply.rolling(arg$clos,FUN=aam,          width=par$w)
    
    fit <-auto.arima(Clos, ic="aic")
    plot(Clos)
    plot(forecast(fit,20))
    #signal= iif(smaShort > smaLong, 1, -1)
    
    clos=arg$clos
    
    Nile =ts(na.omit(clos))
    
    nileMLE <- dlmMLE(Nile, rep(9,2), nileBuild1); 
    #nileMLE2 <- dlmMLE(Nile, rep(9,2), nileBuild2);
    #nileMLE$conv
    nileMod <- nileBuild(nileMLE$par)
    #nileMod2 <- nileBuild(nileMLE2$par)
    #V(nileMod)
    #V(nileMod2)
    ##W(nileMod)
    #W(nileMod2)
    
    nileFilt <- dlmFilter(Nile, nileMod)
    
    nileSmooth <- smaLong# dlmFilter(Nile, nileMod2)# dlmSmooth(nileFilt)
    #x=sum(nileFilt$m[-1]- nileSmooth$s[-1])
    #print(x)
    
    #plot(cbind(Nile, nileFilt$m[-1], nileSmooth$s[-1]), plot.type='s',
    #     col=c("black","red","blue"), ylab="Level", main="Nile river", lwd=c(1,2,2))
    plot(cbind(Nile, nileFilt$m[-1], nileSmooth), plot.type='s',
         col=c("black","red","blue"), ylab="Level", main="Nile river", lwd=c(1,2,2))
    
    #  return(indi.finish(signal,arg))
  }
  if (F)
  {
    xts
    par = list(dv=.3, dw =.01,w=120)
    arg=list(clos= prices$sx5r["2008-11/2009"])
    plot(arg$clos)
    new_Win()
    indi.Kalman(arg=list(clos= prices$sx5r["2007"]) )
  }
  
  #TODO
  #http://www.broker-test.de/finanzwissen/technische-analyse/williams-percent-r/
  
  #indi.WilliamsPercent
  #indi.LinReg
  
  
  
  
  #########################################################################################################################
  my.VAR_ <- function(price,n.ahead=15)    #eine Beispielfunktion f�r rollapplyr
  {
    cat(sprintf("my.VAR_: %s ",toString(as.Date(index(first(price))))),"\n")
    
    #price=mNorm(price) #NEU
    pri=ts(merge(price,seq(1,len(price))),frequency=12)
    priceMod <-VAR(pri,p=1,type="none")  #MM_TODO:  noch ander  VAR-type ausprobieren "trend","both", ...
    pred <- predict(priceMod, n.ahead = n.ahead, ci = 0.95)  #anderes Signifikanz-Intervall ausprobieren  
    
    fcst=pred$fcst[1]
    Res=data.frame(fcst)
    res = last(Res[,1])-first(Res[,1])
    return(res)
  }
  my.VAR<-cmpfun(my.VAR_) #compilier das Teil
  
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  indi.VAR<-function(arg,par=mlist(winLen=c(40,10,200),zlemaN = c(100,10,200)),visual = F,main="")
  {
    mP(Title("VAR",arg,par))
    
    clos=arg$clos
    winLen = as.integer(par$winLen)
    zlemaN = as.integer(par$zlemaN)
    #sigNoise = as.double(par$sigNoise) #  sigNoise = c(2,1,10)
    n.ahead = 2# as.integer(par$n.ahead)
    
    
    slopes <- rollapplyr(clos, width=winLen, FUN=my.VAR, n.ahead=n.ahead,by.column=FALSE, align = "right")
    slopes=na.omit(slopes)
    signal = sign(slopes)
    
    #signal= ifelse(abs(slopes)*100<sigNoise, 0,signal)
    
    signal = ifelse(ZLEMA(signal,n=zlemaN) >= 0, 1,-1)
    
    #slopesP=percent.rank(slopes,50)
    
    #sma = tryM(SMA(clos,winLen) )
    # if (BUG==1)    browser()
    
    #plotSigPrice(signal=signal,prices=clos,indi=list(merge(slopes*10)),xMarker=global_xMarker,main=main)  
    
    return(indi.finish(signal,clos,indi="indi.VAR",par=list(par),visual=visual, Indi=list(merge(slopes)),main=main))
    
  }
  if (F)
    indi.VAR(global_arg,  list(winLen=20,zlemaN=10), visual=T)    #vermutlich super instabil !!
  
  ###########################################################################
  #parameter-names im title
  ###########################################################################
  Title<-function(main="RSI",arg,par,sym="")
  {
    p=sapply(names(par),FUN=function(nam) {sprintf("%s=%s",nam,toString(first(par[[nam]])))})
    title=paste(p,collapse=",")
    title = paste(main,title,sym,sep=": ", toString(as.Date(index(last(arg$clos)))))
    return(title)
  }
  ###################################################################################
  #Alternative zum MACD:
  #  mit kalmann-Filter
  
  #http://hosho.ees.hokudai.ac.jp/~kubo/Rdoc/library/dlm/html/dlmFilter.html
  
  #http://stats.stackexchange.com/questions/18387/whats-Sthe-difference-between-dlmsmooth-and-dlmfilter-in-rs-dlm-package
  #http://stats.stackexchange.com/questions/4296/r-code-for-time-series-forecasting-using-kalman-filter
  
  if (F)
  {
    head(Nile,20)
    
    library(dlm)
    new_Win()
    
    
    nileBuild <- function(par) {
      #random walk with white noise
      #dlmModPoly(1, dV = .3, dW = .01)
      dlmModPoly(1, dV = .95, dW = .01)
      #  dlmModPoly(1, dV = exp(par[1]), dW = exp(par[2]))
    }
    
    #head(Nile,30)
    Nile = ts(na.omit(prices$sx5r["2006/2010"]))
    nileMLE <- dlmMLE(Nile, rep(9,2), nileBuild); 
    nileMLE$conv
    nileMod <- nileBuild(nileMLE$par)
    V(nileMod)
    W(nileMod)
    nileFilt <- dlmFilter(Nile, nileMod)
    nileSmooth <- dlmSmooth(nileFilt)
    #str(cbind(Nile, nileFilt$m[-1], nileSmooth$s[-1]))
    plot(cbind(Nile, nileFilt$m[-1], nileSmooth$s[-1]), plot.type='s',
         col=c("black","red","blue"), ylab="Level", main="Nile river", lwd=c(1,2,2))
    
  }
  #####################################################################################
  ################## plotte return und stuer-Gr??e cprice in einem plot
  #####################################################################################
  
  Trade1.Plot<-function(cprices, t1,model) 
  {
    
    ylim=c( min(min(cprices), min(t1$Ret)),max(max(cprices),mamx(t1$Ret)))  
    plot(t1$Ret,ylim=ylim,main=sprintf("Return %s",model))  
    points(cprices, type = "l", col = "blue")
    signal = t1$Sig
    barplot(signal,col="blue",space = 0, border = "blue",xaxt="n",yaxt="n",xlab="",ylab="")
    
  }
  
  #undebug(guv)
  #guv(mROC(dax),pBenchRet=mROC(Rex),signal= signal)
  ################################################################################################################
  #gib renditen der isin, des benchmark, ein bin?res 0,1 signal und eine allocation
  #alles wird im chart ?ber die zeit angezeigt
  #################################################################################################################
  
  guv<-function(pRet, pBenchRet=NULL, signal=NULL,alloca=NULL,visible=F,indi=NULL)
  {
    name = colnames(pRet[,1])
    if (is.null(signal))
      signal = rep(1,nrow(pRet))
    signal = na.omit(signal)
    alloca = na.omit(alloca)
    pRet = na.omit(pRet)
    
    guv = as.xts(pRet*signal)
    
    GuVr = mRendite(na.omit(guv))
    cgar = last(GuVr);
    
    ret = mRendite(na.omit(pRet))
    if (!is.null(pBenchRet) )
      retB =mRendite(na.omit(mROC(pBenchRet)))
    else
      retB=NULL
    #Beschr?nke die items-liste auf solche elemente die ungleich NULL sind
    items = list( ret,retB,signal,alloca)
    items = items[which(unlist(lapply(items, FUN=function(x) !is.null(x))))]
    mR= na.omit(items)
    
    #mR = na.omit(merge(GuVr,ret,retB,signal,alloca))
    #GuVr = mR[,1]
    #ret =mR[,2]
    #retB = mR[,3]
    #  signal = mR[,4]
    # alloca = mR[,5]
    
    if (visible)
    {
      g_range <- range(mR)# GuVr,ret,retB)
      #browser()
      titel = sprintf("GuV %s %f",name,cgar)
      #windows()
      par(mfrow=c(1,1), oma=c(2,2,2,2),mar=c(2,2,2,2),col="black")
      xlim_ = c(index(last(GuVr)), index(first(GuVr)))
      plot(GuVr,ylim=g_range,pch=15,main= titel)
      if (!is.null(alloca))
      {
        par(new=T)
        lines(alloca,col="lightblue",ylim=range(alloca),type="h")
      }
      par(new=T)
      plot(GuVr,ylim=g_range,pch=15,main=titel)
      lines(ret,col=ifelse(signal <1, "blue", "red"),type="h")
      lines(ret,col="blue",type="l")
      
      par(new=T)
      lines(GuVr,col="green",ylim=g_range,lwd=3)
      if (!is.null(retB))
      {par(new=T)
       lines(retB,col="black",ylim=g_range)
      }
      
      if (!is.null(indi))
      { 
        indi = na.omit(indi)
        par(new=TRUE)
        irange =range(indi)
        plot(indi[,1],yaxt="n",xlab="",ylab="",xlim=xlim_, ylim =irange,main="", auto.grid=T,axes=F)
        for (i in 1:ncol(indi))
          lines(indi[,i],col="black",xlim =xlim_,ylim=irange,lwd=1)
      }
      
      
    } 
    return (guv)
  }
  
  
  if (F)
    breakChannel(dax,maxdd=10,t="2007-05-01::")
  
  #norm_Win(4)
  #longIndikator1= longIndikator[HighLows(longIndikator,maxdd=20,visual=T)$lows]
  #longIndikator2= longIndikator1[HighLows(longIndikator1,maxdd=20,visual=T)$lows]
  #longIndikator3= longIndikator2[HighLows(longIndikator2,maxdd=20,visual=T)$lows]
  
  #mPlot(scaleTo(longIndikator,c(1,0)))
  
  HighLowsOLD<-function(prices, maxdd=5,visual = F)
  {
    prices=scaleTo(prices,c(1,0)) #ohne Skalierung auf positive Werte klappt das alles nicht so gut
    
    zz=na.omit(ZigZag(prices,change=maxdd,percent=T))
    sig=as.vector(coredata(sign(zz-lag(zz))))  #segmente positiver und negativer steigung
    enc <-rle(sig)
    enc.endidx <- cumsum(enc$lengths)  #ending indices
    enc.startidx <- c(0, enc.endidx[1:(length(enc.endidx)-1)],length(prices))  # starting indices
    if (is.na(enc$values[1]))
      enc$values[1] = -1*enc$values[2]
    #markiere die higss- und lows- des zigzag in unterschiedlichen farben
    #  highx = na.omit(enc.endidx[enc$values > 0 ]) 
    #  highs = prices[highx] 
    zzPoints = prices[enc.startidx]
    cat( "\n HighLows-Segmente: ",len(zzPoints)," von punkten: ",len(prices))
    
    if (visual)
      plot(prices,type="h")
    #points(zzPoints,col="green",lwd=2)
    if (visual)
      lines(zzPoints,type="l",col="green",lwd=2)
    
    
    #markiere die higss- und lows- des zigzag in unterschiedlichen farben
    highx = na.omit(enc.endidx[enc$values > 0 ]) 
    
    lowx = na.omit(enc.endidx[enc$values < 0 ]) 
    lows = prices[lowx]
    
    if (first(lowx) < first(highx) )#|| first(prices)>prices[first(highx)])
    {
      highx = c(1,highx)
    }
    else
      lowx= c(1,lowx)
    
    if (visual)
    {
      points(prices[highx],col="red",lwd=1)
      points(prices[lowx],col="blue",lwd=1)
    }
    return(list(highs = highx,lows = lowx,hl=enc.endidx ))  
  }
  
  ################################
  #Berechne die Parameter eines Channel-Stop-Systems 
  #Berechne die historische G�te des StopSystems
  #Berechne den aktuellen Stop-Channel
  
  ################################
  
  breakChannel<-function(prices=edhec,t="2012", maxdd=10, visual=T)
  {
    prices=prices[sprintf("%s",t)]
    prices= prices[isWeekday(time(prices))]
    
    prices=mRendite(mROC(prices))
    
    zz=na.omit(ZigZag(prices,change=maxdd,percent=T))
    
    sig=as.vector(coredata(sign(zz-lag(zz))))  #segmente positiver und negativer steigung
    enc <-rle(sig)
    enc.endidx <- cumsum(enc$lengths)  #ending indices
    enc.startidx <- c(0, enc.endidx[1:(length(enc.endidx)-1)],length(prices))  # starting indices
    if (is.na(enc$values[1]))
      enc$values[1] = -1*enc$values[2]
    #markiere die higss- und lows- des zigzag in unterschiedlichen farben
    #  highx = na.omit(enc.endidx[enc$values > 0 ]) 
    #  highs = prices[highx] 
    zzPoints = prices[enc.startidx]
    
    plot(prices)
    #points(zzPoints,col="green",lwd=2)
    lines(zzPoints,type="l",col="red",lwd=2)
    
    
    #markiere die higss- und lows- des zigzag in unterschiedlichen farben
    highx = na.omit(enc.endidx[enc$values > 0 ]) 
    
    lowx = na.omit(enc.endidx[enc$values < 0 ]) 
    lows = prices[lowx]
    
    if (first(lowx) < first(highx) )#|| first(prices)>prices[first(highx)])
    {
      highx = c(1,highx)
    }
    else
      lowx= c(1,lowx)
    
    
    points(prices[highx],col="blue",lwd=2)
    points(prices[lowx],col="magenta",lwd=2)
    
    
    ########################################
    ## summiere alle long-Teil-St?cke der zz-Zerlegung auf ret
    ret=0
    
    alleSegmenteI =enc.endidx
    alleSegmenteI2 = alleSegmenteI
    #�ber alle Segmente des zigzack
    #berechne f�r jedes Segment die Streuung um die Regression-Line (mean-Reverter)
    lasti=1
    lastOKSegmentES=0
    segI=0
    #browser()
    
    for(i in alleSegmenteI) #�ber alle zz-Segmente
    {
      segI = segI+1
      if (i >first(alleSegmenteI))
      { 
        #browser()
        xxRet  =mROC(prices[lasti:i])
        xxPrices =prices[lasti:i,1]
        
        segx1 = lasti;
        segx2 = i
        
        if (visual)
          lines(xxPrices, col="yellow") #segmentabschnitt in gelb
        
        if (F)
        {
          reg=lm(xxPrices~c(lasti:i))    
          regfitted.values=reg$fitted.values
        }
        else#dynamisierte Version der Regression   #MMA 
        {
          if (F) #auf Tagesdaten
          {
            if(i-lasti > 10 )#&& i +10< len(prices))
            {
              regfitted.values = prices[c(lasti:(lasti+10-1))]
              for(i5 in seq(lasti+10:i)) #�ber alle Einzeltage des Segments
              {
                x5= c(lasti:i5)
                if (len(x5)> 10)
                {
                  y5 = prices[x5,1]
                  reg5=lm(y5~x5)
                  
                  regfitted.values = append(regfitted.values,last(reg5$fitted.values))
                }            
                #
                if (F) #TEST breakpoint
                  if (as.Date(time(prices[i5]))> as.Date("2009-03-01"))
                  {
                    lines(regfitted.values, col="blue")
                    lines(reg5$fitted.values,col="green")
                    browser()
                  }            
              }
            }
            else
              regfitted.values = prices[c(lasti:i)]
          }
          else
          {
            HL = HighLows(prices[seq(from=lasti,to=i)],maxdd= maxdd/5)
            cat("--> 1")
            browser()
            
            if(T)
            {
              regfitted.values=prices[lasti,1]
              
              #  ARBEIT  ##################################################
              
              len(prices)
              
              for(i5 in HL$highs)
              {
                dates =  HL$highs[HL$highs<=i5]
                yy= prices[dats]
                
                trainData = data.frame(yy,dats)
                colnames(trainData) <- c( "Y","X")
                X =  seq(from = i5, to=len(prices))
                predictData= data.frame(prices[X],X)
                
                mod <- lm(Y ~ X, data = trainData)
                m=coef(mod)[2]
                plot(yy)
                lines(as.xts(mod$fitted.values),col="red")
                
                pp = as.xts(predict(mod,newdata=predictData))
                mPlot(rbind(as.xts(mod$fitted.values),pp),rbind(yy,prices[X]))
                
                
                
                myFun3 <- function(x) {
                  x <- data.frame(x, xt=endpoints(x,"days")[-1])
                  mod= lm(Close ~ xt, x)
                  return(coef(mod)[2])
                }
                
                test1 <- rollapplyr(dax["2011::"], width=20, FUN=myFun2, by.column=FALSE)
                if (F) #TEST breakpoint
                  if (as.Date(time(prices[i5]))> as.Date("2009-03-01"))
                  {
                    lines(regfitted.values, col="blue")
                    lines(reg5$fitted.values,col="green")
                    browser()
                  }            
              }
            }
            else
              regfitted.values = prices[c(lasti:i)]
          }
        }
        if (F && visual)
          lines(regfitted.values, col="green")
        
        ddd = (max(xxPrices)-min(xxPrices))/2
        if (F && visual)
          lines(xxPrices-regfitted.values+max(xxPrices)-ddd,col="grey")
      }
      lasti=i
    }
    
    
    return (as.numeric(ret))
    
  }  
  
  
  if(F)
  {
    norm_Win()
    prices = mNorm(dax)
    colnames(prices)=c("Close")
    maxdd= 6
    head(prices)  
    
    HL = HighLows(prices,maxdd= maxdd)
    
    work1 <- function(y) {
      xt=endpoints(y,"days")[-1]
      x1 = first(xt)
      x2 = last(xt)
      xt=HL$highs[HL$highs >=x1 & HL$highs <=x2]  
      # browser()
      if (len(xt) >= 2) #gibts �berhaupt 2 stellen f�r die reg
      {
        y1=y[xt]
        cat(x1,x2, "segmente: ",len(xt), "\n")
        #browser()
        train <- data.frame(y1,xt )
        mod= lm(Close ~ xt, train)
      }
      return(y[x1])
      return(coef(mod)[2])
    }
    
    y=prices["2005::2007"]
    test1=3
    head(prices)
    work1(prices["2005::2007"])
    
    test1 <- rollapplyr(prices, width=400, FUN=work1, by.column=FALSE)
    head(test1)
    plot(test1)
    
    regfitted.values=prices[lasti,1]
    
    ARBEIT  ##MMA1 ####LowlongIndikator sauber auswerten############################################
    
    len(prices)
    
    dates =  HL$highs[HL$highs<=i5]
    yy= prices[dats]
    
    trainData = data.frame(yy,dats)
    colnames(trainData) <- c( "Y","X")
    X =  seq(from = i5, to=len(prices))
    predictData= data.frame(prices[X],X)
    
    mod <- lm(Y ~ X, data = trainData)
    m=coef(mod)[2]
    plot(yy)
    lines(as.xts(mod$fitted.values),col="red")
    
    pp = as.xts(predict(mod,newdata=predictData))
    mPlot(rbind(as.xts(mod$fitted.values),pp),rbind(yy,prices[X]))
    
    oDax=Dax
    
    mGetTickers("Dax","Rex")
    dat = mNorm(merge(Lo(Dax), Hi(Dax), Cl(Dax), Cl(Rex)))
    mPlot( dat)
    
    Dax=oDax
    
    Dax=DAX["2002::2006"]
    LoDax = mNorm(Lo(Dax))
    HiDax = mNorm(Hi(Dax))
    ClDax = mNorm(Cl(Dax))
    OpDax = mNorm(Op(Dax))
    longIndikator = HiDax-ClDax
    colnames(longIndikator) = "Close"
    
    norm_Win(2)
    mPlot(ClDax)
    lines(longIndikator*6+max(ClDax)/2,col="black")
    
    LowlongIndikator  = period.min(longIndikator,  endpoints(longIndikator,"months")) #MMA
    lines(LowlongIndikator*6+max(ClDax)/2,col="blue",type="h")
    mPlot(LowlongIndikator)
    
    #HighLows(longIndikator)
    lowLongIndikator= LowlongIndikator[HighLows(LowlongIndikator,maxdd=5,visual=T)$lows]
    
    lines(lowLongIndikator,col="green")
    
    reg=goodReturn(prices = LowlongIndikator, maxdd = 200, t = "", minReturn= 0.3, visual = T,checkSGB=T)
    
    
    myFun2 <- function(x) {
      n<<-n+1
      #cat(toString(as.Date(index(first(x)))), n, "\n")
      colnames(x) = "Close"
      
      train <- data.frame(x, xt=endpoints(x,"days")[-1])
      mod= lm(Close ~ xt, train)
      return(coef(mod)[2])
    }
    
    myFun3 <- function(x) {
      n<<-n+1
      #cat(toString(as.Date(index(first(x)))), n, "\n")
      colnames(x) = "Close"  
      train <- data.frame(x, xt=endpoints(x,"days")[-1])
      
      mod= lm(Close ~ xt, train)
      return(coef(mod)[2])
    }
    n=0;   test1 <- rollapplyr(LowlongIndikator, width=10, FUN=myFun3, by.column=FALSE)
    
    new_Win()
    mPlot( merge(ClDax, LowlongIndikator*100))
    lines(test1*1000,col="black",type="h")
    
    
    
    ########################
    myFun4 <- function(x) {
      n<<-n+1
      #cat(toString(as.Date(index(first(x)))), n, "\n")
      colnames(x) = "Close"
      i=as.integer(index(x))-firstIndex   #baut die korrekten IndexPositionen der sp�rlichen Extrema �ber die ich fitte
      train <- data.frame(x, xt=i)
      mod= lm(Close ~ xt, train)
      return(coef(mod)[2])
    }
    
    
    new_Win(2)
    lowLongIndikator= LowlongIndikator[HighLows(LowlongIndikator,maxdd=5,visual=T)$lows]
    n=0; firstIndex=as.integer(first(index(lowLongIndikator)));  test1 <- rollapplyr(lowLongIndikator, width=2, FUN=myFun4, by.column=FALSE)
    
    mPlot( merge(ClDax, LowlongIndikator*100))
    lines(scaleTo(ClDax,c(-2,2)), col="black")
    lines(scaleTo(test1,c(-2,2)),col="green",type="h",lwd=2)
    
    ######################
    
    #longIndikator1 = HiDax-LoDax# schwach - aber die Kr�mmung find ich interessant
    l1a  = scaleTo(LowlongIndikator,c(0,1))
    dax1 =   scaleTo(period.min(ClDax,  endpoints(ClDax,"months")),c(0,1))
    mchart(merge(l1a,dax1))
    mPlot(dax1,l1a)
    
    train <- data.frame( merge( dax1, l1))  
    colnames(train) = c("Y","xt")
    tail(train)
    
    mod= lm(Y ~ xt, train)
    summary(mod)
    plot(mod,which=1)
    #-------------------------------
    
    library(MASS)
    bcy<-boxcox(mod)
    
    
    ########################
    
    longIndikator2 =  HiDax-ClDax  #super
    l2  = scaleTo(period.min(longIndikator2,  endpoints(longIndikator2,"months")),c(-1,1))
    dax1 =   scaleTo(period.min(ClDax,  endpoints(ClDax,"months")),c(-1,1))
    mchart(na.omit(dax1))
    colnames(dax1)="dax1"
    purePlot(dax1,l2)
    
    train <- data.frame( merge( dax1, l2))# )  #lag(l2))  )
    colnames(train) = c("Y","xt")
    tail(train)
    
    mod= lm(Y ~ xt, train)
    summary(mod)
    plot(mod, which=1)
    ########################
    
    longIndikator3 =  LoDaHiDax
    l3  = scaleTo(period.min(longIndikator3,  endpoints(longIndikator3,"months")),c(-1,1))
    dax1 =   scaleTo(period.min(ClDax,  endpoints(ClDax,"months")),c(-1,1))
    mPlot(dax1,l3)
    
    train <- data.frame( merge( dax1, lag (l3)))# )  #lag(l2))  )
    colnames(train) = c("Y","xt")
    tail(train)
    
    mod= lm(Y ~ xt, train)
    summary(mod)
    plot(mod, which=1)
    
  }


  #############################################################################################
  #source("Mlib/mlist.R")
  
  mP("########### load Trade.R")
  source("Mlib/sysRun.r")

  #source("Mlib/Now.R")
  