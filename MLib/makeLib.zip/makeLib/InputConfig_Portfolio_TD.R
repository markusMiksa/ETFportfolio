

options(error = quote({
  #  sink(file="error.txt");
  dump.frames();
  print(attr(last.dump,"error.message"));
  traceback();
  #  sink(); 
})) 
options(warn=1)

library(gdata)
library(XLConnect)
#sessionInfo()
#vignette("sos")
#RSiteSearch("sos")
#installXLSXsupport()
##Einf?hrung:  http://freecode.com/articles/creating-charts-and-graphs-with-gnu-r
if (FALSE) 
{
  
  #C:\Program Files\R\R-3.0.1
  #c:\Users\markus\Documents\R\win-library\
  
  
  #install.packages('rgarch')#macht nen bug sp?ter weil xts first,last ?berdeckt nicht mehr vorh.und r.3
  try(detach("package:xts"),TRUE)
  #require(xts) 
  install.packages("gdata")
  #install.packages('quantmod') 
  #install.packages('RODBC')
  #library(zoo)
  install.packages('TTR')  
  install.packages('debug')  
  install.packages('RODBC')
  #install.packages('qmao')  #nicht unter 3
  
  #macht in excel aus einem umgeleiteten Dir
  #="install.packages('"&TRIM(MID(A8;SEARCH("<DIR> ";A8)+5;LEN(A8)))&"') "
  install.packages('gtools')
  
  install.packages('abind') 
  install.packages('Rcpp') 
  install.packages('acepack') 
  install.packages('AER') 
  install.packages('akima') 
  install.packages('alr3') 
  install.packages('anchors') 
  install.packages('ape') 
  install.packages('aplpack') 
  install.packages('backtest') 
  install.packages('BayesX') 
  install.packages('bdsmatrix') 
  install.packages('biglm') 
  install.packages('BiocInstaller') 
  install.packages('bit') 
  install.packages('bitops') 
  install.packages('car') 
  install.packages('caTools') 
  install.packages('chron') 
  install.packages('cmprsk') 
  install.packages('coda') 
  install.packages('coin') 
  install.packages('colorRamps') 
  install.packages('colorspace') 
  install.packages('CompQuadForm') 
  install.packages('coxme') 
  install.packages('cubature') 
  install.packages('data.table') 
  install.packages('DBI') 
  install.packages('Deducer') 
  install.packages('DeducerExtras') 
  install.packages('DeducerPlugInScaling') 
  install.packages('Defaults') 
  install.packages('degreenet') 
  install.packages('deldir') 
  install.packages('DEoptim') 
  install.packages('devtools') 
  install.packages('dichromat') 
  install.packages('digest') 
  install.packages('diptest') 
  install.packages('dlm') 
  install.packages('dlmodeler') 
  install.packages('doSMP') 
  install.packages('doSMP1') 
  install.packages('doSNOW') 
  install.packages('dtw') 
  install.packages('dyn') 
  install.packages('dynlm') 
  install.packages('e1071') 
  install.packages('Ecdat') 
  install.packages('effects') 
  install.packages('ellipse') 
  install.packages('ergm') 
  install.packages('evaluate') 
  install.packages('events') 
  install.packages('expsmooth') 
  install.packages('FactorAnalytics') 
  install.packages('fAsianOptions') 
  install.packages('fAssets') 
  install.packages('fBasics') 
  install.packages('fCopulae') 
  install.packages('fExoticOptions') 
  install.packages('fExtremes') 
  install.packages('fftw') 
  install.packages('fGarch') 
  install.packages('fgui') 
  install.packages('fields') 
  install.packages('fImport') 
  install.packages('flexmix') 
  install.packages('fMultivar') 
  install.packages('fNonlinear') 
  install.packages('fOptions') 
  install.packages('foreach') 
  install.packages('forecast') 
  install.packages('formatR') 
  install.packages('Formula') 
  install.packages('fPortfolio') 
  install.packages('fRegression') 
  install.packages('fSeries') 
  install.packages('fTrading') 
  install.packages('fUnitRoots') 
  install.packages('gam') 
  install.packages('gbm') 
  install.packages('gclus') 
  install.packages('gdata') 
  install.packages('gee') 
  install.packages('geoR') 
  install.packages('geoRglm') 
  install.packages('ggplot2') 
  install.packages('gpclib') 
  install.packages('gplots') 
  install.packages('gtable') 
  install.packages('gtools') 
  install.packages('gWidgets') 
  install.packages('gWidgetsRGtk2') 
  install.packages('gWidgetstcltk') 
  install.packages('hash') 
  install.packages('heatmap.plus') 
  install.packages('helpr') 
  install.packages('hergm') 
  install.packages('hexbin') 
  install.packages('HH') 
  install.packages('highlight') 
  install.packages('Hmisc') 
  install.packages('HSAUR') 
  install.packages('ineq') 
  install.packages('inline') 
  install.packages('ipred') 
  install.packages('irr') 
  install.packages('irutils') 
  install.packages('ISwR') 
  install.packages('iterators') 
  install.packages('itertools') 
  install.packages('its') 
  install.packages('jbryer-irutils-95e4309') 
  install.packages('JGR') 
  install.packages('Kendall') 
  install.packages('kernlab') 
  install.packages('KFAS') 
  install.packages('klaR') 
  install.packages('knitr') 
  install.packages('labeling') 
  install.packages('latentnet') 
  install.packages('latticeExtra') 
  install.packages('lawstat') 
  install.packages('leaps') 
  install.packages('lgtdl') 
  install.packages('lme4') 
  install.packages('lmtest') 
  install.packages('locfit') 
  install.packages('logspline') 
  install.packages('lpSolve') 
  install.packages('mapproj') 
  install.packages('maps') 
  install.packages('maptools') 
  install.packages('matrixcalc') 
  install.packages('MatrixModels') 
  install.packages('maxLik') 
  install.packages('mboost') 
  install.packages('mclust') 
  install.packages('MCMCpack') 
  install.packages('memoise') 
  install.packages('MEMSS') 
  install.packages('mhsmm') 
  install.packages('mice') 
  install.packages('misc3d') 
  install.packages('miscTools') 
  install.packages('mitools') 
  install.packages('mix') 
  install.packages('mlbench') 
  install.packages('mlmRev') 
  install.packages('mlogit') 
  install.packages('mnormt') 
  install.packages('modeltools') 
  install.packages('MPV') 
  install.packages('MSBVAR') 
  install.packages('msm') 
  install.packages('multcomp') 
  install.packages('munsell') 
  install.packages('mvbutils') 
  install.packages('mvna') 
  install.packages('mvnormtest') 
  install.packages('mvtnorm') 
  install.packages('network') 
  install.packages('networkDynamic') 
  install.packages('networksis') 
  install.packages('nor1mix') 
  install.packages('np') 
  install.packages('numDeriv') 
  install.packages('nws') 
  install.packages('openNLP') 
  install.packages('PairTrading') 
  install.packages('parser') 
  install.packages('party') 
  install.packages('PBSmapping') 
  install.packages('penalized') 
  install.packages('PerformanceAnalytics') 
  install.packages('plm') 
  install.packages('plyr') 
  install.packages('png') 
  install.packages('polspline') 
  install.packages('polycor') 
  install.packages('pomp') 
  install.packages('PortfolioAnalytics') 
  install.packages('prodlim') 
  install.packages('proto') 
  install.packages('pscl') 
  #install.packages('qmao') 
  install.packages('quadprog') 
  install.packages('quantmod') 
  install.packages('quantreg') 
  install.packages('R2wd') 
  install.packages('RandomFields') 
  install.packages('randomForest') 
  install.packages('randtoolbox') 
  install.packages('RANN') 
  install.packages('RArcInfo') 
  install.packages('rbenchmark') 
  install.packages('Rcmdr') 
  install.packages('RColorBrewer') 
  install.packages('rcom') 
  install.packages('Rcpp') 
  install.packages('RcppArmadillo') 
  install.packages('Rdonlp2') 
  install.packages('relevent') 
  install.packages('relimp') 
  install.packages('reshape') 
  install.packages('reshape2') 
  install.packages('revoIPC') 
  install.packages('RExcelInstaller') 
  install.packages('rgarch') 
  install.packages('rgdal') 
  install.packages('rgenoud') 
  install.packages('rgeos') 
  install.packages('rgl') 
  install.packages('Rglpk') 
  install.packages('rj') 
  install.packages('rj.gd') 
  install.packages('rJava') 
  install.packages('rlecuyer') 
  install.packages('rmeta') 
  install.packages('rms') 
  install.packages('rngWELL') 
  install.packages('robustbase') 
  install.packages('ROCR') 
  install.packages('RODBC') 
  install.packages('roxygen2') 
  install.packages('rpanel') 
  install.packages('rparallel') 
  install.packages('RQuantLib') 
  install.packages('rscproxy') 
  install.packages('Rserve') 
  install.packages('Rsolnp') 
  install.packages('rsprng') 
  install.packages('RSQLite') 
  install.packages('RthroughExcelWorkbooksInstaller') 
  install.packages('RUnit') 
  install.packages('sampleSelection') 
  install.packages('sandwich') 
  install.packages('scales') 
  install.packages('scatterplot3d') 
  install.packages('sem') 
  install.packages('sfsmisc') 
  install.packages('sgeostat') 
  install.packages('shapefiles') 
  install.packages('shapes') 
  install.packages('sinartra') 
  install.packages('slam') 
  install.packages('sm') 
  install.packages('sn') 
  install.packages('sna') 
  install.packages('snow') 
  install.packages('snowfall') 
  install.packages('snowFT') 
  install.packages('sp') 
  install.packages('spam') 
  install.packages('SparseM') 
  install.packages('spatstat') 
  install.packages('spdep') 
  install.packages('splancs') 
  install.packages('stabledist') 
  install.packages('statmod') 
  install.packages('statnet') 
  install.packages('stockPortfolio') 
  install.packages('stringkernels') 
  install.packages('stringr') 
  install.packages('strucchange') 
  install.packages('subplex') 
  install.packages('subselect') 
  install.packages('SuppDists') 
  install.packages('survey') 
  install.packages('survival') 
  install.packages('systemfit') 
  install.packages('tcltk2') 
  install.packages('TeachingDemos') 
  install.packages('testthat') 
  install.packages('timeDate') 
  install.packages('timeSeries') 
  install.packages('tkrplot') 
  install.packages('tpr') 
  install.packages('tripack') 
  install.packages('truncnorm') 
  install.packages('truncreg') 
  install.packages('trust') 
  install.packages('TSA') 
  install.packages('tsDyn') 
  install.packages('tseries') 
  install.packages('tseriesChaos') 
  install.packages('TTR') 
  install.packages('ttrTests') 
  install.packages('tweedie') 
  install.packages('twsInstrument') 
  install.packages('urca') 
  install.packages('vars') 
  install.packages('vcd') 
  install.packages('VGAM') 
  install.packages('VIM') 
  install.packages('xlsReadWrite') 
  install.packages('xlsx') 
  install.packages('xlsxjars') 
  install.packages('XML') 
  install.packages('xtable') 
  install.packages('xts') 
  install.packages('Zelig') 
  install.packages('zoo') 
  install.package("gplots")
  install.package("XLConnect")
  
  install.packages("futile")
  install.packages("Futile.logger")
  install.packages("BurStFin")
  install.packages("reshape")
  install.packages("sos")
  install.packages("PortfolioAnalytics")
  install.packages("NMOF") 
  install.packages("pracma")
  
  install.packages("XLConnect")
  install.packages("rChart")
  install.packages("Quandl")
  install.packages("doParallel")
  install.packages("foreach")
  install.packages("MASS")
  install.packages("grnn")
  install.packages("xtsExtra", repos="http://R-Forge.R-project.org")
  install.packages("rattle")
  install.packages("rattle", dependencies = c("Depends", "Suggests"))
  daraus.folgt="
  package 'sets' successfully unpacked and MD5 sums checked
package 'Rsymphony' successfully unpacked and MD5 sums checked
package 'relations' successfully unpacked and MD5 sums checked
  package 'TSP' successfully unpacked and MD5 sums checked
  package 'igraphdata' successfully unpacked and MD5 sums checked
  package 'jpeg' successfully unpacked and MD5 sums checked
  package 'clue' successfully unpacked and MD5 sums checked
  package 'igraph0' successfully unpacked and MD5 sums checked
  package 'oz' successfully unpacked and MD5 sums checked
  package 'randomSurvivalForest' successfully unpacked and MD5 sums checked
  package 'glmnet' successfully unpacked and MD5 sums checked
  package 'pmmlTransformations' successfully unpacked and MD5 sums checked
  package 'seriation' successfully unpacked and MD5 sums checked
  package 'igraph' successfully unpacked and MD5 sums checked
  package 'flexclust' successfully unpacked and MD5 sums checked
  package 'isa2' successfully unpacked and MD5 sums checked
  package 'trimcluster' successfully unpacked and MD5 sums checked
  package 'prabclus' successfully unpacked and MD5 sums checked
  package 'tclust' successfully unpacked and MD5 sums checked
  package 'DAAG' successfully unpacked and MD5 sums checked
  package 'waveslim' successfully unpacked and MD5 sums checked
  package 'CircStats' successfully unpacked and MD5 sums checked
  package 'clv' successfully unpacked and MD5 sums checked
  package 'pmml' successfully unpacked and MD5 sums checked
  package 'ada' successfully unpacked and MD5 sums checked
  package 'amap' successfully unpacked and MD5 sums checked
  package 'arules' successfully unpacked and MD5 sums checked
  package 'arulesViz' successfully unpacked and MD5 sums checked
  package 'biclust' successfully unpacked and MD5 sums checked
  package 'cairoDevice' successfully unpacked and MD5 sums checked
  package 'cba' successfully unpacked and MD5 sums checked
  package 'descr' successfully unpacked and MD5 sums checked
  package 'doBy' successfully unpacked and MD5 sums checked
  package 'fpc' successfully unpacked and MD5 sums checked
  package 'ggdendro' successfully unpacked and MD5 sums checked
  package 'hmeasure' successfully unpacked and MD5 sums checked
  package 'latticist' successfully unpacked and MD5 sums checked
  package 'odfWeave' successfully unpacked and MD5 sums checked
  package 'playwith' successfully unpacked and MD5 sums checked
  package 'rggobi' successfully unpacked and MD5 sums checked
  package 'RGtk2Extras' successfully unpacked and MD5 sums checked
  package 'rpart.plot' successfully unpacked and MD5 sums checked
  package 'Snowball' successfully unpacked and MD5 sums checked
  Warning in install.packages :
  package 'verification' successfully unpacked and MD5 sums checked
  package 'weightedKmeans' successfully unpacked and MD5 sums checked
  package 'rattle' successfully unpacked and MD5 sums checked"
  
  install.packages("caret", dependencies = c("Depends", "Suggests"))
  daraus.folgt=
    "package 'tensorA' successfully unpacked and MD5 sums checked
  package 'energy' successfully unpacked and MD5 sums checked
  package 'BRugs' successfully unpacked and MD5 sums checked
  package 'compositions' successfully unpacked and MD5 sums checked
  package 'robCompositions' successfully unpacked and MD5 sums checked
  package 'R2WinBUGS' successfully unpacked and MD5 sums checked
  package 'plotmo' successfully unpacked and MD5 sums checked
  package 'plotrix' successfully unpacked and MD5 sums checked
  package 'partykit' successfully unpacked and MD5 sums checked
  package 'locfdr' successfully unpacked and MD5 sums checked
  package 'flsa' successfully unpacked and MD5 sums checked
  package 'pcaPP' successfully unpacked and MD5 sums checked
  package 'mvoutlier' successfully unpacked and MD5 sums checked
  package 'glasso' successfully unpacked and MD5 sums checked
  package 'entropy' successfully unpacked and MD5 sums checked
  package 'fdrtool' successfully unpacked and MD5 sums checked
  package 'arm' successfully unpacked and MD5 sums checked
  package 'Boruta' successfully unpacked and MD5 sums checked
  package 'bst' successfully unpacked and MD5 sums checked
  package 'C50' successfully unpacked and MD5 sums checked
  package 'Cubist' successfully unpacked and MD5 sums checked
  package 'earth' successfully unpacked and MD5 sums checked
  package 'elasticnet' successfully unpacked and MD5 sums checked
  package 'evtree' successfully unpacked and MD5 sums checked
  package 'extraTrees' successfully unpacked and MD5 sums checked
  package 'fastICA' successfully unpacked and MD5 sums checked
  package 'foba' successfully unpacked and MD5 sums checked
  package 'glmnet' successfully unpacked and MD5 sums checked
  package 'hda' successfully unpacked and MD5 sums checked
  package 'HDclassif' successfully unpacked and MD5 sums checked
  package 'HiDimDA' successfully unpacked and MD5 sums checked
  package 'kknn' successfully unpacked and MD5 sums checked
  package 'kohonen' successfully unpacked and MD5 sums checked
  package 'KRLS' successfully unpacked and MD5 sums checked
  package 'lars' successfully unpacked and MD5 sums checked
  package 'LogicReg' successfully unpacked and MD5 sums checked
  package 'mda' successfully unpacked and MD5 sums checked
  package 'neuralnet' successfully unpacked and MD5 sums checked
  package 'nodeHarvest' successfully unpacked and MD5 sums checked
  package 'obliqueRF' successfully unpacked and MD5 sums checked
  package 'pamr' successfully unpacked and MD5 sums checked
  package 'partDSA' successfully unpacked and MD5 sums checked
  package 'penalizedLDA' successfully unpacked and MD5 sums checked
  package 'pls' successfully unpacked and MD5 sums checked
  package 'protoclass' successfully unpacked and MD5 sums checked
  package 'qrnn' successfully unpacked and MD5 sums checked
  package 'quantregForest' successfully unpacked and MD5 sums checked
  package 'relaxo' successfully unpacked and MD5 sums checked
  package 'rFerns' successfully unpacked and MD5 sums checked
  package 'rocc' successfully unpacked and MD5 sums checked
  package 'rrcov' successfully unpacked and MD5 sums checked
  package 'RRF' successfully unpacked and MD5 sums checked
  package 'rrlda' successfully unpacked and MD5 sums checked
  package 'RSNNS' successfully unpacked and MD5 sums checked
  package 'sda' successfully unpacked and MD5 sums checked
  package 'SDDA' successfully unpacked and MD5 sums checked
  package 'sparseLDA' successfully unpacked and MD5 sums checked
  package 'spls' successfully unpacked and MD5 sums checked
  package 'stepPlr' successfully unpacked and MD5 sums checked
  package 'superpc' successfully unpacked and MD5 sums checked
  package 'caret' successfully unpacked and MD5 sums checked"
  
  install.packages("Rcmdr")
  #library(Rcmdr)  #startet die Gui
  
  install.packages("TSclust")   #zeitreihen-abst�nde
  install.packages("GenSA")
  install.packages("GenSA")
  install.packages("SmarterPoland")
  #gui
  install.packages("Deducer", dependencies = c("Depends", "Suggests"))
  
  ##################
  #sehr interessant:
  
  #  http://www.unstarched.net/r/dbm/
  #  #https://r-forge.r-project.org/softwaremap/trove_list.php
  #  https://r-forge.r-project.org/R/?group_id=1721
  
  
  #install.packages("TEATIME", source = "http://r-forge.r-project.org")
  #install.packages("dbm")
  #install.packages("tsanalysis", source = "http://r-forge.r-project.org")
  install.packages("RCurl")
  install.packages("googleVis")
  install.packages("date")
  install.packages("dbm","https://r-forge.r-project.org/R/?group_id=1721")
  install.packages("fastICA") 
  install.packages("sqldf") #http://www.r-bloggers.com/how-to-select-and-merge-r-data-frames-with-sql/ 
  install.packages("mvtnorm")
  install.packages("FinancialInstrument")
  install.packages("SmarterPoland")
  #  install.packages("fasttime")
}

library("RCurl")
#library("GTrendsR")

library(PerformanceAnalytics)
#data(edhec)
#charts.PerformanceSummary(edhec[,c(1,13)])

library(forecast)
library(gplots)
library(heatmap.plus)
require(ggplot2)
#require(XLConnect)
library(methods)
library(data.table)
library(RColorBrewer)
library(xts)
library(SmarterPoland)

#library(plyr)

library(vars)
library (RODBC)
library(stringr) #file:///C:/Users/markus/Documents/R/win-library/2.14/stringr/html/00Index.html
require(quantmod)

#require(PortfolioAnalytics)
require(lattice)
require(latticeExtra)
require(colorRamps)
library(XML)
library(hash)
library(chron)
library(timeDate)
#library(fUnitRoots)  mach PerformanceAnalytics kaputt
library(compiler)
library(TTR)
#library(futile)
#library(PerformanceAnalytics)
library("stringr")
library("caTools")
#library(tawny)

#library(futile.logger) #http://cartesianfaith.wordpress.com/2013/03/10/better-logging-in-r-aka-futile-logger-1-3-0-released/
if (F)
{
  #  library(tawny)
  #  library(fractalrock)
  prices <- getPortfolioPrices(LETTERS[1:10], 100)
  returns <- apply(prices,2,Delt)[-1,]
  s <- cov.shrink(as.xts(returns,order.by=index(prices)[-1]))
  flog.threshold(WARN, name='tawny')
  s <- cov.shrink(as.xts(returns,order.by=dates[-1]))
  flog.info("Got covariance matrix")
}

#library(tawny)
library("sos")    
#findFn("hurst exponent")  
#hurst(brown72)                    #in pracma   # 0.7385   # 0.720
#hurstexp(brown72, d = 128)

library(NMOF) 
library(pracma)

library(urca)  #johansen ca.co
#lade charts.PerformanceSummaryX  . die j?hrliche Balkengrafik des Retunrs
#library(qmao)
library(foreach)
library(parallel)

options(show.error.messages = TRUE)
#con = gzcon(url('https://github.com/systematicinvestor/SIT/raw/master/sit.gz', 'rb'))

#con = gzcon(file('../frameworks/SystematicInvestorToolbox/code.r', 'rb'))
con = gzcon(file('SysInvestor/code.r', 'rb'))

source(con)
print("########### load SysInvestor code")
close(con) 
source("MLib/SITpatches.r")


last = xts::last    #wird leider von data.table ungut ?beladen!!



options(error = quote({
  #  sink(file="error.txt");
  dump.frames();
  print(attr(last.dump,"error.message"));
  traceback();
  #  sink();
}))



#charts.PerformanceSummary(RF(getSymbols(c("QQQ","EWG","EWI"))))
#Very nice! Thank you for creating this package.
#The chart_Series function (note the underscore) can also handle multipletime series

#getSymbols(c("SPY","DIA"))

# This will put 2 price series on a chart
#thm <- chart_theme()
#thm$col$line.col <- 'lightblue'
#chart_Series(Cl(SPY),theme=thm)
#add_Series(Cl(DIA),on=1)


# Function to compute percentage returns

#Renditen:    Aktuelle/Gestern - 1     //  Returns:     CumProd (davon)


pchange <- function(x) { exp(diff(log(x)))-1 }

#ifelse(4,32,3)
#iif(as.xts(prices)> 6980, 1, as.xts(prices))
#return-Berechnung mit Ausrei?erentfernung 
#mROC <- function(clos) na.omit(Return.clean( na.omit( clos / iif( mlag(clos)==0,NA,mlag(clos)) - 1), method = "geltner", n=20)) #identisch   Return.calculate(prices, method="simple")
#mROC <-function(clos) Return.clean( na.omit( ROC(clos,type="discrete")), method = "geltner", n=20) #identisch   Return.calculate(prices, method="simple")

#r=na.omit(ROC(data$prices))
#min(abs(r))
#r[r==0]<-0.00000001

#mROC <-function(clos) {ret=na.omit(ROC(clos,type="discrete")); ret[which(!is.finite(ret))]<-0.00000001; ret[ret==0]<-0.00000001;return(ret)} #identisch  Return.calculate(prices, method="simple")


mROC <-function(clos,n=1,type="discrete") {ret= ROC(x=clos,n=n,type=type); r=apply(ret,2,FUN=function(x) { x[which(!is.finite(x))]<-0.00000001;x[x==0]<-0.00000001;x}); return(xts(r,order.by=as.Date(rownames(r)))) }

#Return.cumulative(geometric=
#Return.calculate(method="discrete") #log
#chart.ChumReturns
## so gebaut, dass    min(abs(r))  > 0 ist - weil sonst cumprod in mRendite auf Grund l�uft
#mRendite <-function(ret) (cumprod(na.omit(ret)+1)-1) #identisch Return.cumulative(R, geometric = T)
mRendite <-function(ret) (cumprod(ret+1)) #identisch Return.cumulative(R, geometric = T)

#(mRoc und mRendite geh�ren zusammen)

mNorm<-function(clos){ mRendite (mROC(clos))}
mNormCleaned<-function(clos){ mRendite ( Return.clean(mROC(clos), method="boudt"))}

mReturn<-function(prices) {return(na.omit(prices / mlag(prices) - 1))}


#if (geometric) 
#  Return.cumulative = cumprod(1 + x)
#else Return.cumulative = 1 + cumsum(x)


mLogReturn<-function(prices) { return(na.omit(diff(log(prices))))}
mLogRendite<-function(ret) cumsum(na.omit(ret))+1
mNorm2<-function(clos){ mLogRendite (mLogReturn(clos))}

#ret <- ROC(clos)
RocRen <-function(ret) exp(cumsum(ret))
library(quantmod)
#TTR::ROC
setDefaults(ROC, type="discrete")
useDefaults(ROC)
#ROC(1:10)
#CUD
###############################################################################
#http://stackoverflow.com/questions/5162583/is-it-posible-to-optimize-vectorize-
#these-two-functions-for-better-performance
#For the first function you're looking for the cumulative number of periods 
#during which series x is lower/higher than y. For that you can use this handy 
#function CumCount() built from cummax. First some sample data:
###############################################################################

CumCount <- function(x) {
  z <- cumsum(x)
  z - cummax(z*(!x))
}

#set.seed(1)
#x <- sample(1:5,20,T)
#y <- sample(1:5,20,T)
#CumLow = CumCount(x<y)
#CumHigh = CumCount(x>y)

#################################################################
#This little function returns a list with:

#high the index number of high dates
#recentHigh the index number of the most recent high day
#daysSince the number of days since the last high
#data an xts object with only the high days. Useful for plotting.
#aus:http://stackoverflow.com/questions/7354368/how-to-calculate-periods-since-200-period-high-of-a-stock

##################################################################

daysSinceHigh <- function(data, days){
  
  highs <- days-1+which(apply(embed(data, days), 1, which.max)==1)
  recentHigh <- max(highs)
  daysSince <- nrow(data) - recentHigh
  list(
    highs=highs,
    recentHigh = recentHigh,
    daysSince = daysSince,
    data=data[highs, ])
}       

#wie viele Tage sind seid dem letzten n Tage - hoch vergangen
daysSinceHigh_ <- function(x, n){
  apply(embed(x, n), 1, which.max)-1
}

#  daysSinceHigh(Data, 200)$daysSince

#plot(Data)
#points(daysSinceHigh(Data, 200)$data, col="red")


############### wenn R auf verbotene Indizes zur?ckgreift kommt als Return ein integer(0) 
##### wie findet man das ?  (?ber len (0))
# is.ok(zugriff)
#######################################################################################
is.ok<-function(x)  return( length(x) > 0)

#is.ok(matrix(4,4)[0,1])

mP<-function(...)
{
  
  #browser()
  tryM(print(sprintf(...)))
}

###############################################################################
# Split string into tokens using delim
###############################################################################
spl <- function
(
  s,      # input string
  delim = ','  # delimiter
)
{ 
  return(unlist(strsplit(s,delim))); 
}
###############################################################################
mm.strFind<-function(pat,s)
{
  if (is.null(s) || len(s)==0)
    return(F)
  return(  grepl(pat, s)[1])
}
###############################################################################
# Load Packages that are available and install ones that are not available.
############################################################################### 
load.packages <- function
(
  packages, 							# names of the packages separated by comma
  repos = "http://cran.r-project.org",# default repository
  dependencies = "Depends",				# install dependencies
  ...									# other parameters to install.packages
)
{
  packages = spl(packages)
  for( ipackage in packages ) {
    if(!require(ipackage, quietly=TRUE, character.only = TRUE)) {
      install.packages(ipackage, repos=repos, dependencies=dependencies, ...) 
      
      if(!require(ipackage, quietly=TRUE, character.only = TRUE)) {
        stop("package", sQuote(ipackage), 'is needed.  Stopping')
      }
    }
  }
}


load.packages('quadprog,lpSolve')


#########################################################################################################
#Lade aus Yahoo die Liste mit den Symbolen der IndexMember
#########################################################################################################
if (F)
  getIndexComposition("^DJI")
#getIndexComposition("ALV.DE")

getIndexComposition<-function(index) 
{
  url <- paste("http://uk.finance.yahoo.com/q/cp?s=", index, sep="") 
  #symbols <- readHTMLTable(url, as.data.frame=FALSE)[[10]]$Symbol 
  symbols <- readHTMLTable(url, as.data.frame=FALSE)
#  browser()  
  
  ret=  (symbols[[8]])[[1]]
  ret = ret[-c(1,2)]
  longname=((((symbols[[8]]))[[2]])[-c(1,2)])
  print ((((symbols[[8]]))[[2]])[-c(1,2)])
  universe=data.table(symbol=ret,longname=longname)
  mP("############# universe is at clibboard ###################### !!!!")
  writeClipboard(as.matrix(universe))
  View(universe)
  return (c(index,ret))
  
}
####################################################################
####################################################################

get.Index.data<-function(index="^GDAXI")
{
tickers=getIndexComposition(index)
data <- new.env()
mP("download tickers")
getSymbols(tickers, src = 'yahoo', from = '1980-01-01', env = data, auto.assign = T)
mP("tickers loaded")
for(i in ls(data)) data[[i]] = adjustOHLC(data[[i]], use.Adjusted=T)                           
bt.prep(data, align='keep.all', dates='2000::')
return (data)
}
#schreib die stoxxL- Liste als Universe.txt...
####################################################################
#Schreibe die IndexMember ein Yahoo-Index als Yahoo-Namen als Zeitreihen nach MData und als Univers.csv  nach MData/IndexMember
####################################################################
if (F)
  writeIndexComposition("^GDAXI")
if (F)
  writeIndexComposition("Dax")

####################################################################
writeIndexComposition<-function(index="^GDAXI", universeFile = "") #MMA 
{
  indexProvider = getProviderTicker(index)  
  index = indexProvider$tick
  
  if (universeFile =="")
    universeFile = sprintf("MData/IndexMember/%s.csv", indexProvider$name)

  dir.create(dirname(universeFile),recursive=T)
  mP("\n writeIndexCompositions for %s",index)
  ticks=getIndexComposition(index)
  
  #lade die Aktien (IndexMember) runter .. f�r Aktien sind die yahoo-K�rzel eh Standard - da muss nicht extra was in der securities.xls angelegt werden.
  
  if (len(ticks > 0))
    k=sapply(ticks,FUN=function(x) try(mGetTickers(x,online=T)))
  
  
  if (len(ticks)>0 && universeFile != "")
  {
    #browser()
    ticks = sapply(ticks,normaliseTickerName)
    
    ticks = lapply(ticks,FUN=function(x) return( toupper(x)))
    m = cbind(ticks)
    colnames(m)<-c("member")
    write.table(m,file=universeFile,row.names=F,quote=T)
    #sprintf("o:/R/Nuggets/Eckhard/Models/%s/universe.csv",modelDir)
    #writeIndexComposition("^GDAXI",universeFile =sprintf("o:/R/Nuggets/Eckhard/Models/%s/universe.csv",modelDir))
    
  }
  print(coredata(k))
  return(list(ticks))
}



#########################################################################################################

#########################################################################################################

Tickers<-NULL
#tickers<-NULL #die globale Liste der via DB geladenen Ticker xts- Reihen

#########################################################################################################

#########################################################################################################

startsWith <-function (name, stri)
{
  ret<-str_locate(name,stri)[1]
  if (is.na(ret))
    return (FALSE)
  if (1==str_locate(name,stri)[1])
    return (TRUE)
  return (FALSE)
}

#unlist(strsplit("eur=x","="))[1]

#########################################################################################################

#########################################################################################################

BusinessDays <- function(x, y){
  DateVector <- seq(min(c(as.Date(x), as.Date(y))), to = max(c(as.Date(x), as.Date(y))), by = "day")
  return (DateVector[!sapply(DateVector,is.weekend)])
}
########################################################################
#verichte z.B. die highs,lows- Zeitreihen zu einer spalte
#################################
joinRows<-function(XTS)
{
  #  browser()
  res=apply(XTS,1,FUN=function(r) sum(na.omit(r)))
  if (is.xts(XTS))
    res = as.xts(res)
  res
}

#########################################################################################################

countBusinessDays <- function(x, y, holidays=NULL){
  DateVector <- seq(min(c(as.Date(x), as.Date(y))), to = max(c(as.Date(x), as.Date(y))), by = "day")
  if(is.null(holidays))
    holidays <- rep(FALSE, length(DateVector))
  else
    holidays <- DateVector %in% holidays
  length(DateVector) - length(which(as.POSIXlt(DateVector)$wday %in% c(0, 6) | holidays))-1
}

#################################################################
#load stoxx timeseries to xts
#################################################################
readStoxx<-function(sym,tick)
{
  #sym="sx8p"
  #http://www.stoxx.com/download/historical_values/h_ctb_sxagr.txt
  
  url=sprintf("http://www.stoxx.com/download/historical_data/h_%s.txt",tick)
  
  print(url)
  x=read.csv(sep=";",dec=".",header=T,url)
  X=x  
  print(head(x,3))
  #x=x[-c(1,3)]
  datum=x[,1]
  
  if (is.null(row.names(X)))
  {x =x$Indexvalue
   symbol = x$Symbol[1]
   mP("row.names is null")
  }
  else
  {  symbol = x[1,1]; x =x[,2] 
     print(head(row.names(X),3))
  }
  mP("found symbol %s",symbol)
  
  x = cbind(x,x,x,x,x,x)
  x[,5]=1
  symbol=trim(symbol)
  colnames(x)=c( paste(symbol,".Open"),paste(symbol,".High"),paste(symbol,".Low"),paste(symbol,".Close"),paste(symbol,".Volume"), paste(symbol,".Adjusted"))
  if (is.null(row.names(X)))
    ind = as.Date(datum,"%d.%m.%Y")  else   ind = as.Date(row.names(X),"%d.%m.%Y")
  print(head(ind,3))
  stoxx = as.xts(x,order.by=ind)
}

if (F)
  stoxx=readStoxx("sx5r","sx5hun")
#Stoxx=data.frame(stoxx)
#xyplot(stoxx)


#################################################################
#load stoxx timeseries to xts
#NEU
#################################################################
readStoxx<-function(sym,tick)
{
  #http://www.stoxx.com/indices/byregion.html?superRegion=Europe&subRegion=Europe#
  
  #sym="sx8p"
  #http://www.stoxx.com/download/historical_values/h_ctb_sxagr.txt
  
  url=sprintf("http://www.stoxx.com/download/historical_data/h_%s.txt",tolower(trim(tick)))
  
  print(url)
  
  x=read.csv(sep=";",dec=".",header=T,url,stringsAsFactors=F)
  X=x  
  
  print(head(x,3))
  #x=x[-c(1,3)]
  datum=x[,1]
  #browser()
  
  aMode =F
  k=tryCatch(as.Date(x[1,1],"%d.%d.%Y"),error=function(err) NULL)
  
  if (is.finite(k))
  {
    aMode=T
    symbol = x$Symbol[1]
    x =x$Indexvalue
    mP("aMode")
  }
  else
  {  symbol = x[1,1]; x =x[,2] 
     print(head(row.names(X),3))
  }
  mP("found symbol %s",symbol)
  
  x = cbind(x,x,x,x,x,x)
  x[,5]=1
  symbol = trim(symbol)
  colnames(x)=c( paste(symbol,".Open"),paste(symbol,".High"),paste(symbol,".Low"),paste(symbol,".Close"),paste(symbol,".Volume"), paste(symbol,".Adjusted"))
  
  if (aMode)
    ind = as.Date(datum,"%d.%m.%Y")  else   ind = as.Date(row.names(X),"%d.%m.%Y")
  print(head(ind,3))
  stoxx = as.xts(x,order.by=ind)
}


#################################################################
#load stoxx timeseries to xts
#################################################################
readStoxx2<-function(sym,tick,url="")
{
  #sym="sx8p"
  #http://www.stoxx.com/download/historical_values/h_ctb_sxagr.txt
  if (url == "")
    url=sprintf("http://www.stoxx.com/download/historical_data/h_%s.txt",tick)
  # url ="http://www.stoxx.com/download/historical_values/h_sx5hun.txt"
  print(url)
  x=read.csv(sep=";",dec=".",header=T,url,skip=1)
  if(ncol(x) == 1)
    x=read.csv(sep=",",dec=".",header=T,url,skip=1)
  #x[2,1])
  
  symbol =colnames(x)[2]
  print(symbol)
  print(head(x,3))
  #browser()
  #x=x[-c(1,3)]
  datum=x[,1]
  x =x[,2] 
  
  mP("found symbol %s",symbol)
  
  x = cbind(x,x,x,x,x,x)
  x[,5]=1
  symbol = trim(symbol)
  colnames(x)=c( paste(symbol,".Open"),paste(symbol,".High"),paste(symbol,".Low"),paste(symbol,".Close"),paste(symbol,".Volume"), paste(symbol,".Adjusted"))
  ind = as.Date(datum,"%d.%m.%Y") 
  stoxx = as.xts(x,order.by=ind)
  #browser()
  return(list(symbol=symbol, data=stoxx))
}

#########################################################################################################
# Lade einfache (nicht OHLC) aus csv-file - wenn das nicht geht aus dem Internet
#FredTicker = list(
#c("DEXKOUS","FRED"), #load Korea
#c("DEXMAUS","FRED"), #load Malaysia
#c("DEXSIUS","FRED"), #load Singapore
#c("DEXTAUS","FRED"), #load Taiwan
#c("DEXCHUS","FRED"), #load China
#c("DEXJPUS","FRED"), #load Japan
#c("DEXTHUS","FRED"), #load Thailand
#c("DEXBZUS","FRED"), #load Brazil
#c("DEXMXUS","FRED"), #load Mexico
#c("DEXINUS","FRED") #load India      
#  )
#data<-new.env()


# FredTicker = list(
#  c("sx5r","stoxx"),
#  c("sg2r","stoxx"),
#  c("sv2r","stoxx")
#  )
# mGetTickers(FredTicker)

## das Beispiel l?dt von der Stoxx-WebSite einige Indizes 
if (F)
{#SXXP,SXAP,SX7P,SXPP,SX4P,SXOP,SXFP,SX3P,SXDP,SXNP,SXIP,SXMP,SXEP,SXQP
  stoxxL =spl("SX86P,SXRP,S8730P,SX8P,SXKP,SXTP,SX6P"  )            
  StoxxTicker = lapply(stoxxL,FUN=function(x) return( c(tolower(x),"stoxx")))
  
  xdata = new.env()    
  mGetTickers(StoxxTicker,data =xdata)
  mGetTickers("Dax",data=xdata)
  ls(xdata)
  
  xdata = new.env()
  mGetTickers(list(c("sg2r","stoxx")),data =xdata,online=T)
  
  
  X=data.frame(readStoxx("sx8p","sx8p"))
  sx8p=NULL
  undebug(readStoxx)
  undebug(mGetTickers)
  
  #schreib die stoxxL- Liste als Universe.txt...
  stoxxTicker = lapply(c("sx5r","sg2r","sv2r",stoxxL),FUN=function(x) return( tolower(x)))
  m = cbind(stoxxTicker)
  colnames(m)<-c("member")
  write.table(m,file="Models/ta3_Stoxx/universe.csv",row.names=F,quote=T)
  
  
}

normaliseTickerName <-function(ticker)
{name = ticker
 if   (startsWith(name,"^")) 
   name <- sub( "^", "",name,fixed=TRUE)
 
 name <-sub("/","_",name,fixed=T)
 name=unlist(strsplit(name,"="))[1]
 return (name)
}
#########################################################################################################

mGetTickersNew<-function(FredTicker="", data=.GlobalEnv, frame1 ="", From = "2005-01-01")
{
  FredTicker = toString(FredTicker)
  if( !exists(FredTicker,envir=data))
    try(mGetTickers(FredTicker, data, frame1 , From ))
  else
    cat("\n",FredTicker ," already loaded ")
}

is.def<-function(x,  data=.GlobalEnv)
{
  #  assign
  #  mget("a",  .GlobalEnv,ifnotfound="nix")
  #  exists()
  
  #  if (!exists(x,envir=data))
  #    return(F)
  
  if (length(x)==0) return(F)
  if (is.null(x)) return(F)
  if (is.na(x)) return(F)
  return (T)
}


###########################
#yahooTick= getYahooTicker("Dax")
###########################
#MM_PROVIDER
getProviderTicker<-function(tick="Dax") #MM_TODO  - muss bei jedem zus�tzlichen Tick-Provider erweitert werden 
{
  tick = toupper(tick) #alle ticks werden via grossscheibung angetriggert
  
  if (len(SecList) ==0)  # globale def des Anlageuniversum  
  { 
    wb <- loadWorkbook(sprintf("%s/Securities.xls",customerData))#, create = TRUE)
    SecList <<- data.table(wb["SecList"])
    #    SecList$Name<<-toupper(SecList$Name) #alles keys werden gross geschrieben
    
  }
  ticker=first(SecList[SecList$Name==tick]$YahooTicker) 
  
  if (!is.na(ticker) && ticker!="") return (list(name=tick, tick=ticker,provider="yahoo"))
  
  ticker=first(SecList[SecList$Name==tick]$FRED)
  if (!is.na(ticker)&& ticker!="") return (list(name=tick, tick=ticker,provider="FRED"))
  
  
  ticker=first(SecList[SecList$Name==tick]$stoxxTicker)
  if (!is.na(ticker)&& ticker!="") return (list(name=tick, tick=ticker,provider="stoxx"))
  
  
  ticker=first(SecList[SecList$Name==tick]$ArivaTicker)
  if (!is.na(ticker)&& ticker!="") return (list(name=tick, tick=ticker,provider="Ariva"))
  
  
  ticker=first(SecList[SecList$Name==tick]$GoogleTicker)
  if (!is.na(ticker)&& ticker!="") return (list(name=tick, tick=ticker,provider="Google"))
  
  ticker=first(SecList[SecList$Name==tick]$OandaTicker)
  if (!is.na(ticker)&& ticker!="") return (list(name=tick, tick=ticker,provider="Oanda"))
  
  ticker=first(SecList[SecList$Name==tick]$QuandlTicker)
  if (!is.na(ticker)&& ticker!="") return (list(name=tick, tick=ticker,provider="Quandl"))
  
  if (is.na(ticker))
    sag("unknown tick at getProviderTicker %s",tick,warte=T)
  return(list(name=tick, tick=tick,provider="NO"))
}

if (F)
{
  getYahooTicker<-function(tick="Dax")
  {
    if (len(SecList) ==0)  # globale def des Anlageuniversum  
    { 
      wb <- loadWorkbook(sprintf("%s/Securities.xls",customerData))#, create = TRUE)
      SecList <<- data.table(wb["SecList"])
    }
    ticker=first(SecList[SecList$Name==tick]$YahooTicker)
    if (len(ticker)==0)
      sag("Bug at getYahooTicker %s",tick)
    return(ticker)
  }
  
  getArivaTicker<-function(tick="WorldWater_ETF")
  {
    if (len(SecList) ==0)  # globale def des Anlageuniversum  
    { 
      wb <- loadWorkbook(sprintf("%s/Securities.xls",customerData))#, create = TRUE)
      SecList <<- data.table(wb["SecList"])
    }
    ticker=first(SecList[SecList$Name==tick]$ArivaTicker)
    return(ticker)
  }
  
  getFredTicker<-function(tick="DEXINUS")
  {
    if (len(SecList) ==0)  # globale def des Anlageuniversum  
    { 
      wb <- loadWorkbook(sprintf("%s/Securities.xls",customerData))#, create = TRUE)
      SecList <<- data.table(wb["SecList"])
    }
    ticker=first(SecList[SecList$Name==tick]$FRED)
    return(ticker)
  }
  
  
  getQuandlTicker<-function(tick="NSE/OIL")
  {
    if (len(SecList) ==0)  # globale def des Anlageuniversum  
    { 
      wb <- loadWorkbook(sprintf("%s/Securities.xls",customerData))#, create = TRUE)
      SecList <<- data.table(wb["SecList"])
    }
    ticker=first(SecList[SecList$Name==tick]$QuandlTicker)
    return(ticker)
  }
}
#####################################################
## das heutige Datum als String
######################################################
todayS<-function(frm="%d.%m.%Y") #MMA
{
  format(Sys.Date(),frm)
}
todayS2<-function(frm="%Y-%m-%d") #MMA
{
  format(Sys.Date(),frm)
}

########################################################
# lade von der Ariva.de - Webpage die Zeitreihe mit dem arivaName runter.
# Wenn Du den nicht kennst such ihn vai Isin mit 
#getSymbols.ariva(c("LU0274221281","FR0010527275"))
#Weise dem Symbol WATER die Zeitreihe zu, die du auf Ariva unter dem K�rzel "100533557" findest
#getArivaSeries("100533557","WATER",from="2000-01-01",auto.assign=T)
#getArivaSeries("102867422","test",auto.assign=T)

if (F)
{ #MM11
  getSymbols.ariva(c("DE0008469115"))  #die Ariva-Isin zum REX
  DE0008469115
  a=getArivaSeries("6383","test",auto.assign=T)
  
  getSymbols.ariva(c("EU0009658251"))  #die Ariva-Isin zum REX
  a=getArivaSeries("965825","test",auto.assign=T)
  
  
}


#http://www.bundesbank.de/cae/servlet/StatisticDownload?tsId=BBK01.WU046A&its_csvFormat#=de&its_fileFormat=csv&mode=its


if (F)
  a=getArivaSeries("100712940")
#########################################################
getArivaSeries<-function( arivaName="100533557",tic="", from = "1980-01-01", auto.assign=F, envir=.GlobalEnv ) #MMA
{
  if (from !="")
  {
    fromD = as.Date(from)
    #  fromD= as.Date("2012-01-01")
    aformat = format(fromD,"%d.%m.%Y")  #einmal das from - umformatieren
    maxtime = format(Sys.Date(),"%d.%m.%Y")
    
    url=sprintf("http://www.ariva.de/quote/historic/historic.csv?secu=%s&boerse_id=1&clean_split=1&clean_payout=0&clean_bezug=0&min_time=%s&max_time=%s&trenner=/",arivaName,aformat,maxtime)
    #url=sprintf("http://www.ariva.de/quote/historic/historic.csv?secu=%s&boerse_id=1&clean_split=1&clean_payout=0&clean_bezug=0&trenner=/",arivaName,aformat)
    
  }
  else
    url=sprintf("http://www.ariva.de/quote/historic/historic.csv?secu=%s&boerse_id=1&clean_split=1&clean_payout=0&clean_bezug=0&trenner=/",arivaName)
  
  #download.file(url, filename,  mode = 'wb')
  #browser()  
  tabDat = try( read.csv(url,  header=TRUE, stringsAsFactors=F,dec=",",skip=1,sep="/"))#
  #head(tabDat)
  #tail(tabDat)
  #browser()
  #MM11
  # browser()
  if (is.null(nrow(tabDat)))
  {
    mP("getArivaSeries: No TimeSeries for %s %s",arivaName,tic)
    # browser()
    return(NA)
  }
  colnames(tabDat)=spl("Index,.Open,.High,.Low,.Close,.Stuecke,.Volume")
  #browser()#MMX 1
  
  #evtl gibts den Namen ja schon in den Stammdaten - dann kann ich den mitabspeichern
  Ti = SecList[ArivaTicker==arivaName]
  if (nrow(Ti)>0)
  {
    Ti$Name=trim(Ti$Name)
    colnames(tabDat)=   c("Index", sprintf("%s.Open",Ti$Name),sprintf("%s.High",Ti$Name),sprintf("%s.Low",Ti$Name),sprintf("%s.Close",Ti$Name),sprintf("%s.Stuecke",Ti$Name),sprintf("%s.Volume",Ti$Name))
    
  }
  
  tabData =as.Date(tabDat[,1])
  #ZahlenUmwandlung - auch dann wenn es sich um deutsche dec- Formate handelt #MMA
  tabDat_Dat=apply(tabDat[,-1],2,FUN=function(x)as.numeric(sub(",",".",x,fixed=T)))
  hist= as.xts(tabDat_Dat, order.by=tabData)
  hist = m.clean0(hist)
  # browser()
  hist = na.omit(hist)
  #wandel alles nach numeric - auch wenn , statt .  als dec sind
  if (auto.assign)
  {
    if (tic !=  "")
      assign(tic, hist, envir=envir)
    else
      assign(paste("arivaName",arivaName,sep=""), hist, envir=envir)
  }
  # browser() #MMX
  head(hist)
  #  mPlot(hist[,c(1,2,3,4)],main=tic,ylog_ = F)
  return (hist)
}
#
#x=   getArivaSeries("100533557")



###################################################################
#
# Yahoo hat f�r deutsche Wertpapiere 2013.3 die URL ge�ndert
#
###################################################################
getSymbols.YahooDe <- function   #MMAgetSymbols.yahooDE
(
  Symbols, 
  env = .GlobalEnv, 
  auto.assign = F,
  download = T  
) 
{  	
  yahooDE= NULL
  # read all Symbols
  for (i in 1:len(Symbols)) {	
    if(download) {
      symbol=Symbols[i]
      #%5E  f�r ^
      
      yahooDEName = gsub('\\^', '%5E', symbol)
      sym=normaliseTickerName(symbol)
      
      url = sprintf("http://ichart.finance.yahoo.com/table.csv?s=%s&a=10&b=26&c=1960&d=03&e=3&f=2013&g=d&ignore=.csv", yahooDEName)
      
      tabDat = read.csv(url,  header=F, stringsAsFactors=F,dec=".",skip=1,sep=",")#
      
      #head(tabDat)
      
      #for (ii in c(2:   ncol(tabDat)))
      #  tabDat[,ii] = as.numeric(tabDat[,ii])
      
      tabDat[,1] =as.Date(tabDat[,1])
      #    head(tabDat)
      colnames(tabDat)=spl(sprintf("Date,%s.Open,%s.High,%s.Low,%s.Close,%s.Volume,%s.Adjusted",sym,sym,sym,sym,sym,sym))
      hist= as.xts(tabDat[,-1], order.by=as.Date(tabDat[,1]))
      
      
      if (F)
      {
        hist = na.omit(hist)
        
        print(Symbols[i])
        print(yahooDEName)
        print(head(hist))
        ft=fromTo(hist)
        #browser()
        mPlotPureData(hist[,c(1,2,3,4)],main=sprintf("%s",yahooDEName))
      }
      
      #   plot(hist)
      
      
      filename=sprintf("MData/%s.csv",sym)
      print(filename)
      #schreibe die Zeitreihe - nach temp -- noch hat sie ja keinen offiziellen Namen
      try(  write.zoo(hist, file=filename, sep=";",  dec="."))
      
      if (auto.assign) {  	
        assign(sym, hist, env)	
        
        return(hist)
      }
      
    }	
  }
}

if (F)
  getSymbols.YahooDe("Rex")



#########################################################
#Yahoo ist der default-Provider:
# Provider sind zur Zeit :   yahoo,FRED,stoxx,ariva
#yahoo, google, MySQL, FRED, csv, RData, and oanda.

if (F)
{
  mGetTickers("^GDAXI" )
  
  mGetTickers("Rex",online=T )
  mGetTickers("^GREXP",online=T )
  
  getSymbols.YahooDe("Rex") #der liefert die volle L�nge
  
  #  Rex=mGetTickers("Rex",online=T )
  
  mGetTickers(list( spl("STOXXEurope600 AutomobilesParts", "stoxx")),online=T)
  
  
  
  mGetTickers("Dax",online=T)
  mGetTickers(list( spl("sg2r, stoxx")),online=T)
  #, spl("100533557,ariva")),online=T)
  
  FredTicker = list(
    c("DEXKOUS","FRED"), #load Korea
    c("DEXMAUS","FRED"), #load Malaysia
    c("DEXSIUS","FRED"), #load Singapore
    c("DEXTAUS","FRED"), #load Taiwan
    c("DEXCHUS","FRED"), #load China
    c("DEXJPUS","FRED"), #load Japan
    c("DEXTHUS","FRED"), #load Thailand
    c("DEXBZUS","FRED"), #load Brazil
    c("DEXMXUS","FRED"), #load Mexico
    c("DEXINUS","FRED") #load India 
  )
  mGetTickers(FredTicker,online=T)
  mGetTickers("DEXINUS",online=T)
  mGetTickers("Dax",online=T)
  mGetTickers("100533557",online=T)
  mGetTickers("WorldWater_ETF",online=T)
  mGetTickers(list(c("CUSR0000SEEA","FRED")),online=T)
  #FRED:
  #o:\R\Nuggets\Eckhard\MData\Fundamentals\Fred\Germany - ALFRED - St. Louis Fed.url
  #Chicago Fed National Activity Index: Personal Consumption and Housing (CANDH)
  #FRED:   http://research.stlouisfed.org/fred2/series/CANDH?cid=32457
  mGetTickers(list(c("CANDH","FRED")),online=T)
  mPlot(CANDH[,4],ylog_=F)
  #oder Production of Total Industry in Germany (DEUPROINDMISMEI)
  mGetTickers(list(c("DEUPROINDMISMEI","FRED")),online=T)
  mPlot(DEUPROINDMISMEI[,4],ylog_=F)
  
  mGetTickers(list(c("peter","Ariva","100712940")),online=T)
  mGetTickers(list(c("peter","Ariva"," 846911")),online=T)
  
  data=new.env()
  mGetTickers(list(c("BCB/UDJIAD1","Quandl")),data=data,online=T)
  mGetTickers(list(c("NSE/OIL","Quandl")),data=data,online=T)
  
}
#########################################################


mGetTickers<-function( ..., data=.GlobalEnv, frame1 ="", from = "1975-01-01", doAdjust=F, online=F) #MMA
{
  FredTicker = c(...)
  Frednames = NULL
  maxFrom = "1990-01-01"
  #series = NULL
  FredTicker = c(FredTicker)
  
  for (nameL in FredTicker)
  {
    dontSave=F
    name = ""
    provider = ""
    tic =""
    series = NULL
    
    # browser()#MMX
    if (length(nameL)>0 ) #nameL != ""  ??
    {
      if (len(nameL) < 2)
      {
        tic =name = toString(nameL)
        provider="yahoo"  
        
        ticX= getProviderTicker(name)  #noch nachtr�glich eingebaut
        #ticX=getYahooTicker(name)
        
        provider=ticX$provider
        tic = ticX$tic
        
        
        if (is.na(tic) || provider =="NO") #das wertpapier ist in Securities noch nicht angelegt
        {tic = name
         mP("security %s = %s is missing at Securities.xls .. use name an yahoo as provider", tic,name) 
         #browser()
         provider="yahoo" 
        }
      }
      else
        if (len(nameL)<3)
        {
          tic = name=nameL[1]
          provider=nameL[2]
        }
      else
      {
        name=nameL[1]
        provider=nameL[2]
        tic = nameL[3]
        
        if (tic=="" || provider =="")
        {
          ticX= getProviderTicker(toupper(name))  #noch nachtr�glich eingebaut
          
          provider=ticX$provider
          tic = ticX$tic
          
        }
        
      }
      
      yahooName = tic
      if   (startsWith(name,"^")) 
        name <- sub( "^", "",name,fixed=TRUE)
      name=unlist(strsplit(name,"="))[1]
      
      
    }
    #browser()
    name=normaliseTickerName(name)
    if (is.null(Frednames))
      Frednames = name
    else
      Frednames = c(Frednames,name)
    
    File=paste("MData/",name,".csv",sep="")
    if (exists("globMDataSUB"))
      if (nchar(globMDataSUB) >1 )
      {
        mP("mGetTickers reads from globalMDataSUB: %s",globMDataSUB)
        File=paste("MData/",globMDataSUB,"/",name,".csv",sep="")
      }
    
    #browser()
    
    namePrices = paste(name,"Adjusted",sep=".")
    nameOpen = paste(name,"Open",sep=".")
    nameHigh = paste(name,"High",sep=".")
    nameLow = paste(name,"Low",sep=".")
    nameVol = paste(name,"Volume",sep=".")
    nameClose = paste(name,"Close",sep=".")
    
    if (!online)
      if (exists("globalPROVIDER"))
        if (globalPROVIDER != "")
        {provider =globalPROVIDER
         cat("use globalPROVIDER instead of ")
         cat(provider)
        }
    
    
    #versuche zun�chst mal die Datei aus der serialisierten Version zu holen
    #versuche zun�chst DB - dann CSV
    
    if ( T || !exists(name,envir=data))
    {
      
      # if (provider =="yahoo")  #Suche auf dem SQL-Server
      if (is.null(series) && !online)
      {
        print (paste(" dbGetSeries  ",name))
        series = dbGetSeries(name,from = From, env = data)
        print(tail(series,2))
        
        #  sag("ok",T)
        if (!is.null(series)) 
        { series = get(name,envir=data)
          write.zoo(series, file=File, sep=";",  dec=".")
        }
      }
      #browser("xx")
      if (is.null(series) )  #noch nicht mit dbGetSeries geholt
      {
        
        sag("read file")
        
        if (file.exists(File) && !online)
          
        { mP("read.zoo  %s",File)
          if (csvDatFormat =="")
            csvDatFormat="%Y-%m-%d"
          
          if (exists("globalDEC"))
            dec_ = globalDEC
          else
            dec_ = "."
          if (exists("globalSEP"))
            sep_ = globalSEP
          else
            sep_ = ";"
          
          
          mP("read.zoo# %s  ",File)# , csvDatFormat      ,globalDEC , globalSEP)
          #MMX read at mGetTickre
          series = read.zoo( file=File, sep=sep_,dec=dec_,format=csvDatFormat,header =TRUE)        
          # browser()
          #mach ihn gegen dec-probleme robuster
          if (class(coredata( (series))[1])!="numeric") #Cl
          {
            if (dec_==".")
              series = read.zoo( file=File, sep=sep_,dec=",",format=csvDatFormat,header =TRUE)        
            
            else
              series = read.zoo( file=File, sep=sep_,dec=".",format=csvDatFormat,header =TRUE)     
          }
          
          #head(series)  MM_read
          #  browser()
          #sx = xts(series)
          #   browser()
          #  if (dim(sx))
          #series=read.table(file=File, sep=sep_,dec=dec_,header =TRUE)
          
          print (paste("load file",File,sep=":"))
          
          tail(series,1)
          dontSave=T
        }
        
        # browser(text="mGetGickers")
        
        if (is.null(series) ||  online)  #noch nicht in der DB oder online wird erzwungen
        {
          dontSave=F
          if (!online) mP("no serialised data found - look at provider %s ",provider)
          else
            mP("online download %s - look at provider %s ",name, provider)
          #xx =get("xxxx")
          #browser()
          # INTERNET-Download
          if (provider=="Sonstige") #----------------------------------------------------------------------------
{ #fundamentaldaten download -z.B. ifo
  
  #TODO:   fertig machen: rufe jeweils eine spezial-Methode zum einlesen .. z,B. f?r IFO
  s = sprintf("read_%s(%s, %s)", name, name, tic)
  series =eval(parse(text = s))
  #read_<name>(name, provider) ##  keine Nachbearbeitung mehr .. oder doch ?
  #mP("InternetDownload: readStoxx %s",name)
  #series = readStoxx(name)
}
          else
            
            if (provider=="stoxx") #----------------------------------------------------------------------------
{
  mP("readStoxx %s",name)
  series = readStoxx(name,tic)
}
          else
          {mP("InternetDownload: getSymbols %s %s",provider,yahooName)
           
           mist= tryCatch(
             
             
{
  #browser()
  #Rex=NULL
  #GREXP=NULL
  #yahooName ="^GREXP"
  
  #getQuote.google(spl('MSFT,AAPL,IBM')  #MM_TODO  - checke ob auch google-als provider geht
  #browser()
  ######################################################################################
  #  Internet Download
  ######################################################################################
  #MM_PROVIDER
  if (provider == "Ariva")  
  {
    series=try(getArivaSeries(tic , auto.assign=F))
    yahooName = name
    assign(name,series,envir=data)
    doAdjust=F
  }
  else
    #
    if (provider == "Quandl")  
    {
      library(Quandl)
      if (!exists("init.quandl_") )
      {
        mP("login at Quandl")
        Quandl.auth("98xyEn88QWsfqq7aspHU") #hab ich im http://www.quandl.com/DOE-US-Department-of-Energy/EIA_TOTALOILSUPPLY_A_GERMANY73-Total-Oil-Supply-Germany
        #Download-manager aus dem download via rcode-generator
        init.quandl_ <<-F
      }
      #browser()
      # series = try(Quandl("/YAHOO/INDEX_GDAXI",type = "xts"))
      series = try(Quandl(tic,type = "xts"))
      
      name =first(SecList[SecList$QuandlTicker==tic]$Name)
      
      #  name=normaliseTickerName(tic)
      if (len(colnames(series))==1)
      {
        doAdjust=F
        colnames(series) =name
        series=merge(series,series,series,series,series,series)
        colnames(series) = spl(sprintf("%s.Open,%s.High,%s.Low,%s.Close,%s.Volume,%s.Adjusted",name,name,name,name,name,name))
      }
      else
        # browser()
        if (dim(series[,"Adjusted Close"])[2]!=0) #enth�lt  "Adjusted Close"
        {
          doAdjust=F
          oseries= series
          series = oseries[,spl("Open,High,Low,Close")] ; 
          if (dim(oseries[,"Volume"])[2]!=0)
            series=merge(series,oseries[,"Volume"],oseries[,"Adjusted Close"])
          else
             series=merge(series,0,oseries[,"Adjusted Close"])
          
          colnames(series) = spl(sprintf("%s.Open,%s.High,%s.Low,%s.Close,%s.Volume,%s.Adjusted",name,name,name,name,name,name))
          
        }
      else
      {
        doAdjust=F
        series = series[,spl("Open,High,Low,Close")]
        series = merge(series,0, series[,"Close"]) #eine pseudo-adjusted splate
        colnames(series) = spl(sprintf("%s.Open,%s.High,%s.Low,%s.Close,%s.Volume,%s.Adjusted",name,name,name,name,name,name))  
      }
      #browser()
      #browser(mP("qqqq"))
      
      yahooName = name
      assign(name,series)
    }
  else
  { 
    yN= yahooName
    #TB3M = quantmod::getSymbols('DEXINUS', src='FRED', auto.assign = FALSE)
    try(  getSymbols(yahooName,src=provider,from = from, auto.assign=TRUE))
    #notfalls f�r deutsche Symbole auf einer anderen yahoo-url nachschauen
    if   (startsWith(yahooName,"^")) 
      yahooName <- toupper(sub( "^", "",yahooName,fixed=TRUE))
    
    NewWP =try(get(yahooName))
    
    # TB3M = quantmod::getSymbols('DEXINUS', src='FRED', auto.assign = FALSE)
    if (provider =="FRED" && dim(NewWP)[2]==1)
    {
      #standard-spalten draus machen
      NewWP=merge(NewWP,NewWP,NewWP,NewWP,NewWP,NewWP)
      symbol=trim(yahooName)
      colnames(NewWP)=c( paste(symbol,".Open"),paste(symbol,".High"),paste(symbol,".Low"),paste(symbol,".Close"),paste(symbol,".Volume"), paste(symbol,".Adjusted"))
      
    } 
    else
      # browser()
      if (!exists(yahooName) || len(NewWP) <2  || dim(Cl(NewWP))[2]>1)
      {
        NewWP=  try(  getSymbols.YahooDe(yN, auto.assign=TRUE))
        #browser()  
      }
    
    if (dim(Cl(NewWP))[2]>1)
    {
      sag("mist .. 2 Cl- spalten - liefet yahoo wieder AdjustClose  ??")
      browser()
    }
  }
  #yahooName="^Gdaxi"  .. dann kommt aber GDAXI an 
  #yahoo, google, MySQL, FRED, csv, RData, and oanda.
  
  if   (startsWith(yahooName,"^")) 
    yahooName <- toupper(sub( "^", "",yahooName,fixed=TRUE))
  
  #browser() 
  
  if (name != yahooName)
  {
    #browser()
    assign(name,NULL)
    assign(name,get(yahooName))
    series <- get(name)
    series <-get(yahooName)
    if (!is.null(series) && len(series) > 0)
    {
      dontSave = F
      
      mP("internet download of %s to symbol %s: %d lines ",yahooName,name,len(series))
    }
    else
    {
      dontSave =T
      mP("internet download missed of %s to symbol %s ",yahooName,name)
    }
    #   sapply(c(1,2,3),FUN=function(x)print(x))
    #umbenennen der Spalten
    # browser()
    
    c<-colnames(series)
    
    #ccolnames(get(name))<- 
    colnames(series) =sapply(  c, FUN= function(x) sub(yahooName, name, x,fixed =T))
    
    #browser()
    head(series)
    # browser()
    assign(name,series)   #MM_BUG
    if (!is.null(yahooName) && yahooName != name)
      rm(yahooName)
    
  }
  
  series = get(name)  #MM_BUG
},
error=  function(e) 
{
  print(e)  
  series = NULL
  try(if (exists( x=name, envir=data))
    try(rm( list(name),envir=data)))
  return("mist")
})
           
           #getSymbols(yahooName,src=provider, from= maxFrom, env=data)       
           # if (mist != "mist")
           
          }
          #try(rm(name))
          try(mP("from Internet %s",toString(dim(series))))
        }
        
        if (!is.null(series) && !dontSave)
        { 
          #series = cbind(series,series)
          mP("-------------  save File %s %s",File, toString(head(series)))
          
          write.zoo(series, file=File, sep=";",  dec=".")
        }
        else
          mP("no Data at Internet for %s",name)
      }
      #print(paste(" getSymbols ",name))
      #colnames(prices)<-Frednames
      #colnames(series))
      if (!is.null(series) )
      {
        
        print(paste(name, toString( len(series)),sep=" has "))
        print(head(series,1));print(tail(series,1))
        #von = (series)[1]),'%d%b%y')
        #bis=  "??"# format(index(row.names(series)[nrow(row.names(series))]),'%d%b%y')   #format(index(tail(data[[i]],1)[1]), '%d%b%y')
        #mP(" !!### %s    from %s til  %s",tit,von,bis)
        #browser()
        series = as.xts(series)
        
        if (provider != "Sonstige")
        {
          if (is.null(dim(series)) || dim(series)[2]<2)
          {
            
            s = series
            s[,1] =  as.numeric(series[,1]) ##MM_TOCHECK
            #s=na.omit(s)
            
            #    if (name=="REX_RI_slope90")
            #      browser()
            #  s = series  
            #    s=""
            #    tryCatch.W.E(  na.omit(series))   
            #    s =         na.omit(series)
            
            
            #browser()
            
            series = cbind(series,s,s,s,rep(0.000001,len(series)),s)     
            colnames(series)<- c(nameOpen,nameHigh,nameLow,nameClose,nameVol, namePrices)       
            series = na.omit(series)
            if (!dontSave)
              write.zoo(series, file=File, sep=";",  dec=".")
            
            #if (provider == "FRED")
            #  browser()
            #if (!is.null(series))
            #  assign(name,series,envir =data)
          }
          else
          {
            #assign(name,series,envir =data)
            #assign(name,series)
            
            if (doAdjust)
              series<- M_adjustOHLC(series, name,use.Adjusted=T);
            #estr=paste("series<- adjustOHLC(",name,")",sep="")
            #print(estr)
            #eval(parse(estr))
            
            #browser()
            # series = m.clean0(series)
            
            #series = na.omit(series)  #MM_WN1
            
            #if (!is.null(series))
            #  assign(name,series,envir =data)
          }
        }
        
        #head(series)
        if (!is.null(series))           
        {
          print(sprintf("assign series %s",name))    #MMMM
          if (name =="Rex")
          {
            # write.xts(series,"test1.csv")
            #browser()
            #sss =  m.clean0(series)
            #head(sss)
          }
          #head(series,1)
          #browser()
          #if (exists( x=name,envir=data))
          #if (!is.null(data[[name]]))
          #  rmSymbol(name,data=data)
          #try(rm(envir=data, list(name)))
          
          #data = t0rex$t0data
          #ls(data)
          #Rex=data[["Rex"]]
          #rm(Rex,envir= data)
          
          # browser()
          #  try( assign(name,series,envir=.GlobalEnv))   //MM2
          if (exists(name,envir=data))
            rmSymbol(name,envir=data)
          try(assign(name,series,envir=data))
        }
      }
    }else print(paste(name," exists"))           
    
  }
  #########################################################################################################
  #baue eine Tabellen-Objekt aus den Close-Teilen
  return (NULL)  #<<<<<<<<<<<<<<<<<<<<<<<<<<
  
  prices<-NULL
  symbolnames = NULL
  
  #  for(i in data$symbolnames) {colnames(data[[i]])=normColnameS(data[[i]])}
  
  for(i in ls(data))  
  { 
    colnames(data[[i]])=normColnameS(data[[i]]) #MMK
    
    if (is.null(prices))
    {prices = Cl(data[[i]])
     symbolnames = i
    }
    else
    {prices = na.omit(merge(prices,Cl(data[[i]])))
     symbolnames = c(symbolnames,i)
    }
  }
  colnames(prices)<-symbolnames
  if (frame1 == "")
    prices = as.xts(prices)
  else
    prices = as.xts(prices)[frame1]
  
  return(prices)
}

M_adjustOHLC<-function (x,symbol.name, adjust = c("split", "dividend"), use.Adjusted = FALSE, 
                        ratio = NULL) 
{
  # browser()
  sag("at adjust")
  #browser()
  if (is.null(ratio)) {
    if (use.Adjusted) {
      if (!has.Ad(x)) 
      {
        print(symbol.name)
        print(head(x,3))
        #stop("no Adjusted column in 'x'")
        ratio=1
        #browser()
        if (symbol.name=="REX")
          browser()
      }
      else
        ratio <- Ad(x)/Cl(x)
    }
    else {
      div <- getDividends(symbol.name)
      splits <- getSplits(symbol.name)
      ratios <- adjRatios(splits, div, Cl(x))
      if (length(adjust) == 1 && adjust == "split") {
        ratio <- ratios[, 1]
      }
      else if (length(adjust) == 1 && adjust == "dividend") {
        ratio <- ratios[, 2]
      }
      else ratio <- ratios[, 1] * ratios[, 2]
    }
  }
  #  head(x)
  
  
  Op1=Op(x);if (len(Op1[!is.na(Op1)])==0) Op1 =0  else Op1 = m.ifna.prev(Op1)
  Lo1 =Lo(x);if (len(Lo1[!is.na(Lo1)])==0) Lo1 =0 else Lo1 = m.ifna.prev(Lo1)
  Hi1 = Hi(x);if (len(Hi1[!is.na(Hi1)])==0) Hi1 =0 else Hi1 = m.ifna.prev(Hi1)
  Cl1 = Cl(x)[,1];if (len(Cl1[!is.na(Cl1)])==0) Cl1 =0 else Cl1 = m.ifna.prev(Cl1)
  
  if (F)
  {
    Op1[is.na(Op1)] <-0
    Lo1[is.na(Lo1)] <-0
    Hi1[is.na(Hi1)] <-0
    Cl1[is.na(Cl1)] <-0
  }
  Adjusted <- Cl1 * ratio
  
  res=structure(cbind((ratio * (Op1 - Cl1) + Adjusted), 
                      (ratio * (Hi1 - Cl1) + Adjusted), 
                      (ratio * (Lo1 - Cl1) +  Adjusted), 
                      Adjusted,
                      if (has.Vo(x)) Vo(x) else 0,                                                                                                           
                      if (has.Ad(x)) 
                        Ad(x)  else 0),
                .Dimnames = list(NULL, colnames(x)))
  
  #browser()
  #head(res)
  #write.xts(res,"test4")
  return(res)
}


mcolnames<-function(dat,newCols)
{
  if(is.null(dim(dat)))    
  {dat = cbind(dat,dat)
   colnames(dat)<-c(newCols)
   return(dat)
  }
  else
    colnames(dat)<-newCols
  return (dat)
}


mm.RiskReturnScatter<-function (R, Rf = 0, main = "Annualized Return and Risk", add.names = TRUE, 
                                xlab = "Annualized Risk", ylab = "Annualized Return", method = "calc", 
                                geometric = TRUE, scale = NA, add.sharpe = c(1, 2, 3), add.boxplots = FALSE, 
                                colorset = 1, symbolset = 1, element.color = "darkgray", 
                                legend.loc = NULL, xlim = NULL, ylim = NULL, cex.legend = 1, 
                                cex.axis = 0.8, cex.main = 1, cex.lab = 1, ...) 
{
  if (method == "calc") 
    x = checkData(R, method = "zoo")
  else x = t(R)
  if (is.null(dim(Rf))) 
  {Rf = R[,1]
   Rf[,1] =0
  }
  columns = ncol(x)
  rows = nrow(x)
  columnnames = colnames(x)
  rownames = rownames(x)
  if (length(colorset) < columns) 
    colorset = rep(colorset, length.out = columns)
  if (length(symbolset) < columns) 
    symbolset = rep(symbolset, length.out = columns)
  if (method == "calc") {
    comparison = t(table.AnnualizedReturns(x[, columns:1], 
                                           Rf = Rf, geometric = geometric, scale = scale))
    returns = comparison[, 1]
    risk = comparison[, 2]
    rnames = row.names(comparison)
  }
  else {
    x = t(x[, ncol(x):1])
    returns = x[, 1]
    risk = x[, 2]
    rnames = names(returns)
  }
  if (is.null(xlim[1])) 
    xlim = c(0, max(risk) + 0.02)
  if (is.null(ylim[1])) 
    ylim = c(min(c(0, returns)), max(returns) + 0.02)
  if (add.boxplots) {
    original.layout <- par()
    layout(matrix(c(2, 1, 0, 3), 2, 2, byrow = TRUE), c(1, 
                                                        6), c(4, 1), )
    par(mar = c(1, 1, 5, 2))
  }
  plot(returns ~ risk, xlab = "", ylab = "", las = 1, xlim = xlim, 
       ylim = ylim, col = colorset[columns:1], pch = symbolset[columns:1], 
       axes = FALSE, ...)
  if (ylim[1] != 0) {
    abline(h = 0, col = element.color)
  }
  axis(1, cex.axis = cex.axis, col = element.color)
  axis(2, cex.axis = cex.axis, col = element.color)
  if (!add.boxplots) {
    title(ylab = ylab, cex.lab = cex.lab)
    title(xlab = xlab, cex.lab = cex.lab)
  }
  if (!is.na(add.sharpe[1])) {
    for (line in add.sharpe) {
      abline(a = (Rf * 12), b = add.sharpe[line], col = "gray", 
             lty = 2)
    }
  }
  if (add.names) 
    text(x = risk, y = returns, labels = rnames, pos = 4, 
         cex = 0.8, col = colorset[columns:1])
  rug(side = 1, risk, col = element.color)
  rug(side = 2, returns, col = element.color)
  title(main = main, cex.main = cex.main)
  if (!is.null(legend.loc)) {
    legend(legend.loc, inset = 0.02, text.col = colorset, 
           col = colorset, cex = cex.legend, border.col = element.color, 
           pch = symbolset, bg = "white", legend = columnnames)
  }
  box(col = element.color)
  if (add.boxplots) {
    par(mar = c(1, 2, 5, 1))
    boxplot(returns, axes = FALSE, ylim = ylim)
    title(ylab = ylab, line = 0, cex.lab = cex.lab)
    par(mar = c(5, 1, 1, 2))
    boxplot(risk, horizontal = TRUE, axes = FALSE, ylim = xlim)
    title(xlab = xlab, line = 1, cex.lab = cex.lab)
    par(original.layout)
  }
}

MplotNormedPrices<-function(r=ret,frame="", bench_ = "" , ylog_=T, main="Returns",legend.loc_ = "",risk.dates_ = risk.dates,risk.labels_ = risk.labels)
  
{  
  #sieh auch   plotNormedPrices(cumsum(mROC(data$prices)))
  
  
  ret = na.omit(r[frame])
  if (len(bench_)>1)
    ret =selectBench(ret,bench_)
  mat = mRendite(ret)
  
  if (ylog_)
    mat= log(mat)
  
  #mat = mLogRendite(ret)
  
  rang=range(mat,na.rm = FALSE)
  
  cols = rainbow(ncol(mat))
  colSet = c("red", topo.colors(ncol(mat)))
  colSet = cols
  
  #browser()
  ft=fromTo(mat)
  
  Auflegedatum=ft[1]
  Bisdatum = ft[2]
  try(chart.RiskReturnScatter(ret,  main = sprintf("RiskReturn %s to %s  ",ft[1],ft[2]), colorset=cols))# colorset = rainbow8equal))
  
  
  title=sprintf("Stock Returns %s-%s ",Auflegedatum,Bisdatum)
  #colSet = c("red",palette(gray(seq(0,.9,len=ncol(ret)-1))))
  plot(mat[,1], ylim =rang, main=title)
  for(ci in 1:ncol(ret))
    lines(mat[,ci],col=colSet[ci],lwd=2)
  # so turn off clipping:
  #par(xpd=TRUE)
  #legend(2.8,-1,c("group A", "group B"), pch = c(1,2), lty = c(1,2))   
  legend("topleft", colnames(mat), cex=0.8, bty="n",
         col=colSet,pch=19)
  
  #labs=colnames(mat)
  #axis(2, coredata(last(mat)),labels=FALSE)
  #mtext(labs, 2, at=coredata(last(mat)), col=1,las=1,line=1,cex=0.7)
  #for (i in seq(par("yaxp")[1],par("yaxp")[2],by=(par("yaxp")[2]-par("yaxp")[1])/par("yaxp")[3])) {
  #  abline(h=i, col="gray70")}
  
}

#mPlot(x)


# mPlot:  die Log-Darstellung ist hier der Default-Wert    #MMcheck
mPlot <-function(...,frame="" , scale=0, ylog_=T, main="",legend.loc_ = "",risk.dates_ = risk.dates,risk.labels_ = risk.labels,signal=NULL)  #MMA
{ 
  
  prices = na.omit(merge(...))
  
  if (scale ==1)
    #t2 =lapply(colnames(prices), FUN=function(col){ prices[,col]=scaleTo(prices[,col],c(0,1)); return(col)})
    for (col in colnames(prices))
    {
      prices[,col]=scaleTo(prices[,col],c(0,1))
    }
  
  
  #LeftMargin=1
  #hasTitle = !is.null(main);
  #par( mar = c(iif(plotX,2,10), LeftMargin , iif(hasTitle,2,0), 3) )
  
  
  if (ylog_)
  {
    #browser()
    #MM! gib die price-columns zur�ck die 0-Werte enthalten  
    x_0=na.omit(unlist(lapply(colnames(prices),FUN=function(col) {X=prices[,col];ifelse(nrow( X[X ==0])>0,col,NA)})))
    
    if  (!is.def(x_0) || max(x_0)==0)
      prices=log(prices)    
    else
    {
      cat("mPlot-ylog_ omits columns with 0 values: ")
      cat("\n######\n")
      #browser()
      cat(x_0)
      cat("\n")
      
      prices =prices[,colnames(prices)!=x_0 ]
    }
  }
  # browser() #T!
  #if (main == "")
  #  main = toString(colnames(prices))
  
  mat = na.omit(prices[frame])
  
  rang=range(mat,na.rm = FALSE)
  ft=fromTo(mat)
  Auflegedatum=ft[1]
  Bisdatum = ft[2]
  if (main=="no")
    title=""
  else
    title=sprintf("%s %s bis %s ",main,Auflegedatum,Bisdatum)
  cols = rainbow(ncol(mat))
  colSet = c("red", topo.colors(ncol(mat)))
  #colSet = c("red",palette(gray(seq(0,.9,len=ncol(ret)-1))))
  #browser("mPLot")  
  
  plot((mat[,1,drop=F]), ylim =rang, main=title)
  
  
  #grid()
  if (T)
  {
    axis(4)  
    for(ci in 1:ncol(mat))
      lines(mat[,ci,drop=F],col=colSet[ci],lwd=2)
  }
  # so turn off clipping:
  #par(xpd=TRUE)
  #legend(2.8,-1,c("group A", "group B"), pch = c(1,2), lty = c(1,2)) 
  
  #legend("topleft", colnames(mat), cex=0.6, bty="n", col=colSet,pch=19)
  plota.legend(colnames(mat),colSet[1:ncol(mat)],pch=10,cex=0.6)
  
  
  #labs=colnames(mat)
  #axis(2, coredata(last(mat)),labels=FALSE)
  #mtext(labs, 2, at=coredata(last(mat)), col=1,las=1,line=1,cex=0.7)
  #for (i in seq(par("yaxp")[1],par("yaxp")[2],by=(par("yaxp")[2]-par("yaxp")[1])/par("yaxp")[3])) {
  #  abline(h=i, col="gray70")}
  
  if (!is.null(signal))
  {
    dax=mat[,1]
    k=na.omit(merge(dax,dax,signal,dax,dax)); 
    k[,4] = ROC(k[,4])
    k=na.omit(k)
    k[,5] = mRendite(k[,4]*k[,3])
    #zeichne den guv
    lines(k[,5],col="green",lwd= 2)
    k[which(k[,3]==0),1]=NA
    #markiere die Long-Phase
    lines(k[,1],lwd=3,col="yellow",type="l")
    
    legend("topleft", c(colnames(mat),"guv"), cex=0.6, bty="n",
           col=colSet,pch=10)
    
    
  }
  return("OK")  
}



#####################################################################################################
#plotte normierte preise
#ret = (prices / mlag(prices) - 1)
#oder
#r <- cumsum(diff(log(prices))[-1,])
#oder
#US10y.roc <- diff(DGS10, lag=1)
#US10y.roc[1,] <- 0
# These are start and end dates, formatted the same way as the default axis labels
#data(edhec)
# Event lists - FOR BEST RESULTS, KEEP THESE DATES IN ORDER
risk.dates = c(
  "Oct 87",
  "Feb 94",
  "Jul 97",
  "Aug 98",
  "Oct 98",
  "2000-07-01",
  "2001-09-11",
  "2008-09-15",
  "2011-03-11",
  "2011-07-29"
  
)
risk.labels = c(
  "Black Monday",
  "Bond Crash",
  "Asian Crisis",
  "Russian Crisis",
  "LTCM",
  "Tech Bubble",
  "Sept 11",
  "Lehman",
  "Fukushima",
  "Europe Crisis"
)

#R=edhec[,"Funds of Funds",drop=FALSE]
#Return.cumulative = cumprod(1+R) - 1
#chart.TimeSeries(Return.cumulative)
#chart.TimeSeries(Return.cumulative, colorset = "darkblue", legend.loc = "bottomright", period.areas = cycles.dates, period.color = "lightblue", event.lines = risk.dates, event.labels = risk.labels, event.color = "red", lwd = 2)



#####################################################################################################
plotNormedPrices<-function(r=data$prices,frame="", bench_ = BENCH , ylog_=F, main="Returns",legend.loc_ = "",risk.dates_ = risk.dates,risk.labels_ = risk.labels)
{
  title_=main
  
  r = na.omit(r[frame])
  # plot.zoo(as.zoo(r), screens = 1, col = 1:ncol(r),
  # lwd = 3,
  #   par.settings = theEconomist.theme(box = "transparent"),
  #        lattice.options = theEconomist.opts(),  main = "prices",
  #        
  #         xlab = "Testdate", ylab = "cumsum(diff(log(price)))"
  #        )
  datum1=format(index((r)[1,]), '%d%b%y')
  datum2 = format(index(tail(r,1)[1,]), '%d%b%y')
  
  n = ncol(r)
  rgb = colorRampPalette(c("red","black", "blue"),  space = "rgb") #Lab)
  colSet = c("green",rgb(n))
  title = sprintf("%s %s-%s",title_,datum1,datum2)
  x<-selectBench(r,bench_)
  if (legend.loc_=="")
    chart.TimeSeries(x,colorset = colSet, ylab=bench_,yaxis.right=T,
                     main=title ,   ylog=ylog_ ,auto.grid=T,lwd=2,
                     event.lines = risk.dates_, event.labels = risk.labels_, event.color = "red")
  else
    chart.TimeSeries(x,legend.loc=legend.loc_,colorset = colSet,yaxis.right=F,
                     main=title ,  ylob=NULL, ylog=ylog_ ,auto.grid=T,lwd=2,
                     event.lines = risk.dates_, event.labels = risk.labels_, event.color = "red")
  
  labs=colnames(r)
  axis(2, coredata(last(r)),labels=FALSE)
  mtext(labs, 2, at=coredata(last(r)), col=1,las=1,line=1,cex=0.7)
  for (i in seq(par("yaxp")[1],par("yaxp")[2],by=(par("yaxp")[2]-par("yaxp")[1])/par("yaxp")[3])) {
    abline(h=i, col="gray70")
  }
}


########################################################################################
# hole die Bench-spalte des Datenblocks r nach vorn (damit sie farbig hervorgehobn werden kann)   
########################################################################################

selectBench<-function(r, bench=BENCH)
{
  
  r = na.omit(r)
  
  if (len(bench)< 1 || ncol(r)< 2) return(r)
  benchid = which(colnames(r)==bench)
  
  if (len(benchid) < 1) return (r)
  
  benchid = benchid[1]
  x = r[,benchid]
  res=cbind(x,r[, -benchid])
  res = na.omit(res)
  return( res)  
}


new_Win<-function(x=1)
{
  windows(record=TRUE);
  norm_Win(x)
}

norm_Win<-function(x=1)
{
  if (x==4)
    par(mfrow = c(2, 2), oma = c(0, 0, 2, 0))
  else
    par(mfrow=c(x,1))
  
}

blockInfo<-function(r = data$prices)
{
  sprintf("%s \r von %s bis %s ",toString(colnames(r)), head(index(r),1),tail(index(r),1))
}
############################################################################################################
# lies aus der MSSQL-Preis-Datenbank und mach xts - objecte daraus 
#

############################################################################################################

dbGetSeries<-function(name_, from = "2005-01-01",enddate = Sys.Date(), env=.GlobalEnv,dbServer=Sys.info()["nodename"])
{
  ti=NULL
  return (ti) #20121022: no SQL-Server installed any more
  
  start<-format(as.Date(from),"%Y%m%d")
  end<- format(as.Date(enddate),"%Y%m%d") # yyyy-mm-dd
  print(end)
  if (!is.list(name_))
    name_ <-c(name_)
  #db<-odbcDriverConnect("driver=SQL Server;server=ARTHUR\\SQLEXPRESS;Initial Catalog=Paris" )
  db<-odbcDriverConnect(paste("driver=SQL Server;server=",dbServer,"\\SQLEXPRESS;Initial Catalog=Paris; User Id=miksa;Password=milka" ,sep=""))
  
  for (name in name_)
  {
    print (name)
    Tickers <<- c( with(.GlobalEnv,Tickers),name) #h?nge den namen am globaler Tickers-Liste an
    request<-paste("SELECT Date_ AS Date, [Open], High, Low, [Close],  Volume, Price FROM  [Paris].[dbo].[PricesDB] WHERE     (Name = '",name, "'", "and Date_ > ",start, " and Date_ < ",end," )ORDER BY Date ASC" ,sep="")
    try(mts<-sqlQuery(db,request) )
    if (!is.null(mts) && dim(mts)[1] > 0)
    {
      # bd<- BusinessDays(enddate,from)
      #  row.names(mts)<-bd
      
      row.names(mts) <- as.Date(as.character(mts$Date),"%Y%m%d")
      mts$Open<-as.numeric(mts$Open)
      mts$High<-as.numeric(mts$High)
      mts$Low<-as.numeric(mts$Low)
      mts$Close<-as.numeric(mts$Close)
      mts$Price<-as.numeric(mts$Price)
      mts$Volume<-as.numeric(mts$Volume)
      colnames(mts)<-c("Date",paste(name,"Open",sep="."),paste(name,"High",sep="."),paste(name,"Low",sep="."),paste(name,"Close",sep="."),paste(name,"Volume",sep="."),paste(name,"Adjusted",sep=".")  )
      mat<-as.matrix(mts[,-1]) 
      xmat<-as.xts(mat)
      
      if   (startsWith(name,"^"))
        name <- sub( "^", "",name,fixed=TRUE)  
      # eval(parse(text=paste(ticker,qxts,sep="<-")))
      
      assign(name, xmat, envir =env)
      assign(paste(name,"_",sep=""), mts,envir=.GlobalEnv) #data.frame(qxts)
      if (is.null(xmat))
        ti=NULL else ti = get(name, envir=env)
    }
    else 
    {
      #assign(name,NULL,envir=env)
      ti=NULL #MM20120330
    }
  }
  close(db)
  return (ti)
}

############################################################################################################
#Vergleicht zwei Zeitreihen mittesl Correlation zwischen ihnen
############################################################################################################

mbox<-function(a,b)
{
  x<-NULL
  
  mb = na.omit(merge(a,b))
  colnames(mb)=c(colnames(a),colnames(b))
  return (x<-as.xts(mb )) 
}

mbox2<-function(li)
{
  x<-NULL
  
  mb = na.omit(merge(a,b))
  colnames(mb)=c(colnames(a),colnames(b))
  return (x<-as.xts(mb )) 
}

# as.symbol(Dax)
# deparse(quote(Dax))
# typeof(Dax)
# as.character(Dax)
# Dax$name
# xx=mReturn(mbox(Cl(Dax),Cl(CRB)))
# chart.RiskReturnScatter(xx)
# chart.CumReturns(xx,legend.loc="bottom")

mBox<-function(L)
{
  
  x<-NULL
  a= L[[1]]
  a=apply(L[-1],FUN= function(b) na.omit(merge(a,b)))
  return (a)
  return (x<-as.xts(na.omit(merge(a,b)) )) 
}



#l <- mapply(FUN=load.ets.trades, date=dates, filename=filenames)

chartCompare2  <-function(dax,rex=NULL, corrWin=100)
{
  Yen10y<- NULL
  
  if (is.null(rex ) || is.numeric(rex))      {
    Yen10y = dax}
  else
  {
    Yen10y =na.omit(merge(dax,rex))
  }
  
  chart.Correlation(Yen10y)
  
  
  #define colors
  #use derivative of indianred4 with alpha for Yen
  rgbnum <- col2rgb("indianred4")
  col.yen <- rgb(rgbnum[1],rgbnum[2],rgbnum[3],alpha=180,maxColorValue=255)
  #use derivative of steelblue4 with alpha for US 10y
  rgbnum <- col2rgb("steelblue4")
  col.10y <- rgb(rgbnum[1],rgbnum[2],rgbnum[3],alpha=180,maxColorValue=255)
  
  #2 rows and 1 column of graphs
  par(mfrow=c(2,1))
  par(oma=c(0,1,0,0))
  opar <- par(mai = c(0, 0.8, 0.5, 0.8))
  #plot the Japanese Yen
  plot.zoo(Yen10y[,1], type="l",
           xaxt="n", xlab=NA, ylab="Yen (US$/JPY)",
           col=col.yen, col.lab=col.yen, col.axis=col.yen,
           lwd=3,bty="n",fg = "gray70")
  #do grid for y
  for (i in seq(par("yaxp")[1],par("yaxp")[2],by=(par("yaxp")[2]-par("yaxp")[1])/par("yaxp")[3])) {
    abline(h=i, col="gray70")
  }
  title(main=colnames(Yen10y),adj=0,outer=TRUE,line=-2)
  
  par(new=TRUE)
  plot.zoo(Yen10y[,2], type="l",
           xaxt="n", yaxt="n", xlab=NA, ylab=NA,
           col=col.10y, col.lab=col.10y,
           lwd=3,bty="n",fg = "gray70")
  axis(side=4,col.axis=col.10y,fg="gray70")
  usr <- par("usr")
  text(usr[2] + .12 * diff(usr[1:2]), mean(usr[3:4]), "US 10y Yield %",
       srt = 90, xpd = TRUE, col = "steelblue4")
  par(opar)
  opar <- par(mai = c(0.8,0.8,0.2,0.8))
  
  #plot running correlation between yen and US 10y
  plot.zoo(runCor(Yen10y[,1],Yen10y[,2],n=corrWin),
           xlab=NA, ylab = NA,
           lwd=3,bty="n",
           col.axis="gray30",col.lab="gray30",col="gray30",fg="gray30")
  title(main=paste("Rolling",toString(corrWin)," days Correlation",sep=""), cex.main=0.9, adj=0, col.main="gray30")
  for (i in seq(-1,1,by=1)) {
    abline(h=i, col="gray70")
  }
  axis(side=4,labels=FALSE,fg="gray70")
  par(opar)
  
  
}
###############################################################################
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
###############################################################################
# Collection of General Utilities
# Copyright (C) 2011  Michael Kapler
#
# For more information please visit my blog at www.SystematicInvestor.wordpress.com
# or drop me a line at TheSystematicInvestor at gmail
###############################################################################

compute.annual.factor = function(x) {
  possible.values = c(252,52,26,13,12,6,4,3,2,1)
  index = which.min(abs( nrow(x) / compute.nyears(x) - possible.values ))
  round( possible.values[index] )
}

###############################################################################
# Convenience Utilities
###############################################################################


###############################################################################
# Join vector of strings into one string using delim
###############################################################################
join <- function
(
  v, 			# vector of strings
  delim = ''	# delimiter
)
{ 
  return(paste(v,collapse=delim)); 
}

###############################################################################
# Remnove any leading and trailing spaces
###############################################################################
trim <- function
(
  s	# string
)
{
  s = sub(pattern = '^ +', replacement = '', x = s)
  s = sub(pattern = ' +$', replacement = '', x = s)
  return(s)
}
trim_ <- function
(
  s  # string
)
{
  s = sub(pattern = '^_+', replacement = '', x = s)
  s = sub(pattern = '_+$', replacement = '', x = s)
  return(s)
}

###############################################################################
# Get the length of vectors
############################################################################### 
len <- function
(
  x	# vector
)
{
  return(length(x)) 
}

###############################################################################
# Fast version of ifelse
############################################################################### 
iif <- function
(
  cond,		# condition
  truepart,	# true part
  falsepart	# false part
)
{
  if(len(cond) == 1) { if(cond) truepart else falsepart }
  else {  
    if(length(falsepart) == 1) {
      temp = falsepart
      falsepart = cond
      falsepart[] = temp
    }
    
    if(length(truepart) == 1) 
      falsepart[cond] = truepart 
    else 
      falsepart[cond] = truepart[cond]
    
    #falsepart[!is.na(cond)] = temp
    
    return(falsepart);
  }
} 

###############################################################################
# Check for NA, NaN, Inf
############################################################################### 
ifna <- function
(
  x,	# check x for NA, NaN, Inf
  y	# if found replace with y
) { 	
  return(iif(is.na(x) | is.nan(x) | is.infinite(x), y, x))
}

###############################################################################
# Count number of non NA elements
############################################################################### 
count <- function(
  x,			# matrix with data
  side = 2	# margin along which to count
)
{
  if( is.null(dim(x)) ) { 
    sum( !is.na(x) ) 
  } else { 
    apply(!is.na(x), side, sum) 
  }
}  

###############################################################################
# Running over window Count of non NA elements
############################################################################### 
run.count <- function
(
  x, 			# vector with data
  window.len	# window length
)
{ 
  n    = length(x) 
  xcount = cumsum( !is.na(x) )
  ycount = xcount[-c(1 : (k-1))] - c(0, xcount[-c((n-k+1) : n)])
  return( c( xcount[1:(k-1)], ycount))
}

###############################################################################
# Day of Week
############################################################################### 
date.dayofweek <- function(dates) 
{	
  return(as.double(format(dates, '%w')))
}

date.day <- function(dates) 
{	
  return(as.double(format(dates, '%d')))
}

date.week <- function(dates) 
{	
  return(as.double(format(dates, '%U')))
}

date.month <- function(dates) 
{	
  return(as.double(format(dates, '%m')))
}

date.year <- function(dates) 
{	
  return(as.double(format(dates, '%Y')))
}


date.week.ends <- function(dates) 
{	
  return( unique(c(which(diff( 100*date.year(dates) + date.week(dates) ) != 0), len(dates))) )
}

date.month.ends <- function(dates) 
{	
  return( unique(c(which(diff( 100*date.year(dates) + date.month(dates) ) != 0), len(dates))) )
}

Dates.month.ends <- function(dates) 
{  
  library(timeDate)  
  #tS = timeSequence(from = "2008-01-01", to = "2008-12-31", by = "month")
  # Do you want the last Day or the last Friday in Month Data ?
  as.Date(unique(timeLastDayInMonth(dates)))
  
}
Dates.week.ends <- function(dates) 
{  
  library(timeDate)  
  as.Date(unique(dates[isWeekday(dates, wday = 5)]))  #5 heisst freitags
  
}

Dates.quarter.ends <- function(dates) 
{  
  library(timeDate)  
  #tS = timeSequence(from = "2008-01-01", to = "2008-12-31", by = "month")
  # Do you want the last Day or the last Friday in Month Data ?
  as.Date(unique(timeLastDayInQuarter(dates)))
  
}

date.year.ends <- function(dates) 
{	
  return( unique(c(which(diff( date.year(dates) ) != 0), len(dates))) )
}

# map any time series to monthly
map2monthly <- function(equity) 
{
  #a = coredata(Cl(to.monthly(equal.weight$equity)))
  
  if(compute.annual.factor(equity) >= 12) return(equity)
  
  dates = index(equity)
  equity = coredata(equity)
  
  temp = as.Date(c('', 10000*date.year(dates) + 100*date.month(dates) + 1), '%Y%m%d')[-1]
  new.dates = seq(temp[1], last(temp), by = 'month')		
  
  map = match( 100*date.year(dates) + date.month(dates), 100*date.year(new.dates) + date.month(new.dates) ) 
  temp = rep(NA, len(new.dates))
  temp[map] = equity
  
  #range(a - temp)
  
  return( make.xts( m.ifna.prev(temp), new.dates) )
}

# create monthly table
create.monthly.table <- function(monthly.data) 
{
  nperiods = nrow(monthly.data)
  
  years = date.year(index(monthly.data[c(1,nperiods)]))
  years = years[1] : years[2]
  
  # create monthly matrix
  temp = matrix( double(), len(years), 12)
  rownames(temp) = years
  colnames(temp) = spl('Jan,Feb,Mar,Apr,May,Jun,Jul,Aug,Sep,Oct,Nov,Dec')
  
  # align months
  index = date.month(index(monthly.data[c(1,nperiods)]))
  temp[] = matrix( c( rep(NA, index[1]-1), monthly.data, rep(NA, 12-index[2]) ), ncol=12, byrow = T)
  
  return(temp)
}


# http://www.mysmp.com/options/options-expiration-week.html
# The week beginning on Monday prior to the Saturday of options expiration is referred to as options expiration week. 
# Since the markets are closed on Saturday, the third Friday of each month represents options expiration.
# If the third Friday of the month is a holiday, all trading dates are moved forward; meaning that Thursday will be the last trading day to exercise options.
# http://www.cboe.com/TradTool/ExpirationCalendar.aspx

# The expiration date of stock options (3rd Friday of the month)
# http://bytes.com/topic/python/answers/161147-find-day-week-month-year
third.friday.month <- function(year, month)
{
  day = date.dayofweek( as.Date(c('', 10000*year + 100*month + 1), '%Y%m%d')[-1] )
  day = c(20,19,18,17,16,15,21)[1 + day]
  return(as.Date(c('', 10000*year + 100*month + day), '%Y%m%d')[-1])
}




###############################################################################
# Timing Utilities
###############################################################################
# Begin timing
###############################################################################
tic <- function
(
  identifier	# integer value
)
{
  assign(paste('saved.time', identifier, sep=''), proc.time()[3], envir = .GlobalEnv)
}

###############################################################################
# End timing
###############################################################################
toc <- function
(
  identifier	# integer value
)
{
  if( exists(paste('saved.time', identifier, sep=''), envir = .GlobalEnv) ) {
    prevTime = get(paste('saved.time', identifier, sep=''), envir = .GlobalEnv)
    diffTimeSecs = proc.time()[3] - prevTime
    cat('Elapsed time is', round(diffTimeSecs, 2), 'seconds\n')
  } else {
    cat('Toc error\n')
  }    
  return (paste('Elapsed time is', round(diffTimeSecs,2), 'seconds', sep=' '))
}

###############################################################################
# Test for timing functions
###############################################################################
test.tic.toc <- function()
{
  tic(10)
  for( i in 1 : 100 ) {
    temp = runif(100)
  }
  toc(10)
}


###############################################################################
# Matrix Utilities
###############################################################################
# Lag matrix or vector
#  mlag(x,1) - use yesterday's values
#  mlag(x,-1) - use tomorrow's values
###############################################################################
mlag <- function
(
  m,			# matrix or vector
  nlag = 1	# number of lags
)
{ 
  # vector
  if( is.null(dim(m)) ) { 
    n = len(m)
    if(nlag > 0) {
      m[(nlag+1):n] = m[1:(n-nlag)]
      m[1:nlag] = NA
    } else if(nlag < 0) {
      m[1:(n+nlag)] = m[(1-nlag):n]
      m[(n+nlag+1):n] = NA
    } 	
    
    # matrix	
  } else {
    n = nrow(m)
    if(nlag > 0) {
      m[(nlag+1):n,] = m[1:(n-nlag),]
      m[1:nlag,] = NA
    } else if(nlag < 0) {
      m[1:(n+nlag),] = m[(1-nlag):n,]
      m[(n+nlag+1):n,] = NA
    } 
  }
  return(m);
}

###############################################################################
# Replicate and tile an array
# http://www.mathworks.com/help/techdoc/ref/repmat.html
###############################################################################
repmat <- function
(
  a,	# array
  n,	# number of copies along rows
  m	# number of copies along columns
)
{
  kronecker( matrix(1, n, m), a )
}

###############################################################################
# Compute correlations
###############################################################################
compute.cor <- function
(
  data, 		# matrix with data
  method = c("pearson", "kendall", "spearman")
)
{
  nr = nrow(data) 
  nc = ncol(data) 
  
  corm = matrix(NA,nc,nc)
  colnames(corm) = rownames(corm) = colnames(data)
  
  for( i in 1:(nc-1) ) {
    temp = data[,i]
    for( j in (i+1):nc ) {
      corm[i,j] = cor(temp, data[,j], use='complete.obs', method[1])	
    }
  }
  return(corm)
}

###############################################################################
# XTS helper functions
###############################################################################
##############################################################################

###############################################################################
# Write XTS object to file
###############################################################################
write.xts <- function
(
  x,			# XTS object
  filename	# file name
)
{
  dir.create(dirname(filename),recursive=T)
  write.csv(x, row.names = index(x), filename)	
}

###############################################################################
# Work with file names
###############################################################################
get.extension <- function(x) 
{ 
  trim( tail(spl(x,'\\.'),1) ) 
}	

get.full.filename <- function(x) 
{ 
  trim( tail(spl(gsub('\\\\','/',x),'/'),1) ) 
}



get.filename <- function(x) 
{ 
  temp = spl(get.full.filename(x),'\\.')
  join(temp[-len(temp)])
  
  
  #############################################################
  #Text-Ausgabe wie bei sprintf() in c
  #############################################################
  
  mP<-  function(...)
  {
    print(sprintf(...))
  }
  
  # Function to compute percentage returns
  pchange <- function(x) { exp(diff(log(x)))-1 }
  
  # The weighted mean function
  wmean <- function(x) { n <- length(x); w <- seq(n); return(sum(w*x)/sum(w)) }
  
  
  ######################################################################
  # Beispspiel f?r DeOptim und auch den 3-dPlot
  #siehe auch o:\R\Nuggets\Optimizing\Optimization.pdf
  #######################################################################
  
  
  chart.DownsideTable<-function(returnComparison)
  {
    
    #  returnComparison<-merge(ret,RetToAnalyze)
    #  colnames(returnComparison)<-c(colnames(ret),colnames(RetToAnalyze))
    #  charts.PerformanceSummary(returnComparison, main="compare",
    #                            colorset = redfocus)
    
    
    downsideTable<-melt(cbind(rownames(table.DownsideRisk(returnComparison)),table.DownsideRisk(returnComparison)))
    colnames(downsideTable)<-c("Statistic","Portfolio","Value")
    ggplot(downsideTable, stat="identity", aes(x=Statistic,y=Value,fill=Portfolio)) + geom_bar(position="dodge") + coord_flip()
    downsideTable
  }
  ######################################################################
  # Beispspiel f?r DeOptim und auch den 3-dPlot
  #siehe auch o:\R\Nuggets\Optimizing\Optimization.pdf
  #######################################################################
  rastrigin <-function(x1,x2) ## schr?ge Funktion mit vielen Optima
  {
    phi=3.14159
    x1=as.double(x1)
    x2 = as.double(x2)
    ret = as.double(20+x1*x1+x2*x2-10*(cos(2*phi*x1)+cos(2*phi*x2)))
    return (ret) 
  }
  
  #### erzeuge ein fiese MultiH?gel--Testoberfl?che um den Optimiere zu testen
  ##### 3dPlot
  if (FALSE)
  { 
    rastriginDemo <-function()
    {
      mmax=-1000  
      xmax=0
      ymax=0
      
      X=seq(-5,5,by=0.1)
      Y=seq(-5,5,by=0.1)
      
      m=matrix(nrow=length(X),ncol=length(Y))
      for (x in X )
        for (y in Y)
        {
          m#P("x = %f, y= %f",x,y)    
          m[y*10+51,x*10+51] = (v=rastrigin(x,y))
          if (v >= mmax)
          {
            xmax=x;ymax=y; mmax = v
            #mP("max %f at %f %f ",mmax,xmax,ymax)
          }
        }
      
      mP("max %f at %f %f ",mmax,xmax,ymax)
      ######### 3d Plot ######
      library(rgl)
      persp3d(x=X,y=Y, z=m, box=FALSE, col=m)
      
      return (m)
    }
    
    m=rastriginDemo()
    rastrigin(-4.5,-4.5)
    rastrigin(-5,-5)
    
    
    #DEoptim   MINIMIERT  Funktionen deren Parameter als vector ?bereben wurden
    Rastrigin<-function(xvec)
    {
      x1 = xvec[1]
      x2 = xvec[2]
      res = ( 1 / (1+rastrigin(x1,x2)))
      return (res)
    }
    
    Rastrigin(c(-4.5,-4.5))
    Rastrigin(c(4.522998 ,-4.522998)) 
    library(DEoptim)
    args(DEoptim.control)
    #   function (VTR = -Inf, strategy = 2, bs = FALSE, NP = 50, itermax = 200,
    #             CR = 0.5, F = 0.8, trace = TRUE, initialpop = NULL, storepopfrom = itermax +
    #               1, storepopfreq = 1, checkWinner = FALSE, avWinner = TRUE,
    #             p = 0.2)
    #     NULL
    #   NP number of population member
    #   itermax max number of iterations (population generations)
    #   strategy dierential evolution strategy
    #   F step size for scaling dierence
    #   CR crossover probability
    #   VTR value-to-reach
    # 
    
    res<-DEoptim(fn=Rastrigin,lower=c(-5,-5),upper=c(5,5),control=list(storepopfrom=1,itermax=1000))
    res$optim
    
    t<-function(x) return (1/(x))
    res<-DEoptim(fn=t,lower=c(1),upper=c(500),control=list(storepopfrom=1,itermax=1000))
    res$optim
    
    #############################################################################
    
    #  tail(Dax)
    Prices <-dbGetSeries("Dax",from="2011-06-01")
    prices = getSymbols('SPY', src = 'yahoo', from = '2012-01-01', auto.assign = F)
    
    data <-dbGetSeries("Dax",from="1999-06-01")
    
    plot(Prices, ylim = range(OHLC(Prices)))
    plota(Prices, type = 'ohlc',  ylim = range(OHLC(Prices)))
    chartSeries(Prices,theme='white',TA='addRSI(n=5);addBBands(n=5)')
    
    first(Prices, "1 week")
    
    #bt.simple.test <- function()
    #{
    # load.packages('quantmod')
    
    # load historical prices from Yahoo Finance
    data = getSymbols('SPY', src = 'yahoo', from = '1980-01-01', auto.assign = F)
    
    # Buy & Hold
    signal = rep(1, nrow(data))
    buy.hold = bt.simple(data, signal)
    
    # MA Cross
    sma = SMA(Cl(data),200)
    signal = ifelse(Cl(data) > sma, 1, 0)
    sma.cross = bt.simple(data, signal)
    
    # Create a chart showing the strategies perfromance in 2000:2009
    dates = '2010::2013'
    buy.hold.equity <- buy.hold$equity[dates] / as.double(buy.hold$equity[dates][1])
    sma.cross.equity <- sma.cross$equity[dates] / as.double(sma.cross$equity[dates][1])
    
    chartSeries(buy.hold.equity, TA=c(addTA(sma.cross.equity, on=1, col='red')),	
                theme ='white', yrange = range(buy.hold.equity, sma.cross.equity) )	
    #}
    
    
    #con = gzcon(file('o:/R/Nuggets/frameworks/SystematicInvestorToolbox/bt_test.r', 'rb'))
    #source(con) #MMcheck
    
    #close(con)
    
    bt.empty.test()
    bt.matching.dtw.test()
  }
}

######################################################################
# Beispspiel f?r DeOptim und auch den 3-dPlot
#siehe auch o:\R\Nuggets\Optimizing\Optimization.pdf
#######################################################################

yearList<-function(from_,to_,by_=1)
{
  if (from_ == to_)
    return(from_)
  ls=NULL
  for(i in seq(from=from_,to=to_, by=by_))
    if (is.null(ls))
      ls=i else ls = sprintf("%s,%s",ls,i)
  return(spl(ls))
}


#hList =hash()

######################################################################
#assoc-Liste die dem Key sval mit einer Liste von featuren assoziiert.
#pro Aufruf kommt wird die passenden feature-Liste verl?ngert
#######################################################################

addFeature<-function(hList, sVal,feature)
{
  if (is.null(hList[[sVal]]))      
  {
    jkBinList = list(feature)
    hList [[sVal]]= jkBinList   #asso of SVal with List of jk-Values that generate this sVal    
    
  }
  else
  {
    jkBinList = hList[[sVal]]
    jkBinList = c(jkBinList, list(feature))  #verl?ngere die jkBinList des sVal um eine weiteres jkTupel 
    hList [[sVal]]= jkBinList
  }
  return (hList)  
}

# hList <- hash()
# 
# s=2.1123274
# sVal= toString(round(s,1))
# hList=addFeature(hList,sVal, c(6,7))
# hList=addFeature(hList,"5.2", c(99,3))
# hList=addFeature(hList,"2.1", c(299,223))
# hList
# len(hList[["2.1"]])
# 


#euklidscher Abstand
Euklid_distance <- function (x1, x2) {
  temp <- x1 - x2
  sum(temp * temp)
}
#Euklid_distance(c(1,1),c(4,4))

#undebug(mL)
mL <-function(r)
{
  
  print("mL --->")
  print   (head(r,1))
  print (tail(r,1))
  cat ("cols: ", ncol(r)," lines: ",nrow(r))
}


fromTo <-function(r=data$prices,visual=T)
{
  #  r
  # browser()
  if (!exists("r") || is.null(r) || len(r) ==0 || len( dim(r)) ==0 || dim(r)[1]<1)
  {
    mP("fromTo() called with null")
    browser()
    return(c (0,0))
  }
  Auflegedatum=format(time(head(r,1)), '%Y-%m-%d')
  Bisdatum = format(time(tail(r,1)), '%Y-%m-%d')
  
  #Auflegedatum=format(time((r)[1,]), '%d%b%y')
  #Bisdatum = format(time(tail(r,1)[1,]), '%d%b%y')
  if (visual) cat (colnames(r),"\ncols: ", ncol(r)," lines: ",nrow(r),"\n",Auflegedatum,Bisdatum,"\n")
  return(c (Auflegedatum,Bisdatum))
}


fromToS <-function(r=data$prices)
{
  #browser()
  Auflegedatum=format(time(head(r,1)), '%Y-%m-%d')
  Bisdatum = format(time(tail(r,1)), '%Y-%m-%d')
  ret=sprintf("%s::%s",Auflegedatum,Bisdatum)
  return(ret)
}


#########################################################################################
writeIndexUniverse <-function(iname)
{
  indexProvider = getProviderTicker(iname)  
  index = indexProvider$tick
  stoxxTicker = getIndexComposition(index)
  m = cbind(stoxxTicker)
  colnames(m)<-c("member")
  file_ = sprintf("Models/universe%s.csv",iname)
  dir.create(dirname(file_),recursive=T)  
  mP("writeIndexUniverse %s",file_)
  write.table(m,file=file_,row.names=F,quote=F)
  cat(index," = ",iname,"\n",file_)
  return(iname)
}

#stoxxTicker = getIndexComposition("^Stoxx50E")
#writeIndexUniverse("^Stoxx50E")

########################################################################################
ALTrmSymbol<-function(symbolstr, data=.GlobalEnv)
{
  # browser()#TT
  
  #i=symbol
  if (exists(symbolstr,envir=data))
  {
    #  sym = paste("",i,"",sep="'")
    #  text_=paste("rm(",sym,",envir=data)")    
    
    
    symbol=get(symbolstr, envir=data) #[symbolstr]
    mP("rmSymbol %s !!!!!!!!!!!!!!!!!  %s",symbolstr,toString(symbol))
    
    #assign("Dax",i,data)
    #ls(data)
    #symbolstr="Dax"
    
    nam=paste("'",symbolstr,"'",sep="")
    
    cat(nam)
    browser()
    rm(list(nam),envir=data)
    #rm(nam,envir= data)
    #ls(data)
    
    #   rm(i,envir = data)
    
    #  eval(parse(text=text_))
  }
}


rmSymbol<-function(symbolstr, envir=.GlobalEnv)
{
  data= envir
  if (exists(symbolstr,envir=data))
  {
    #  sym = paste("",i,"",sep="'")
    #  text_=paste("rm(",sym,",envir=data)")    
    
    mP("rmSymbol %s !!!!!!!!!!!!!!!!!  \n",symbolstr)
   # stacktrace()
#    browser()  
  
    #symbol=data[[symbolstr]]
    #rm(symbol,envir= data)
    
    #   rm(i,envir = data)
    text_=sprintf("rm(%s,envir=data)",symbolstr)
    #  browser()
    eval(parse(text=text_))
  }
}



listTicks<-function(data=.GlobalEnv)
{
  cat("\nlistTicks --->>>\n")
  for (tick_ in ls(data))
  {
    #tick_ = "Dax"
    #cat("\ncheck symbol ------ ",tick_)
    tick= get(tick_,envir=data)
    if (length(tick)!=0 && !is.null(tick) && isPrice(tick,tick_))
      cat("##################",tick_,"\n")
  }
}
#isPrice(dax,"dax")

delNonPrices <-function(data=data)
{
  cat("delNonPrices-->>")
  print(ls(data))
  #debug(isPrice)
  #browser()  
  #if (exists("symbolnames",envir=data))
  #  bt.prep.remove.symbols(b=data)
  
  for (tick_ in ls(data))
  {
    #tick_ = "Dax"
    cat("\ncheck symbol ------ ",tick_)
    #  browser() #T
    tick= get(tick_,envir=data)
    
    if (length(tick)==0 || is.null(tick) || !isPrice(tick,tick_))
    {
      cat("\n +++++#################### rmSymbol ", tick_)
      browser()
      #Browser()#TTT
      #rm(tick_,envir=data)
      rmSymbol(tick_, envir=data)
    }
  }
  cat("<<<<< delNonPrices")
  print(ls(data))
  
}



if (F)
{
  ls(data)
  #ist das tick=data[[i]]  item ein kurs ?
  sym=data[["dates"]]
  head(sym)
  #symbolExists(sym,data)
  as.symbol(sym)
  tickName(sym)
  
  data
  as.name(sym)
  get(sym,data)
  
  exists(sym,data)
}


symbolExists<-function(sym,data=.GlobalEnv)
{
  return(exists(sym,envir = data))
  ok= tryCatch(length(sym)> 0, error = function(...) return(F))
  return (ok)
}


mtrim <- function
(
  s  # string
)
{
  s = sub(pattern = '^ +', replacement = '', x = s)
  s = sub(pattern = ' +$', replacement = '', x = s)
  return(s)
}




#gib mir die Spalte die im Bezeichner col stehen hat
mCol<-function(wp,col)
{
  coli=grep(col,colnames(wp))
  if (coli > 0)
    return(wp[,coli])
  return(NULL)
}





tickName<-function(tick_, data = .GlobalEnv)
{
  tick_= mtrim(tick_)  
  otick = tick_
  
  if (!symbolExists(tick_,data) || !is.character(tick_))
  {
    mL("#####################>>>>>> wrong usage  at tickName")
    return ("")
  }
  
  if (exists(tick_,data))
  { 
    #print( paste("\ntick!Name:", tick_,":"))
    
    tick=get(tick_,data)   
    tick_=""
    
    if (len(colnames(tick))>0)
    {
      col1 = colnames(tick)[1]
      if (len(col1)>0)
        if (len( grep("\\.Close",col1))>0 || len( grep("\\.Open",col1))>0 || len( grep("\\.High",col1))>0 || len( grep("\\.LOw",col1))>0)
        {
          jead=unlist(strsplit(colnames(tick)[1], "\\."))
          if (len(jead)>0 )
            tick_ = otick #jead[1]
        }
    }
    else
      tick_ = ""
    return(tick_)
  }
  else 
    return("") 
}

#tickName("dax")


isPrice <-function(tick,tick_)
{
  
  #return(tickName(tick_)!= "")
  
  #browser() #MMX
  
  
  if (length(tick) ==0 || is.null(tick)  )
    return (F)
  if (length(colnames(tick)) ==0 || is.null(colnames(tick))  )
    return (F)
  
  #print("\n")
  #print(colnames(tick))
  
  alttick_ = unlist(strsplit(colnames(tick)[1], "\\."))[1]
  if (length(which(colnames(tick)==sprintf("%s.Close", tick_)))>0 || length(which(colnames(tick)==sprintf("%s..Close", tick_))))
    return(T)
  if (length(which(colnames(tick)==sprintf("%s.Close", alttick_)))>0 || length(which(colnames(tick)==sprintf("%s..Close", alttick_))))
    return(T)
  
  return(F)
}


#################### Gib die Liste der Symbole aus envir zurück die im Sinne .Open,...Close als tickNames sind

#dataPrices()
dataPrices<-function(envir=.GlobalEnv)
{
  
  t2 =lapply(ls(envir), FUN=function(x)  tickName(x,data=envir))  
  #browser() #T! dataPrices
  if (len(t2)>0)
    return(unlist(t2)[t2 !=""])
  else
  { cat("Warning: dataPrices:  no data !!")
    return(list())
  }
}


#*****************************************************************
# drawDowns f?r Trailingstop
#mr =  cumprod(1+na.omit(diff(log(clos[starti:endi]))))
#DrawD = drawD(mr,8,geometric=T)
#par(mfrow=c(2,1))
#plot(mr)
#plot(DrawD$dd)

#if (DrawD$kbreak>0)#trailing stop triggered
#{}  
#****************************************************************** 
drawD_<-function(y, thresh=0,geometric=F,firstDate =F) #MM!  #MMA
{
  if (!is.null(firstDate))
    y = y[sprintf("%s::",firstDate)]
  
  nal=len(y[is.na(y[,1])])
  if (nal > 0)
    mP("Warning in drawD:  omit %d NA s",nal)
  y=na.omit(y)
  
  kbreak=-1
  maxDDpct=maxDD=0
  bestval = as.numeric(y[1])
  bestvali=1
  dd=y
  
  
  
  for(i in 1:length(y))
  {
    yval=as.numeric(y[i])
    #browser()
    if (yval > bestval)
    {bestval=yval
     bestvali = index(y[i])
    }
    if (geometric)
      DDpct=  DD = (bestval-yval) / bestval * 100
    else
    {DD=bestval-yval
     DDpct = (bestval-yval) / bestval * 100
    }
    #dd[i] = DD
    if (maxDD< DD)
    {maxDD=DD
     maxDDpct= DDpct  
    }
    if (thresh> 0 && maxDDpct > thresh)
    {kbreak=index(y[i])
     break 
    }
    
  }
  DD = (bestval-yval) / bestval * 100
  
  if (kbreak<0) kbreak = ""
  else  kbreak=as.Date(index(y[kbreak]))
  
  if (bestvali <0) bestvali=""
  else bestvali= as.Date(index(y[bestvali]))
  
  return(list(maxDD=maxDDpct,bestvali=bestvali, bestval=bestval,kbreak=kbreak ))
}

drawD<-cmpfun(drawD_) #compilier das Teil


drawU_<-function(y, thresh=0,geometric=F,firstDate =NULL)
{
  if (!is.null(firstDate))
    y = y[sprintf("%s::",firstDate)]
  
  nal=len(y[is.na(y[,1])])
  if (nal > 0)
    mP("Warning in drawU:  omit %d NA s",nal)
  y=na.omit(y)
  
  kbreak=-1
  maxDUpct=maxDU=0
  bestval = as.numeric(y[1])
  bestvali=1
  du=y
  for(i in 1:length(y))
  {
    yval=as.numeric(y[i])
    if (yval < bestval)  #diesmal ist das das min
    {bestval=yval
     bestvali = index(y[i])  #der geht aufs kommende Minimum
    }
    if (geometric)
      DUpct=  DU = (yval-bestval) / yval * 100
    else
    {DU=yval-bestval
     DUpct =  (yval-bestval) / yval * 100
    }
    #du[i] = DU
    if (maxDU< DU)
    {maxDU=DU
     maxDUpct= DUpct  
    }
    if (kbreak ==-1 && thresh> 0 && maxDUpct > thresh)
    {kbreak=index(y[i])
     break 
    }
  }
  DU = (yval-bestval) / yval * 100
  
  if (kbreak<0) kbreak = ""
  else  kbreak=as.Date(index(y[kbreak]))
  
  if (bestvali <0) bestvali=""
  else bestvali= as.Date(index(y[bestvali]))
  
  return(list(maxDU=maxDUpct,bestvali=bestvali, bestval=bestval, kbreak=kbreak))
}

drawU<-cmpfun(drawU_) #compilier das Teil




################################################################################
#zeigt (grafisch animiert in zwei Plots) wie sich eine DrawDown-DrawUp -Folge
#durch die Zeit bewegt - und dabei eine Trendst�cke-partitionierung vornimmt.

#Indikatoren sollten stehts so trainiert werden, dass sie nur an den 
#Trendwechselstellen �nderungssignale von sich geben !!!
#Dax=Cl(data$DAX)["2007::2009-06"]
if (F)
{  
  DdownDupWalkAhead(Dax,10,5)
  maxDrawDown=10
  
  minDrawUp=5
  visual=T
}
################################################################################
##Dax = Cl(Dax)
DdownDupWalkAhead_<-  function(Dax,maxDrawDown, minDrawUp,visual =T)
{
  lastDate = NULL
  myFirstDate = as.Date(index( first(Dax)))
  lastDate = NULL
  Brk=c()
  Peak=c(first(Dax))
  
  if (visual)
  {
    if (visual) 
      par(mfrow=c(1,1))
    
    plot(Dax)
    maxDax= max(Dax)
    hor = Dax; hor[]=maxDax
    lines(hor,col="blue")
    ddy = (maxDrawDown*maxDax)/100
    hor[]=max(Dax)-ddy
    lines(hor,col="red")
    userStop(" %s  "," - init - ")
    
    par(mfrow=c(2,1))
    
  }
  while(T)
  {
    DrawD = drawD(Dax,maxDrawDown,geometric=T,firstDate=lastDate)
    
    if (visual)
    {
      plot(Dax)
      peak=Dax[DrawD$bestvali]
      brk =Dax[sprintf("::%s",DrawD$kbreak)]
      lines(brk, type="h",col="red")
      lines(brk, type="l",col="blue")
      lines(peak, type="h",col="blue")
    }
    
    if (DrawD$kbreak <0)  #kein Break mehr gefunden
      break
    
    Brk = append(Brk,Dax[DrawD$kbreak])   #Ergebnisbildung
    
    #browser()
    Peak= append(Peak,Dax[DrawD$bestvali])   
    ##suche einen DrawUp von wenigstens  minDrawUp%  -- andernfalls krieg ich f�r diesen Trend nicht mals die Transaktionskosten rein !
    
    lastDate = DrawD$bestvali
    lastDate = DrawD$kbreak
    
    #Dax = Dax[sprintf("%s::",lastDate)]   #weiter am dem bestVall des letzten DD
    DrawU = drawU(Dax,minDrawUp,geometric=T,firstDate=lastDate)
    if (visual)
    {
      plot(Dax)
      peak=Dax[as.Date(DrawU$bestvali)]
      lines(peak, type="h",col="blue")
      brk =Dax[sprintf("%s::%s",lastDate,DrawU$kbreak)]
      lines(brk, type="h",col="green")
      lines(brk, type="l",col="blue")
      lines(peak, type="h",col="blue")
    }
    if (DrawU$kbreak <0)  #kein Break mehr gefunden
      break
    
    Brk = append(Brk,Dax[DrawU$kbreak])   #Ergebnisbildung
    Peak= append(Peak,Dax[DrawU$bestvali]) 
    
    lastDate = DrawU$bestvali
    lastDate = DrawU$kbreak
    
    if (visual)
    {
      print(lastDate)      
      print(Peak)
      userStop(" %s  ",lastDate)
    }
    #print(lastDate)
    if (lastDate <= myFirstDate)
      break 
  }
  #Gib die Liste mit den Zeitstempeln zur�ck
  Peak= append(Peak,last(Dax))
  res =list(brk=Brk, peak=Peak)
  return(res)
}  
DdownDupWalkAhead<-cmpfun(DdownDupWalkAhead_) #compilier das Teil


amark<-function(dat="2002-03-01",col="magenta")
{
  if (is.xts(dat))
    dat = index(dat)
  
  if (is.vector(dat))
  {
    dat=na.omit(dat)
    lapply(dat,function(x) if (x !="") abline(v=as.POSIXct(x),col=col.add.alpha(col , 85),lwd=2))
  }
  else
    abline(v=as.POSIXct(dat),col=col.add.alpha(col , 95),lwd=3)
  return(0)
}
##########################################################################

##########################################################################
mZigZag<-function(Dax, dd=5,visual=F)
{
  ds=  DdownDupWalkAhead(Dax,dd,dd,visual=F)
  if (visual)
  {
    plot(Dax)
    lines(ds$peak,type="h",col="green")
    lines(ds$brk,type="h",col="blue")
    browser()
  }
  return(ds$peak)
}

prePreis<-function(Dax,datum)
{
  #mark(datum)
  #rowser(mP("prePeis"))
  i=get.Index(Dax,datum)
  if (i > 1)
    return(as.numeric(Dax[(i-1),]))
  else
    return(as.numeric(Dax[1,]))
  
}


mZigZag2<-function(Dax, dd=5,visual=F)
{
  print("mZigZag2")
  ds=  DdownDupWalkAhead(Dax,dd,dd,visual=F)
  
  
  
  if (F)
  {
    x=2
    amark(DateS(ds$peak[x]))
    print( ifelse(ds$peak[x]>prePreis(Dax,index(ds$peak[x])),"high","low"))
    browser(mP("zigzag2"))
  }
  k=lapply(c(1:len(ds$peak)),FUN=function(x) 
  {
    return( list(peak =ds$peak[x], brk= as.Date(index(first(ds$brk[as.Date(index(ds$brk))>as.Date(index(ds$peak[x]))]) )), ptype=toString(ifelse(ds$peak[x]>prePreis(Dax,index(ds$peak[x])),"high","low"))))
  })
  
  if (visual)
  {
    plot(Dax)
    lines(ds$peak,type="h",col="green",lwd="2")
    
    lapply(k,function(x) {if (!is.null(x$ptype)) ifelse (x$ptype=="low", amark(index(x$peak),col="red"),amark(index(x$peak),col="blue"))})
    
    lines(ds$brk,type="h",col="blue")
    browser()
  }
  
  
  
  return(k)  #patch2
}

if (F)
{
  Dax=Cl(data$DAX)["2007::2011-08"]
  k=mZigZag2(Dax,dd=5,T)
  #gib Info �ber peaks und den Zeitpunkt brk zu dem sie identifiziert wurden
  lapply(k,function(x) {
    brk=x$brk;peak=x$peak
    mP("Today is %s , found new %s some days ago: %s %f",brk,x$ptype,DateS(peak),peak)
  })
  zzLo=mZigZag2(Dax,dd=dd,visual=F)
  zzHi=mZigZag2(Dax,dd=10,visual=F)
  
  zbrk.Lo =unlist(lapply(zzLo,function(x){ ifelse(x$ptype=="low",toString(x$brk),NA) }))
  zbrk.Lo[zbrk.Lo==""] = NA; 
  
  
  zbrk.Hi =unlist(lapply(zzHi,function(x){ ifelse(x$ptype=="high",toString(x$brk),NA) }))
  zbrk.Hi[zbrk.Hi==""] = NA;
  
  plot(Dax)
  peak.Lo =na.omit(unlist(lapply(zzLo,function(x){ ifelse(x$ptype=="low",DateS(x$peak),NA) })))
  peak.Hi =na.omit(unlist(lapply(zzHi,function(x){ ifelse(x$ptype=="high",DateS(x$peak),NA) })))
  
  amark(peak.Lo,"magenta")
  amark(zbrk.Lo,"blue")
  amark(peak.Hi,"red")
  amark(zbrk.H,"blue")
  
}
#############################################################
#liest mit Runlength-Encoding die eingetroffenene Signale (-1,0,1)
#und z�hlt die trains 
#############################################################
numTrades_<-function(Sig)
{
  allT =0
  res=list()
  Sig[Sig==0] <- -1
  Sig = sign(Sig)
  
  for (i in c(1:ncol(Sig)))
  {
    i=1
    sig = as.vector(Sig[,i])#segmente positiver und negativer steigung
    enc <-rle(sig)
    n=  len(enc$lengths)  #ending indices
    name=colnames(Sig)[i]
    if (is.null(name))
      name = colnames(prices)[i]
    if (is.null(name))
      name = "Sig"
    res[[name]] = n
    allT = allT+n
  }
  res[["allT"]] = as.numeric(allT)
  return(res)
}

numTrades<-cmpfun(numTrades_) #compilier das Teil

#################################################################################
#################################################################################

getCol <-function (dat,col) 
{
  return(dat[, grep(col, colnames(dat), ignore.case = TRUE)])
  stop(sprintf("getCol(): subscript out of bounds: no column name containing %s",col))
}

#################################################################################
#################################################################################

wait <- function(){
  t <- readline("\nPlease 'q' to quit the demo or any other key to continue...\n")
  if (t == "q") TRUE else FALSE
}

#################################################################################
#################################################################################
sag <- function(str,...,warte=F){
  star <- "**********"
  cat(paste("\n",star,"\n",sprintf(str,...),"\n",star,"\n",sep=""))
  if (warte)
    wait()
}
##################################################################################
#transformiere monats oder wochendaten zu tagedaten
#quantmod hat auch:  (muss aber mit foreach multi-gespaltet werden)
#allReturns: calculate all available return periods
#dailyReturn: calculate daily returns
#weeklyReturn: calculate weekly returns
#monthlyReturn: calculate monthly returns
#quarterlyReturn: calculate quarterly returns
#annualReturn: 
##################################################################################
mto.daily<-function(monthdata)
{
  ft = fromTo(monthdata)
  startDay =ft[1]
  endDay = ft[2]
  #anzahl tage im zeitraum 
  days = -as.numeric(difftime(startDay,endDay),units="days")
  
  #eine leere xts-reihe mit dageswerten von bis
  emptyXTS = xts(1:days, as.Date(startDay)+1:days)
  #da werden die ifo-monats-werte reingeeschrieben
  ifoDrin= merge(emptyXTS, monthdata)
  #  ifoDrin = ifoDrin[,-1]
  #  head(ifoDrin)
  # backfill  auff?llen der tagedaten
  ifo=ifoDrin
  ifo[] =apply(coredata(ifoDrin), 2, m.ifna.prev)
  #rausfiltern von wochenenden
  ifo= ifo[isWeekday(time(ifo))]
  ifo = ifo[,-1]
  
  colnames(ifo)=c("dayData")
  return (ifo)
}

#################################################################################
#################################################################################
addMonth<-function(dat,n=1)
{
  s=sprintf("%d month",n)
  return (seq(as.Date(dat), by = s, length = 2)[2]  )
}

#################################################################################
#addTime(dat,-3,"day")
#################################################################################
addTime<-function(dat,n=1,d="day")
{
  s=sprintf("%d %s",n,d)
  return (seq(as.Date(dat), by = s, length = 2)[2]  )
}

######################################################################################################
# 
######################################################################################################
expectTrendBreak<-function(prices=edhec,t, maxdd=10, weights=NULL,geometric=TRUE, nStd=FALSE,visual=T)
{
  prices=prices[sprintf("%s::",t)]
  maxdd = 0.5
  colnames(prices)="Close"
  zz=na.omit(ZigZag(prices,change=maxdd,percent=T))
  
  sig=as.vector(coredata(sign(zz-lag(zz))))  #segmente positiver und negativer steigung
  enc <-rle(sig)
  enc.endidx <- cumsum(enc$lengths)  #ending indices
  enc.startidx <- c(0, enc.endidx[1:(length(enc.endidx)-1)],length(prices))  # starting indices
  
  #markiere die higss- und lows- des zigzag in unterschiedlichen farben
  highx = na.omit(enc.endidx[enc$values > 0 ]) 
  highs = prices[highx] 
  #ein Trend liegt vor, wenn die Highs in die H?he gehen
  dh = highs-lag(highs)
  colnames(dh) = "deltaHigh"
  dh[,1] = ifelse(is.na(dh),0,dh)
  
  # so lange die Highs h?her gehen geh ich von einem intakten Trend aus ...
  
  for(n in 1:length(highs))
  {
    n=2
    now_ = time(highs[n])
    if (n==1)
    {
      lastT=time(prices[1])
      trend = prices; trend[,1]=NA; TRENDn=trend[1,1]= na.omit(enc$values)[1]
      trendAbschnitt = sprintf("%s/%s",lastT,now_)
      trend[trendAbschnitt,1] = TRENDn
    }
    else
    {
      if (dh[now_] < 0 && TRENDn ==1) # trendbreak
      {
        trendAbschnitt = sprintf("%s/%s",lastT,now_)
        trend[trendAbschnitt,1] = TRENDn
        TRENDn=-1
        lastT =now_  #trendbreak
      }  
      else
      {
        trendAbschnitt = sprintf("%s/%s",lastT,now_)
        trend[trendAbschnitt,1] = TRENDn    
      }
    }   
  }  
}

##NOCH IM TEST

buyTilBreakPerf<-function(prices=edhec, maxdd=10 )
{
  #maxdd=10
  #rausfiltern von Wochenenden
  
  prices= prices[isWeekday(time(prices))]
  zz=na.omit(ZigZag(prices,change=maxdd,percent=T))
  
  sig=as.vector(coredata(sign(zz-lag(zz))))  #segmente positiver und negativer steigung
  enc <-rle(sig)
  enc.endidx <- cumsum(enc$lengths)  #ending indices
  enc.startidx <- c(0, enc.endidx[1:(length(enc.endidx)-1)],length(prices))  # starting indices
  if (is.na(enc$values[1]))
    enc$values[1] = -1*enc$values[2]
  #markiere die higss- und lows- des zigzag in unterschiedlichen farben
  #  highx = na.omit(enc.endidx[enc$values > 0 ]) 
  #  highs = prices[highx] 
  zzPoints = prices[enc.startidx]
  
  plot(prices)
  points(zzPoints,col="green",lwd=2)
  lines(zzPoints,type="l",col="red",lwd=2)
  
  ########################################
  ## summiere alle long-Teil-St?cke der zz-Zerlegung auf ret
  ret=0
  
  for(i in 1 :len(zzPoints))
  {
    #  i=len(zzPoints)
    i=5 #TEST
    now_ = as.Date(time(zzPoints[i]))
    tagSpaeter=as.Date(now_)+1
    
    tagSpaeterPrice = prices[tagSpaeter,1]
    
    isWeekend(tagSpaeter)
    
    zP = prices[as.Date(now_)]
    
    if (i==len(zzPoints))
      nextP=last(prices,1)[,1]
    else
      nextP = zzPoints[i+1,1]
    if (coredata(nextP[,1] )> coredata(zP[,1]) && tagSpaeter != now_) #long
    {
      ret = ret+(as.numeric(nextP[,1]) - as.numeric(prices[tagSpaeter,1]) ) #Transaktionskosten gehen rein indem einfach der Kurs des schlechten Folgetags genommen wird
      cat(i,"  ",toString(as.Date(now_)),toString(as.Date(tagSpaeter)), zP,tagSpaeterPrice,nextP[,1],"   ",ret,  "   \n")
    }
  }
  #ret als pct
  ret = ret/prices[1,1]*100
  
  return (as.numeric(ret))
  
}  

#goodReturn (dax,t="2005", maxdd=10,checkSGB=T)

###################################
#goodReturn #MMA
#wichtig:  die prices m�ssen mNorm sein
#ohne ylim: - warum zeigt der ZickZack 2008 ne viel feinere Zerlegung wenn ich 2007 - statt 1900 anfang ??
#ylim gibt die Range an, auf die sich die DrawDown- in Prozent beziehen - entspricht also quasi dem 100% DrawDown.
#wenn ich keinen ylim geb. wird der automatisch aus der via-frame-Selektion eher zuf�lligen range() des sichtbaren
#zeitreihenausschnitts gew�hlt ... und der kann sich heftig �ndern !!! 
#f�r ylim muss ich also objektive Werte finden - sonst werden die segmentierunge abh�nig davon welchen ausschnitt der 
#reihe ich mir anschau.
# Je weiter der ylim  Bereich ist, desto mehr Segmente wirds bei gleichem maxdd gegeben.
# im Vergleich zum  sehr langzeitigen Plot - nimmt ein Ausschnitt sich mehr y -Bandbreite
# so kommen gleiche Ergebnisse raus:
if (F)
{
  dax = merge(Hi(Dax),Lo(Dax),Cl(Dax))
  AllDax = mNorm(dax)[,3]
  P=AllDax["2007::2009"] 
  range(P)
  
  ylim= range(AllDax["2007::2009"])
  ylim
  range(AllDax)
  
  
  goodReturn(prices=AllDax,  maxdd=37,visual=T,checkSGB=T)
  #die k�rze Zeitreihe P bekommt die gleiche dynamik (ylim) zugeteilt- wie die Lange AllDax im betreffenden Zeitraum hat.
  goodReturn(prices=P,  maxdd=37,visual=T,checkSGB=T,ylim=ylim)
  
  
  goodReturn(prices=AllDax,  maxdd=37,visual=T,checkSGB=T,ylim=ylim)
  
}


###################################
goodReturn<-function(prices=edhec,t="", maxdd=10, weights=NULL,geometric=TRUE, nStd=FALSE,minReturn=0,checkSGB=F, visual=T,ylim = NULL)
{
  if (t != "")
    prices=na.omit(prices[sprintf("%s::",t)])
  else
    prices = na.omit(prices)
  pricesL1 = as.numeric(last(prices))
  #prices=mRendite(mROC(prices))
  pricesL2 = as.numeric(last(prices))
  #fac = pricesL1/pricesL2 
  #browser() 
  #plot(oprices)
  oprices = prices
  range(oprices)
  if (!is.null(ylim))
    prices = scaleTo(prices,ylim)  #vor dem ZigZag schnell mal in ein Positiv-Skalierung wechseln - sonst klappts nicht
  
  zz=ZigZag(prices,change=maxdd,percent =T,retrace=F)
  zz=na.omit(zz)  #bl�der weise gibts manchmal vorn oder hinten Inf- Werte
  
  if (len(zz)< 3)
    return(0)
  if (visual)
  {
    #browser()
    #  new_Win(1)
    plot(prices)
    lines(zz,col="red")
  }
  
  sig=as.vector(coredata(sign(zz-lag(zz))))  #segmente positiver und negativer steigung
  enc <-rle(sig)
  enc.endidx <- cumsum(enc$lengths)  #ending indices
  enc.startidx <- c(0, enc.endidx[1:(length(enc.endidx)-1)],length(prices))  # starting indices
  
  #markiere die higss- und lows- des zigzag in unterschiedlichen farben
  highx = na.omit(enc.endidx[enc$values > 0 ]) 
  
  lowx = na.omit(enc.endidx[enc$values < 0 ]) 
  lows = prices[lowx]
  
  if (first(lowx) < first(highx) )#|| first(prices)>prices[first(highx)])
  {
    highx = c(1,highx)
  }
  else
    lowx= c(1,lowx)
  
  #browser()
  ZZprice = oprices[enc.endidx,1]
  prices = oprices[,1]
  
  if (visual)
  {
    par(mfrow=c(1,1))
    plot(prices)
    lines(ZZprice,col="red")
    lines(prices,col="blue")
    
    points(prices[highx],col="green")
    points(prices[lowx],col="magenta")
  }
  alleSegmenteI = enc.endidx
  
  if(checkSGB) #Saegeblatt-BreitenUntersuchug
  {
    lasti=1
    alleSGB=c() #pro Segment eine Saegeblatt-Breite
    
    for(i in alleSegmenteI) #�ber alle zz-Segmente
    {
      if (i >first(alleSegmenteI))
      { 
        xxRet  =mROC(prices[lasti:i])
        xxPrices =prices[lasti:i,1]
        
        segx1 = lasti;
        segx2 = i
        #browser()
        if (visual)
        {
          lines(xxPrices, col="grey") #segmentabschnitt in gray
          
        }
        if (T)
        {
          X = c(segx1:segx2)
          reg=lm(xxPrices~X)    
          #reg=lm(xxPrices~c(1:len(xxPrices)))
          regfitted.values=reg$fitted.values
          lines(regfitted.values, col="green")
          #
          
          ddd = (max(xxPrices)-min(xxPrices))/2
          #if (visual)
          #  lines(xxPrices-regfitted.values+max(xxPrices)-ddd,col="brown")
          xNorm=xxPrices-regfitted.values 
          #die S�gezahnbreite
          es = abs(as.numeric(ES(p=0.90,xNorm,method = "historical")))
          alleSGB=c(alleSGB,es)
          
          if (visual)
          {
            lines(regfitted.values-es, col="brown")
            lines(regfitted.values+es, col="brown")
            
            
            
            if (F)
            {
              Maxdd = as.numeric(last(xxPrices)*maxdd/100)
              val1 = last(xxPrices)-Maxdd
              val2 = last(xxPrices)+Maxdd
              #browser()
              lines(val1, col="magenta",type="h")
              lines(val2, col="red",type="h")
            }
          }
          
          
          #predict(reg, type="response") # predicted values
          #resid=residuals(reg, type="deviance") # residuals
          
          nahead=len(prices)-segx2
          
          #prognose berechnen   #MMA
          prog= predict(reg, newdata = data.frame(X=c((segx2+1):(segx2+nahead))))
          #die prognoseXts erh�lt ihre coredaten aus der Prognose - die Dat�mer wie Fortschreibung
          progXts = xts(coredata(prog), index(prices)[segx2]+1:nahead)
          m= coef(reg)[2]
          
          if (m>=0)
            progXts = progXts-es
          else
            progXts =progXts+es
          
          #Der schnittpunkt ist der erste Punkt wo die preise unter die Prognose rutschen
          
          
          
          if (m >= 0)  #der vorhergehende Trend stieg - er prognostiziert damit dann (am Tag seines Endes)
            #die Stop-Level f�r den folgenden Trend - und zeichnet sie schon mal ein.
            cross = first(prices[segx2:len(prices)][prices <= progXts ])
          else            
            cross = first(prices[segx2:len(prices)][prices >= progXts ])
          
          # browser()
          if (len(cross)>0)
          {
            points(cross,col="red",lwd=3)
            #zeichne die Prognose-Gerade  ein - aber nur bis zum cross
            daysuntilCross=c(1: len(time(prices[segx2]):time(cross)))
            crossline = progXts[daysuntilCross]
            
            lines(crossline ,col="red",lwd=2)
          }
          #browser()
          #weitere stoplinien:
          minLineBreite = 460
          #s�geblattbreite unter dem High/Low des lezten Segement -Endes  
          if (m> 0)  
            thresh1 = xts(coredata(rep(max(xxPrices)-2*es ,   minLineBreite)), index(prices)[segx2]+1:  minLineBreite)
          else
            thresh1 = xts(coredata(rep(min(xxPrices)+2*es ,   minLineBreite)), index(prices)[segx2]+1:  minLineBreite)
          lines(thresh1,col="magenta",lwd=2)
          #maxdd unter dem High/Low des lezten Segement -Endes   - erst hier schl�gt der ZickZack zu ... !!!
          if (m> 0)  
            Thresh= max(xxPrices)-maxdd*max(xxPrices)/100
          else
            Thresh= min(xxPrices)+maxdd*max(xxPrices)/100
          thresh2 = xts(coredata(rep(Thresh ,   minLineBreite)), index(prices)[segx2]+1:  minLineBreite)
          lines(thresh2,col="black",lwd=2)
          
          #browser()
          #goodReturn(prices=AllDax,  maxdd=37,visual=T,checkSGB=T,ylim=ylim)
          
        }
        #  browser() 
      }
      lasti=i  #n�chstes Segment
    }
    
  }
  
  lagPrice = mlag(ZZprice)
  lagPrice[1,1]=0
  
  slippageI = enc.endidx+1
  slippageI[len(slippageI)]=last(enc.endidx) #den letzten Index gleich setzen - weil sonst �berlaf
  slippageP = ZZprice
  slippageP[,1]= coredata(prices[slippageI,1]) 
  slippage = ZZprice-slippageP
  
  transactionCosts = 0.03
  rets = (ZZprice-lagPrice)*(sign(ZZprice-lagPrice))-transactionCosts
  rets = rets-20*abs(slippage)
  
  cs=cumsum(rets)
  erg = as.numeric(last(cs))
  if (visual)
  {
    plot(cs)
  }
  if (checkSGB)
  {
    #browser()
    es=mean(alleSGB) #die mittlere Saegblatt-Breite 
    return(list(Segmente=len(alleSegmenteI)-1,Ertrag=erg, alleSGB=alleSGB, SaegeblattBreite=2*es))
  }
  return(list(Segmente=len(alleSegmenteI)-1, Ertrag=erg))
}




if (F)
{
  dax = merge(Hi(Dax),Lo(Dax),Cl(Dax))
  AllDax = mNorm(dax)[,3]
  P=AllDax["2007::2009"] 
  range(P)
  
  ylim= range(AllDax["2007::2009"])
  ylim
  
  goodReturn(prices=AllDax,  maxdd=37,visual=T,checkSGB=T)#MMA  - warum zeigt der ZickZack 2008 ne viel feinere Zerlegung we
  goodReturn(prices=P,  maxdd=37,visual=T,checkSGB=T,ylim=ylim)#MMA  - warum zeigt der ZickZack 2008 ne viel feinere Z 
  
  
  P0=mNorm(dax)
  mPlot(P0,ylog_=F)
  plot(P0)
  P=scaleTo(P,range(P0["2007::2009"]))
  
  PS=mmerge(P0,P)
  mPlot(PS,ylog_=F)  
  tail(PS)
  Ps =PS[,5]
  ylim=range(PS["2007::2009",1])
  goodReturn(prices=Ps,  maxdd=37,visual=T,checkSGB=T,ylim=ylim)#MMA - warum zeigt der ZickZack 2008 ne viel feinere Zerlegung we
  
  
  
  
  #bb=BBands(P,n=20,sd=2.5)[,c(1:3)]
  #mPlot(merge(P,bb))
  #dbb = P-bb
  #mPlot(merge(P,dbb[,1]))
  new_Win(1)
  bestDD = findBestDrawDown(prices=mNorm(dax[,1]))
  
  goodReturn(prices=P,  maxdd=37,visual=T,checkSGB=T) #MMA  - warum zeigt der ZickZack 2008 ne viel feinere Zerlegung wenn ich 2007 - statt 1900 anfang ??
}



##wie merge aber die Daten werden nicht auf den gemeinsamen Bereich verk�rzt - vielmehr werden die NA die bei reinem cbind auftreten durch die Start/Stop-Werte  ersetzt
mmerge<-function(...)  #MMA
{
  Prices1= cbind(...)
  if (is.null(Prices1))
    browser(mP("bug in mmerge"))
  if (nrow(Prices1)<2)
    return (Prices1)
  
  prices1 = coredata(Prices1)
  prices1=apply(prices1, 2,m.ifna.prev)
  
  #prices1=apply(prices1, 2, ifna.prev.rev)  #wende die Funktion auf alle Spalten der Martrix an ..
  
  coredata(Prices1) <-prices1
  return (Prices1)
}
mmergeRev<-function(...)  #MMA
{
  Prices1= cbind(...)
  if (nrow(Prices1)<2)
    return (Prices1)
  
  prices1 = coredata(Prices1)
  prices1=apply(prices1, 2,m.ifna.prev)
  
  prices1=apply(prices1, 2, ifna.prev.rev)  #wende die Funktion auf alle Spalten der Martrix an ..
  
  coredata(Prices1) <-prices1
  return (Prices1)
}

####################
#zeigt unterschiedlich lange Zeitreihen an - ohne sie auf ein gemeinsames x-intervall zu begrenzen
####################
mPlotPureData<-function(...)  #MMA
{
  
  try(
{
  Prices1=mmerge(...)
  mPlot( Prices1,ylog_=F,main=main)
  
  nrow(Prices1)
  
}
  )
  
}

############### HighLight ist ein eindim-xts und wird orange gemalt
############### LockLight soll die gleiche Dimension wie Prices1 haben, 
purePlot<-function(...,main="",HighLight=NULL, LockLight = NULL, plotX=T,col="black",Signal=NULL)
{
  
  try(
{
  #browser(mP("purePlot"))
  Prices1=mmerge(...)
  title=sprintf("%s %s",main,fromTo(Prices1))
  Prices1[is.infinite(Prices1)]<-NA
  #x.highlight=get.Index(prices,as.Date(index(HighLight)))
  
  x.highlight= temp= which(!is.na(merge(HighLight,Prices1))[,1])
  
  ylim = range(Prices1,na.rm=T)
  
  
  if (main=="" || main=="no")
    plota(Prices1,type="n",plotX=plotX,ylim=range(Prices1,na.rm=T),x.highlight=x.highlight)
  else
    plota(Prices1,type="n",main=main,plotX=plotX,ylim=range(Prices1,na.rm=T),x.highlight=x.highlight)
  
  #pric#plota.grid()
  # browser()
  colSet = c(col,rainbow(ncol(Prices1)))
  #colSet = c("red", topo.colors(ncol(Prices1)))
  #colSet = c("red",palette(gray(seq(0,.9,len=ncol(ret)-1))))
  
  #plot((mat[,1,drop=F]), ylim =rang, main=title)
  
  if (T)
  {
    #axis(4)  
    for(ci in 1:ncol(Prices1))
      lines(Prices1[,ci,drop=F],col=colSet[ci],lwd=2)
  }
  plota.legend(colnames(Prices1),colSet[1:ncol(Prices1)],pch=10,cex=0.6)
  
  
  
  return(1)##########################################################
  
  
  #  for(k in c(1:dim(Prices1)[2]))
  #           plota.lines(Prices1[,k],col="red")
  
  #  return(1)
  # mPlot( Prices1,ylog_=F,main=main)
  #  browser()
  HighLight=HighLight[,1]
  if (!is.null(HighLight))
    rollapplyr(HighLight,width=1,FUN=function(HighLight)
    {
      problem.date = DateS(HighLight)
      amark(problem.date,col="darkgreen")    
      
    }) 
  
  nrow(Prices1)
  
} )
  
  #  )
}

if (F)
{
  HighLight=mNorm(prices[,1])[mNorm((prices[,1]))>1.5 & mNorm((prices[,1]))<2.5 ]
  fromTo(HighLight)
  purePlot( mNorm((prices)),plotX=T,main="test", HighLight=HighLight) 
}


############################### Teste das colle xtsExta
if(F)
{
  library(xtsExtra)
  #plot so nicht mehr funktionieren  .. siehe mchart .. purePlot aber wohl !!
  
  #  plot(dax,main="hallo") werden nicht mehr verbunden
  #  lines(dax,col="red")
  
  plot.xts(prices,
           screens=c(1,2,2), #plot 1st series in 1st panel and 2nd and 3rd series in 2nd panel
           layout.screens=c(1,1,2), #just as an example change the layout so 1st panel is 1/3 of area and 2nd is bottom 2/3
           blocks = list( #set up blocks for recessions
             start.time=as.Date(index(HighLight)),
             #langer ausruck, damit nicht dauernd l�cken in der einf�rbung sind wenn der folgetag ein wochenende ist
             end.time=as.Date(index(prices[get.Index(prices,as.Date(index(HighLight)))+1])),
             col = "lightblue"),
           lwd = 1,
           legend.loc = "topleft", auto.legend=TRUE,
           main=title)
  detach("package:xtsExtra")#  ... beisst sich leider mit xts - also wird mein oft benutzer
  
}


####backfill- umgekehrt
#entfernt die linken (fr�hen) NA- Werte durch den ersten non-NA-Wert
#gegenst�ck zum ifna.prev() des sysinvestors.
ifna.prev.rev<-function(p)     #MMA
{
  return( p[ifna.prevx.rev(p)])
}



findBestDrawDown<-function(prices=dax,t="",minReturn=0.3,ylim=c(0,100))  #MMA
{
  res = list()
  bestRet=list()
  bestVal = 0
  reg=0
  mRES=c()
  
  #Versuche die DrawDownWerte 1..30
  for(dd in seq(1:60))
  {
    reg=goodReturn(prices =prices, maxdd = dd, t = t, minReturn= minReturn,checkSGB =F, visual = F,ylim=ylim)
    reg= reg$Ertrag
    mRES= c(mRES,reg)
    Reg = c(dd,reg)
    if (bestVal==0||reg>bestVal ) 
    {bestRet = Reg
     bestVal= reg
    }
    res = list( Reg,res )
  }
  
  dd= bestRet[1]
  print(bestRet)
  reg=goodReturn(prices = prices, maxdd = dd, t = t, minReturn= minReturn ,checkSGB = T, visual = T)  
  
  cat("bestRet at maxdd ",bestRet,"\n ")
  
  norm_Win(2)
  plot(mRES     )
  plot(prices)
  
  return(bestRet[1])
  #res[[1]][2]
}



#################################################################################
#welcher Return kann von prices  ab zeit t via buy hold erreicht werden ehe ein
#maxdrawdown von  maxdd ausstoppt ?
#visual = T  ergbit 2 plots
#################################################################################
#t="2005"
#prices=dax

goodReturn1<-function(prices=edhec,t, maxdd=10, weights=NULL,geometric=TRUE, nStd=FALSE,minReturn=0, visual=T)
{
  killedPreSegment=F
  prices=prices[sprintf("%s::",t)]
  
  prices=mRendite(mROC(prices))
  lastOKSegmentES=0
  
  if (F)
    #automatische Ermitllung des besten Stop-Bereiches
    if (is.null(maxdd) || maxdd ==0)
    {
      bestdd = 5
      bestRet = -1
      for (dd in 5:30)
      {
        dd=8
        
        thisRet= buyTilBreakPerf(prices, dd)
        if (thisRet>bestRet)
        {
          bestRet=thisRet; bestdd = dd
        }
      }
      maxdd = bestdd
    }
  
  zz=ZigZag(prices,change=maxdd,percent =T)
  
  plot(prices)
  lines(zz,col="red")
  sig=as.vector(coredata(sign(zz-lag(zz))))  #segmente positiver und negativer steigung
  enc <-rle(sig)
  enc.endidx <- cumsum(enc$lengths)  #ending indices
  enc.startidx <- c(0, enc.endidx[1:(length(enc.endidx)-1)],length(prices))  # starting indices
  
  #markiere die higss- und lows- des zigzag in unterschiedlichen farben
  highx = na.omit(enc.endidx[enc$values > 0 ]) 
  
  lowx = na.omit(enc.endidx[enc$values < 0 ]) 
  lows = prices[lowx]
  
  if (first(lowx) < first(highx) )#|| first(prices)>prices[first(highx)])
  {
    highx = c(1,highx)
  }
  else
    lowx= c(1,lowx)
  #if (first(prices))
  len(highx)
  points(prices[highx],col="green")
  points(prices[lowx],col="blue")
  
  #browser()
  if (len(highx)<1)
    maxP = last(prices)
  else
    maxP = prices[first(highx)]
  
  alleSegmenteI =enc.endidx
  alleSegmenteI2 = alleSegmenteI
  #�ber alle Segmente des zigzack
  #berechne f�r jedes Segment die Streuung um die Regression-Line (mean-Reverter)
  lasti=1
  lastOKSegmentES=0
  segI=0
  for(i in alleSegmenteI) #�ber alle zz-Segmente
  {
    segI = segI+1
    if (i >first(alleSegmenteI))
    { 
      #browser()
      xxRet  =mROC(prices[lasti:i])
      xxPrices =prices[lasti:i,1]
      
      segx1 = lasti;
      segx2 = i
      
      if (visual)
        lines(xxPrices, col="yellow") #segmentabschnitt in gelb
      
      
      if (T)
      {
        reg=lm(xxPrices~c(lasti:i))    
        regfitted.values=reg$fitted.values
      }
      else#dynamisierte Version der Regression 
      {
        if(i-lasti > 10 )#&& i +10< len(prices))
        {
          regfitted.values = prices[c(lasti:(lasti+10-1))]
          for(i5 in seq(lasti+10:i))
          {
            x5= c(lasti:i5)
            if (len(x5)> 10)
            {
              y5 = prices[x5,1]
              reg5=lm(y5~x5)
              
              regfitted.values = append(regfitted.values,last(reg5$fitted.values))
            }            
            #
            if (F) #TEST breakpoint
              if (as.Date(time(prices[i5]))> as.Date("2009-03-01"))
              {
                lines(regfitted.values, col="blue")
                lines(reg5$fitted.values,col="green")
                #browser()
              }            
          }
        }
        else
          regfitted.values = prices[c(lasti:i)]
        
        
      }
      if (visual)
        lines(regfitted.values, col="green")
      
      ddd = (max(xxPrices)-min(xxPrices))/2
      if (visual)
        lines(xxPrices-regfitted.values+max(xxPrices)-ddd,col="blue")
      
      
      xNorm=xxPrices-regfitted.values 
      
      #browser()
      
      #die S�gezahnbreite
      
      es = ES(p=0.99,xNorm,method = "historical")
      
      
      #min(xNorm)<es
      segmentReturn=mROC(append(prices[segx1],prices[segx2]))
      isTrendSegmentOK = abs(segmentReturn) > lastOKSegmentES  && abs(segmentReturn)> minReturn
      
      if( (lastOKSegmentES == 0 || isTrendSegmentOK))
      {
        lastOKSegmentES=abs(es)
        killedPreSegment = F  
      }
      else #l�sche das unrentable Segment 
      { 
        #die letzten zwei Knoten entfernen - durch setzen von killedPreSegment
        if (visual)
        {
          cat("\n",segI,":kill node ",alleSegmenteI2[segI],"\n segmentReturn is only ",segmentReturn,"\n")
          cat(alleSegmenteI2)
          cat("\nat\n")
          cat(segI,":   ",segx1,segx2,"\n")
        } 
        alleSegmenteI2 = alleSegmenteI2[-c(segI,segI-1)]
        segI = max(1,segI-2)
        lastI = alleSegmenteI[segI]
        segx1= lastI
        newZ=prices[c(segx1,segx2)]
        lines(newZ,col="blue")
        cat("\nnew\n",alleSegmenteI2)
        #browser()
        
      }
      
      if (visual)
      { cat(isTrendSegmentOK)
        cat(" ")    
      }
      
      #browser()
      
      
      
      lasti=i  #n�chstes Segment
    }
  }
  
  cat("--------------------->")
  ret= (as.numeric(maxP)-as.numeric(prices[1,1]))/as.numeric(prices[1,1])*100
  rR=prices[1:highx[2]]
  cat("Ret ",ret)
  #browser()
  
  newZZ=prices[alleSegmenteI2]
  
  lines(newZZ,col="brown",lw=2)
  
  #if (visual) lines(rR,col="blue",type="h")
  return (ret)
  ##################################################
  
  
  
  
  
  
  
  Rorg = mROC(prices)
  R=Rorg
  
  if (visual)
  {
    
    par(mfrow=c(2,1))
    DJ.roc <- R#ROC(prices,n=1,type="discrete")
    DJ.draw = Drawdowns(DJ.roc)
    sort(coredata(- DJ.draw),decreasing = T)
    
    #jpeg(filename="DJ plot with Drawdowns zoo.jpg",
    #  quality=100,width=6.25, height = 6.25,  units="in",res=96)
    plot.zoo(mRendite(R),plot.type="single",
             col=c(2,3,4),ylab="log Price",xlab=NA,main="Dow Jones Indexes")
    
    lines(zz,col="green",lwd=2)
    
    rgb <- hcl(c(0, 0, 260), c = c(100, 0, 100), l = c(50, 90, 50), alpha = 0.3)
    xblocks(index(DJ.roc),as.vector(DJ.draw[,1] < -maxdd/100),col = rgb[1])
    
    xblocks(index(DJ.roc),as.vector(DJ.draw[,1] < -0.20),col = rgb[1])
    #  legend("topleft",inset=0.05,colnames(prices),fill=c(2,3,4),bg="white")
    
    plot(mRendite(R),main=sprintf("goodReturn %s %s %f", colnames(prices)[1],t,maxdd))
    
    
  }
  
  t2 =time(last(R))
  dd =findDrawdowns(ret[,drop=FALSE])
  len(dd$trough)
  len(dd$return)
  
  dds= as.xts( -dd$return*100,order.by=as.Date(time(R[dd$trough,1])))
  
  #table.Drawdowns(R, top = 10, digits = 9)
  #maxdd=80
  ddx = which(dds > maxdd)
  di=dd$trough[ dds > maxdd]
  
  
  if (length(di)>0) #ausgestoppt
  {
    di = first(di)
    t2 = time(R[di])
    R=R[sprintf("::%s",t2)]    
  }
  
  rR=mRendite(R)
  if (visual) lines(rR,col="blue",type="h")
  
  x=rR[rR==max(rR)]
  wo = time(x)
  if (visual) lines(rR[sprintf("%s::",wo)],col="red") 
  gRend= mRendite(Rorg[sprintf("%s/%s",t,time(x))])
  
  
  if (visual)  cat("maxDrawdown ",maxDrawdown(gRend)*100  ,"\n")
  #  findDrawdowns(gRend)
  lines(gRend,col="green")
  guv = as.numeric(last(gRend))-as.numeric(first(gRend))
  return(guv)
}



#################################################################################
#scaliere eine Zeitreihe auf einen gegeben rangen (vector aus zwei werten - min,max)
#################################################################################
scaleTo<-function(close, rang,srange=NULL)
{
  #head(close)
  close=na.omit(close)
  toMin=min(rang)
  toMax=max(rang)
  mi=min(close)
  ma=max(close)
  
  
  if (is.null(srange))
  {
    fac=(toMax-toMin) / (ma-mi)
    ret=close*fac#-mi*fac
    ret= ret-min(ret)+toMin
  }
  else
  {
    miS=srange[1]
    maS=srange[2]
    corfac = (ma-mi) /  (maS-miS)
    #  browser()
    #corfac=1
    #  fac=(toMax-toMin) / (ma-mi) * corfac
    #  print("scale")
    #  browser()
    #browser()
    #  fac1=(toMax-toMin) / (ma-mi)
    #  ret=close*fac1
    #  ret= ret-min(ret)+toMin
    
    
    fac=(toMax-toMin) / (maS-miS) 
    
    ret=close*fac
    ret= ret-min(ret)+toMin
    
    head(ret)
    range(close)  
  }
  
  
  return(ret)
}

#################################################################################
#################################################################################

#####################################################
#listet alle in einem r-file definieren funktionen
######################################################
list_R_functions<-function(file="portfolioCode.r")
{
  
  ret=c(mP("###list_R_functions: #################### %s ################>",file))
  data=new.env()
  source(local=data, file=file)
  
  print(ls.str(mode = "function",envi=data))
  funcs= c(lsf.str(envi=data))
  
  #browser()
  #function(funx) sprintf("%s(%s)",funx,toString(attributes(formals(funx))$names))
  
  funcArgs = sapply (funcs,FUN=function(funx) {sprintf("%s(%s)",funx,toString(attributes(formals(funx))$names))},simplify = TRUE)
  
  ret=as.data.frame(rbind(c("######################","####################################"),cbind(file,funcArgs)))
  #print(ret)  
  mP("##############################################################")
View(ret)  
  return(ret)
  
}


list_R_functions_At_Dir<-function(
  dataPath="SysInvestor/SIT-master/R",
  dirName = "SysInvestor")
{
  A<-NULL#data.frame(spl("rFile,Args"))
  for (rfile in 
       dir(path = dataPath, pattern = glob2rx("*.r"), all.files = T,
           full.names = F, recursive = F,
           ignore.case = FALSE, include.dirs = FALSE)
  )
  {   
    
    fname=sprintf("%s/%s",dataPath,rfile)
    
    mP(fname)
    a1=list_R_functions(file=fname)
    
    if (is.null(A))
      A<-a1
    else
      A <- rbind(A,a1)
    
  }
  #browser()
  write.table(A,file=sprintf("%s.csv",dirName),sep=";",col.names=c("Funcs","rFile;Args"),quote=FALSE, row.names=FALSE)
  
  print(sprintf("%s.csv",dirName))
}

if(F)
{
  sapply(parse("InputConfig_Portfolio_TD.R"),FUN=function(x){  str_extract(toString(x),glob2rx("*.function"))})
  
  
  a1=list_R_functions(file="InputConfig_Portfolio_TD.R")
  write.table(a1,file="Funcs.csv",sep=";",col.names=c("rFile","Args"),quote=FALSE)
  
  
  list_R_functions_At_Dir("SysInvestor/SIT-master/R","Info/SysInvestorALL")  #MMA
}


## 1) with traditional 'graphics' package:
showCols1 <- function(bg = "gray", cex = 0.75, srt = 30) {
  m <- ceiling(sqrt(n <- length(cl <- colors())))
  length(cl) <- m*m; cm <- matrix(cl, m)
  ##
  require("graphics")
  op <- par(mar=rep(0,4), ann=FALSE, bg = bg); on.exit(par(op))
  plot(1:m,1:m, type="n", axes=FALSE)
  text(col(cm), rev(row(cm)), cm,  col = cl, cex=cex, srt=srt)
}
#showCols1()

## 2) with 'grid' package:
showCols2 <- function(bg = "grey", cex = 0.75, rot = 30) {
  m <- ceiling(sqrt(n <- length(cl <- colors())))
  length(cl) <- m*m; cm <- matrix(cl, m)
  ##
  require("grid")
  grid.newpage(); vp <- viewport(w = .92, h = .92)
  grid.rect(gp=gpar(fill=bg))
  grid.text(cm, x = col(cm)/m, y = rev(row(cm))/m, rot = rot,
            vp=vp, gp=gpar(cex = cex, col = cm))
}
#showCols2()

###########################################
#siehe
#MM!  xtsExtraTest
#http://www.r-bloggers.com/plot-xts-is-wonderful/
###########################################

XtsGuvPlot<-function(data.to.plot = NULL,main="Performance Summary")
{
  
  #for a little more advanced application we can start to do charts.PerformanceSummary style plot.xts 
  cumulreturn.panel  <- function(...) {
    mtext("Cumulative Return", side=1, adj=1, line=-3)
    default.panel(...)
    abline(h=pretty(c(par("yaxp")[1],par("yaxp")[2]),n=par("yaxp")[3]),col="gray60",lty=3)
    abline(h=0, col="black")
  }
  
  es.panel <- function(index,x,...) {
    mtext("Expected Shortfall", side=1, adj=1, line=-3) 
    default.panel(index,x,...)
    #silly to do this but if we wanted just certain points like every 4 months we could do something like this
    #default.panel(index[seq(1,NROW(index),by=4)],coredata(x[seq(1,NROW(index),by=4)]),...)
    #abline(h=0, col="black")
    abline(h=pretty(c(par("yaxp")[1],par("yaxp")[2]),n=par("yaxp")[3]),col="gray60",lty=3)
    abline(h=par("yaxp")[1], col="black")
  }
  
  drawdown.panel <-  function(index,x,...) {  
    mtext("Drawdown", side=1, adj=1, line=-2) 
    default.panel(index,x,...)
    #silly to do this but if we wanted just certain points like every 4 months we could do something like this
    #default.panel(index[seq(1,NROW(index),by=4)],coredata(x[seq(1,NROW(index),by=4)]),...)
    #abline(h=0, col="black")
    abline(h=pretty(c(par("yaxp")[1],par("yaxp")[2]),n=par("yaxp")[3]),col="gray60",lty=3)
    abline(h=par("usr")[3], col="black")
  }
  
  #get some risk measurements to add for Performance Summary style plot
  Risk.drawdown <- Drawdowns(R)
  
  Risk.es <- rollapplyr(R,FUN="ES",width=36,p=0.95,na.pad=TRUE)
  #take care of NA with 0 at beginning and interpolation at end
  Risk.es <- apply(Risk.es,MARGIN=2,FUN=na.fill,fill=c(0,"extend"))
  #something wrong with returned value from apply.rolling so indexes don't work properly
  data.to.plot <- as.xts(cbind(coredata(Return.cumulative),Risk.es,coredata(Risk.drawdown)),order.by=index(edhec))
  
  #png("chartsPerformanceSummary.png",width=640,height=600,units="px")
  plot.xts(data.to.plot,
           lwd = c(2,1,1), #do this to show how arguments are recycled
           col = brewer.pal(n=9,"PuBu")[c(8,4,6)],
           auto.grid = FALSE, #usually auto.grid works just fine but turn off for example purposes
           las = 1,yax.loc = "right",  # yax.loc could also be flip or left in this case
           screens = c(1,1,1,2,2,2,3,3,3),  #3 series for each so first 3 in panel 1 second 3 in panel 2 and last 3 in panel 3
           layout.screens = c(1,1,2,3), #panel 1 take up first 2 of 4 so 50% and panels 2 and 3 each 25%
           bty = "n", 
           panel = c(cumulreturn.panel,es.panel,drawdown.panel), #c(first.panel,"auto"), #panel cycles through by panel rather than each series
           ylab = NA, major.format = "%b %Y", minor.ticks = FALSE,
           legend.loc = c("topleft",NA,NA), auto.legend = TRUE,
           legend.pars = list(bty = "n", horiz=TRUE),  #make legend box transparent
           cex.axis = 0.9, 
           main = NA)
  
  title(main = "Performance Summary of EDHEC Indexes", adj = 0, outer = TRUE, line = -1.5)
  
}


assert <- function (condition, ...) { #MMA
  mc <- match.call()
  if (!is.logical(eval(condition)) || ! all(condition)) {
    cat("Assertion failled:", 
        deparse(mc[[2]]), "is not TRUE\n")
    ll <- list(...)
    for (i in seq(along=ll)) {
      cat("  ", deparse(mc[[i+2]]), ": ", ll[[i]], "\n", sep="")
    }
    ca <- sys.calls()
    cat(paste(length(ca):1, ": ", rev(ca), sep="", collapse="\n"), "\n")
    cat("BROWSER (type 'c' to quit):\n")
    browser()
    stop(paste(deparse(mc[[2]]), "is not TRUE"), call.=FALSE)
  }
}
#
#list_R_functions("InputConfig_Portfolio_TD.R")
#listTicks()

###################################


#x="hallo <meta name=\"keywords\" content=\"db x-tr.SMI ETF Inhaber-Anteile 1D (WKN DBX1SM, ISIN LU0274221281), Fonds\">"

#Extrahiert aus einem String x (der l�nge  nchar(x)  den Teil der  zwischen word1 und word2 steht)
#Vorsicht bei Sonderzeichen wie (,/ oder ... )

StrBetween<-function(x,word1,word2) #MMA
{
  rest = ifelse(word2=="","",sprintf("%s",word2))
  pat=sprintf("%s(.*?)%s",word1,rest)
  if (word2=="") #leftOf
    pat=sprintf("%s(.*)",word1)
  if (word1 =="") #rightOf
    pat=sprintf("(.*)%s",word2)
  #  print (pat)
  res = ""
  m=first(regexec(pat,x))
  M=regmatches(x, m)
  #browser()
  res = trim(unlist(M)[2])
  print("###")
  print(res)
  return(res)
}

if (F)  #Tests zu StrBetween  #MMA
{
  x="sadfasfasf<meta name=\"keywords\" content=\"db x-tr.SMI ETF Inhaber-Anteile 1D (WKN DBX1SM, ISIN LU0274221281), Fonds\"> </head> <body >"
  
  res=StrBetween(x,"<meta name=\\\"keywords\\\" content=\\\"","\\\">")  
  res=StrBetween(x,"<meta name=\\\"keywords\\\" content=\\\"","")  
  res=StrBetween(x,"","\\\">") 
  
}


leftOf<-function(x,what)
{
  res=StrBetween(x,"",what)
  return (res)
}


rightOf<-function(x,what)
{
  res=StrBetween(x,what,"")
  return (res)
}

ZahlBetween<-function(x,word1,word2)
{
  return(as.numeric ( StrBetween(x,word1,word2)))
  
  
  library("stringr")
  pat="chart.m\\?secu=(\\d+)&amp"
  rest = ifelse(word2=="","",sprintf("%s",word2))
  pat=sprintf("%s.*%s",word1,rest)
  pat=sprintf("%s(\\d+)%s",word1,rest)
  x2= str_extract(x,pat)
  pat="(\\d+)"
  x3 = str_extract(x,pat)
  print(x3)
  return(x3)
  
}

if (F)
  prettyWpName("^'/R'B^S_Market&amp;_Access_FTSE.\tJSE_Afr  ica_;Top,_40_ETF'")


##################################
#versucht aus nem string einen wp-tauglichen namen zu machen, der auch
#als filename f�r csv-files taugt.
##normalisier ihn indem du . und blank durch "_" ersetzt
##################################
prettyWpName <- function (wpName0) 
{
  
  if (is.na(wpName0) || is.null(wpName0) )
    return (" ")
  
  if (nchar(wpName0)>250) 
    wpName0 =substr(wpName0,1,250)
  wpName0 = trim(wpName0)
  if   (substr(wpName0,1,1)=="^") 
    wpName0 <- sub( "^", "",wpName0,fixed=TRUE)
  if   (substr(wpName0,1,1)==".")  #leading . entfernen
  {
    wpName0 <- substr(wpName0,2,250)
    
  }
  wpName=wpName0
  
  wpName <- gsub("&amp;", "u",wpName0,fixed=TRUE)
  wpName <- gsub( "Kurs", "",wpName,fixed=TRUE)
  wpName <- gsub( "Chart", "",wpName,fixed=TRUE)
  wpName <- gsub( "Nachrichten", "",wpName,fixed=TRUE)
  
  wpName <- gsub( "#", "",wpName,fixed=TRUE)
  wpName <- gsub( ".", "_",wpName,fixed=TRUE)
  wpName <- gsub( ";", "_",wpName,fixed=TRUE)
  wpName <- gsub( ",", "_",wpName,fixed=TRUE)
  wpName <- gsub( "'", "",wpName,fixed=TRUE)
  wpName <- gsub( " ", "_",wpName,fixed=TRUE)
  wpName <- gsub( "___", "_",wpName,fixed=TRUE)
  wpName <- gsub( "__", "_",wpName,fixed=TRUE)
  wpName <- gsub( "\\", "_",wpName,fixed=TRUE)
  wpName <- gsub( "/", "_",wpName,fixed=TRUE)
  wpName <- gsub( "<", "",wpName,fixed=TRUE)
  wpName <- gsub( ">", "",wpName,fixed=TRUE)
  wpName <- gsub( "?", "",wpName,fixed=TRUE)
  wpName <- gsub( "\t", "",wpName,fixed=TRUE)
  wpName <- gsub( "\r", "",wpName,fixed=TRUE)
  wpName <- gsub( "\n", "",wpName,fixed=TRUE)
  wpName <- gsub( "  ", "_",wpName,fixed=TRUE)
  wpName <- gsub( "   ", "_",wpName,fixed=TRUE)
  wpName <- gsub( "&", "u",wpName,fixed=TRUE)
  wpName <- trim(wpName)
  
  return(wpName)
}

######################################################################################

#norm_Win(4)
#longIndikator1= longIndikator[HighLows(longIndikator,maxdd=20,visual=T)$lows]
#longIndikator2= longIndikator1[HighLows(longIndikator1,maxdd=20,visual=T)$lows]
#longIndikator3= longIndikator2[HighLows(longIndikator2,maxdd=20,visual=T)$lows]

#mPlot(scaleTo(longIndikator,c(1,0)))
#####################################################################################



HighLows <-function(prices, maxdd=5,visual = F)  #MMA
{
  prices=scaleTo(na.omit(prices[,1]),c(1,0)) #ohne Skalierung auf positive Werte klappt das alles nicht so gut
  
  if (maxdd==0)
    zz=prices
  else
    zz=na.omit(ZigZag(na.omit(prices),change=maxdd,percent=F))
  if (index(last(zz)) < index(last(prices))) #letzten Punkt noch anh�ngen
    zz = append(zz,last(prices))
  browser()
  plot(zz)
  if (F)
  {
    #zz=prices
    #es liegt ein offset zwischen  zz und prices !!!!!!
    #wie viele leading NA gibts in zz ??
    #browser()
    block=merge(zz,prices,all=T)[,1]
    nac=as.vector(iif(is.na(block),1,NA))
    enc <-rle(nac)
    offset = enc$lengths[1]
  }
  
  if ( visual)
  {
    plot(prices)
    lines(zz,col="red")
    # browser()  
  }
  
  f=""
  sd = sign(diff(zz))[f]
  rS=runSum(sd,2)
  rS=lag(rS,-1)
  
  peaks <- prices[ as.Date(index(rS[rS==0]))]
  highx = peaks[peaks > lag(peaks,-1)]
  lowx = peaks[peaks < lag(peaks,1)]
  
  if (visual)
  {
    plot(prices[f])
    points(peaks[f])
    lines(zz[f],col="red")
    points(highx,col="blue",lwd=3)
    points(lowx,col="red",lwd=3)
  }
  
  highx=as.Date(index(highx))
  lowx=as.Date(index(lowx))
  peaks=as.Date(index(peaks))
  return(list(highs = highx,lows = lowx,hl=peaks ))
  
  ##############################################################################################
  
  peaks <- findpeaks(as.vector(zz))  
  #price, x-lage des peaks,
  Peaks <-merge(zz, zz[peaks[,2]],zz[peaks[,3]],zz[peaks[,4]]) 
  
  browser(mP("HL"))
  highx = peaks[,2]; Highs=zz[peaks[,2]]
  lowx = na.omit(iif(!is.na(peaks[,3]),peaks[,3], peaks[,4]))
  
  Lows=na.omit(iif(!is.na(Peaks[,3]),Peaks[,3], Peaks[,4]))
  
  #lines(Highs,type="p")
  zzPoints=na.omit(iif(!is.na(Peaks[,2]),Peaks[,2], Peaks[,3]))
  if (index(last(zzPoints)) < index(last(prices))) #letzten Punkt noch anh�ngen
    zzPoints = append(zzPoints,last(prices))
  if (index(first(zzPoints)) > index(first(prices))) #letzten Punkt noch anh�ngen
    zzPoints = append(first(prices),zzPoints)
  
  
  #points(zzPoints,col="green",lwd=2)
  if (visual)
  {
    frame="2009"
    frame=""
    if (F)
    {
      
      plot(prices[frame],type="h")
      
      lines(zzPoints[frame],type="l",col="green",lwd=2)
      
      
      #lines(zz,col="red")
      points(Highs[frame],col="magenta",lwd=1)
      points(Lows[frame],col="blue",lwd=1)
      
      #browser()
    }
    new_Win(2)
    par(mfrow=c(2,1))
    plot(prices[frame],type="l")
    lines(zz[frame],type="l",col="green")    
    points(prices[highx+offset,],col="red")  #bug
    points(prices[lowx+offset,],col="blue") 
    
    head(zz)
    head((diff(zz)))
    #mittlere wegstrecke == kanalbreite
    purePlot(merge(scaleTo(SMA(abs(diff(zz)),40),c(0,1)))[frame],prices[frame])
    browser()
  }
  #markiere die higss- und lows- des zigzag in unterschiedlichen farben
  highx = highx+offset    #es liegt ein offset zwischen  zz und prices !
  lowx = lowx+offset
  hl=sort(append(lowx,highx))  
  
  return(list(highs = highx,lows = lowx,hl=hl ))  
}

########################################################################################


####################################################
#jedes �bergebene xts wird in einem eigenen Fenster - die gestapelt sind-
#mit eigener y-Achse gedruckt

#mPlots(hsm,cl,frame="2008::",titel= "Ernte")

#####################################################

mPlots<-function(...,title="",frame="")   #MMA  wie xyplots  nur netter, siehe xyplot(mmerge(hsm,cl),grid=T, main="mist")
{
  #browser()
  #args=list(mmerge(...))
  args =list(...)
  #args=mmerge(args)
  if (len(args)==1)
  {
    p = args[[1]]
    
    Args= list()
    for(c in colnames(p))
    {
      Args = append(Args,list(p[,c]))
      
    }
    
  }
  else
    Args=args
  
  args = Args
  norm_Win(len(args))
  
  first_ = args[[1]]
  last_ =  args[[len(args)]]
  last_ = last_[frame]
  
  #browser()
  args = args[-len(args)]
  
  first=T
  title_=""
  
  for(x in args)
  {
    x=na.omit(x[frame])
    if (first)
      if (title != "")
        title_ = title
    else
      title_ =  deparse(substitute(...))
    if (first)
      plota(merge(x,first_)[,1],ylim=range(na.omit(x)),main=title_,plotX=F,LeftMargin=1) 
    else
      plota(merge(x,first_)[,1],ylim=range(na.omit(x)),plotX=F,LeftMargin=1) 
    
    for(ci in  1:ncol(x))
      plota.lines(x[,ci],col=ci)
    
    #lines(x)
    first =F
    
  }    
  plota(merge(last_,first_)[,1],ylim=range(na.omit(last_)),LeftMargin=1)
  for(ci in  1:ncol(last_))
    plota.lines(last_[,ci],col=ci)
  
}
mPlotS<-function(...,title="",frame="")   #MMA  wie xyplots  nur netter, siehe xyplot(mmerge(hsm,cl),grid=T, main="mist")
{
  args=list(...)
  #args=mmerge(args)
  if (len(args)==1)
  {
    p = args[[1]]
    
    Args= list()
    for(c in colnames(p))
    {
      Args = append(Args,list(p[,c]))
      
    }
    
  }
  
  args = Args
  #norm_Win(len(args))
  
  
  last_ =  args[[len(args)]]
  last_ = last_[frame]
  
  #browser()
  args = args[-len(args)]
  
  first=T
  title_=""
  
  for(x in args)
  {
    x=na.omit(x[frame])
    if (first)
      if (title != "")
        title_ = title
    else
      title_ =  deparse(substitute(...))
    
    if (first)
      plota(x,ylim=range(x,na.rm=T),main=title_,plotX=T,LeftMargin=1) 
    #else
    #  plota(x,ylim=range(x),plotX=F,LeftMargin=1) 
    
    lines(x)
    first =F
    
  }    
  #plota(last_,ylim=range(last_),LeftMargin=1)
  plota.lines(last_,col="black")
  
}

#seq(5,3)
####################################################
####RunLengthEnc
#es kommt ein vektor rein (z.B. mit 0 und eins - Trains - aus HighLows())
#Heraus kommt ein Vektor der die Train-L�ngen gez�hlt hat und im S1 die 
#Trainl�nge jeweils in den Train schreibt.
#####################################################
runLengthEnc<-function(s1)   #MMA
{
  #s1=ifelse(sign(highs-lag(highs,1))<0,0,1)
  sig=as.vector(s1)  #segmente positiver und negativer steigung
  enc <-rle(sig)
  enc.endidx <- cumsum(enc$lengths)  #ending indices
  S1 = s1
  #trage die  runl�ngen in S1 
  for(i in seq(1, len(enc.endidx)))
    for(j in seq(1, enc$lengths[i]))  ### jedes bit des trains durch die trainl�nge ersetzen 
      S1[enc.endidx[i]+j-1,] = enc$lengths[i] -j+1   #MM_TODO  runLengthEnc - testen und aufpassen dass man keine Info's an die Zukunft weiterreicht ... :-)
  
  return(S1)
}



runLengthEnc2<-function(s1)   #MMA
{
  #s1=ifelse(sign(highs-lag(highs,1))<0,0,1)
  sig=as.vector(s1)  #segmente positiver und negativer steigung
  enc <-rle(sig)
  enc.endidx <- cumsum(enc$lengths)  #ending indices
  enc.startidx <- c(0, enc.endidx[1:(length(enc.endidx)-1)],length(s1))  # starting indices
  
  S1 = s1
  S1[]=0
  x=1
  #browser()
  #trage die  runl�ngen in S1 
  for(i in seq(1, length(enc$lengths)))
  {
    lenk=1
    for(j in seq(1, enc$lengths[i]))  ### jedes bit des trains durch die trainl�nge ersetzen 
    {
      #    browser()
      S1[x]=lenk*sign(s1[x])
      lenk=lenk+1
      x=x+1 
    }
  }
  return(S1)
}

# 252 - days, 52 - weeks, 26 - biweeks, 12-months, 6,4,3,2,1
#rasterOn(151)

######################################################################
#nimmt sich den zu der liste der erlaubten werte am besten passenden zu x
######################################################################
rasterOn = function(x,possible.values = c(252,52,26,13,12,6,4,3,2,1)) 
{
  index = which.min(abs( x - possible.values ))
  round( possible.values[index] )
}


####################################################
####gegen Ausreisser, outlier  #MMA
## nimm lieber  Return.clean(ret)  aus der PerformanceAnalytics-lib

#PeformanceAnalytics:
#   clean.boudt(R, alpha = 0.01, trim = 0.001)
#http://finzi.psych.upenn.edu/R/library/timeSeries/html/base-subset.html
#geht auch mit timeSeries


#http://braverock.com/brian/R/PerformanceAnalytics/html/Return.clean.html
#Kalman:  tsSmooth(),
#https://r-forge.r-project.org/scm/viewvc.php/*checkout*/pkg/pracma/R/.Rapp.history?revision=5&root=optimist&pathrev=11

if (F)
{
  #ungfiltert
  ret = mROC(prices)
  purePlot(mRendite(ret))
  #ausrei�er bereinigung
  ret = Return.clean(ret, method = c("none", "boudt", "geltner")[2])
  price = mRendite(ret)
  purePlot(price)
  
  
  
  
}

#####################################################

#http://www.r-bloggers.com/moving-window-filters-and-the-pracma-package/
#http://www.r-bloggers.com/finding-outliers-in-numerical-data/
# ExploringData package is FindOutliers, described in this post.  


HampelFilter <- function (x, k,t0=3){ #MMX
  n <- length(x)
  y <- x
  ind <- c()
  L <- 1.4826
  for (i in (k + 1):(n - k)) {
    x0 <- median(x[(i - k):(i + k)])
    S0 <- L * median(abs(x[(i - k):(i + k)] - x0))
    if (abs(x[i] - x0) > t0 * S0) {
      y[i] <- x0
      ind <- c(ind, i)
    }
  }
  list(y = y, ind = ind)
}

##################################

###################################################################
# �hnlich wie bt.apply.matrix() wird  die Funktion f auf alle Spalten
#der Matrix angewandt.  Sie gibt aber in der Regel eine ganze Liste
#von Ergebnissen wieder- Das Ergebnis  slot wird ausgew�hlt und in die
#Ergebnis xts-matrix gebaut.
###################################################################

mt.apply.matrix_<-function(prices,f,slot="",...)
{
  Prices = NULL  
  fun=match.fun(f)
  for(col in colnames(prices))
  {
    x=fun(prices[,col,drop=FALSE],...)
    
    if (slot!="")
      x=x[[slot]]
    if (is.null(Prices))
      Prices=x
    else
      Prices =cbind(Prices,x)
  }
  colnames(Prices) = colnames(prices)
  return (Prices)
}

mt.apply.matrix<-cmpfun(mt.apply.matrix_) #compilier die Funktion


##########################################################
#m.Run() ein super leichtes PM-System: ret=  prices*Signal f�r viele #MMA
#Aktienin den Prices+Signal-Spalten gleichzeitig
##########################################################
m.Run_<-function(prices,signal) 
{
  signal=lag(signal)   #!!!!
  Prices = NULL 
  prices = mROC(prices)
  colnames(signal)=colnames(prices)
  #fun=match.fun(f)
  
  for(col in colnames(prices))
  {
    x=prices[,col,drop=FALSE] * signal[,col,drop=FALSE]
    if (is.null(Prices))
      Prices=x
    else
      Prices =cbind(Prices,x)
  }
  colnames(Prices) = colnames(prices)
  return (Prices)
}

m.Run<-cmpfun(m.Run_) #compilier die Funktion


##########################################################
# l�sche xts Spalten die leer sind
##########################################################
m.clean0_BAD<-function(prices)
{
  #fun=match.fun(f)
  #browser()
  Prices = prices
  Prices[] = bt.apply.matrix(coredata(prices), m.ifna.prev)  
  ci=0
  del = c()
  for(col in colnames(prices))
  {
    ci=ci+1
    x=prices[,col,drop=FALSE] 
    
    x[!is.finite(x)]<-0 #ersetze na durch 0
    
    if (nrow(x) == nrow(x[x==0])) #alles 0  
      del=c(del,ci)
  }
  print("m.clean0 del")
  
  if (is.null(del) || len(del)<1)
    return (Prices)
  
  return (Prices[,- (del)])
}



m.clean0<-function(series) #MMMM1
{
  #mP("m.clean0")
  #browser()
  res1=NULL
  for(sym in c(1:len(colnames(series))))
  {
    #browser()
    head(col)
    col=series[,sym];  col = col[!is.na(col)]
    #browser()
    if (len(col) >0)
    {
      goodcol=m.ifna.prev(series[,sym])
      if (is.null(res1))
        res1= goodcol
      else
        res1=cbind(res1,goodcol)
    }
  }
  #browser()
  return(res1)
}
######################################################################
######################################################################

## wie mP .. aber mit einem verpflichtenden Tastendruck
userStop<-function(sag = "", ...,pos="")
{
  cat("\n")
  mP(sag,...)
  cat("\n")
  #browser()
  if ( globalCAT == ""  ||  globalCAT ==pos)
  {
    mP("userStop %s: ####  press Return ####",pos)
    browser()
    #readline()
  }
  else 
    mP("userStop %s: ############# ",pos)
}
#userStop("%s alter","hallo",pos="alloc1")
######################################################################
### sehr einfache Qualit�tsmessung des ret .. hier auf SharpeRatio
## gemeinsam gemessen �ber alle aktien (rowSums)
quality_<-function(ret,visual =F)
{
  
  if (visual)
  {
    print(KellyRatio(ret))
    print(table.AnnualizedReturns(ret))
    print(maxDrawdown(ret))
  }
  
  Tkosten =0.0008
  nt=as.numeric(numTrades(sign(ret))$allT) 
  Tkosten =Tkosten*nt
  # ich geh von einer slippage von einem Tag aus.
  # punkt genau wird man die Trendwechsel nie erwischen
  if (F) #with slippage ?
  {
    slipF = merge(ret,lag(ret,1 ))
    slipRet=slipF[as.Date(index(ret)),2]
    ret = ROC(slipRet,type="discrete")
  }
  #q=table.AnnualizedReturns(ret)[3,]
  
  #if (ncol(ret) > 1)
  #  q = rowSums(table.AnnualizedReturns(ret)[3,])
  # bt.ret = ROC(ret, type='discrete')
  bt.ret = ret
  bt.ret[1] = 0.000001
  bt.ret[!is.finite(bt.ret)]=0
  
  equity = cumprod(1 + bt.ret)
  
  q = last(equity)#/abs(compute.max.drawdown(ret))
  #  q=compute.sharpe(bt.ret)
  #q=compute.cagr(res) / abs(compute.max.drawdown(res))
  #q =q*100-nt*Tkosten
  
  # q=compute.sharpe(Ret)
  
  #compute.sharpe(mROC(prices))/compute.sharpe(ret)
  
  q=(q-Tkosten) #/ maxDrawdown(bt.ret)
  return (as.numeric(q))
}
quality<-cmpfun(quality_) #compilier das Teil


##########################################################################
# x ist ein DATUM-String,  Dax ist lange xts in der x steckt,
# xts2Index gibt dann die Zahl (1.. len(Dax)) der Position von x zur�ck
##########################################################################

xts2Index<-function(x,Dax)  #MMA
{
  #browser()
  x=as.Date(x)
  i1=which(index(Dax)==index(Dax[x]))
  if(len(i1) ==0)return(0)
  return(i1)
}
##########################################################################
## gib das Datum, dass um xshift zu x1 verschoben ist - im Dax.
## (das ist was anderes als x1+xshift - jedenfalls wenn der Dax L�cken hat)
##########################################################################
xtsAddDate<-function(x,Dax,xshift)
{
  i1=which(index(Dax)==index(Dax[x]))
  i2 = pmax(1,pmin(i1+xshift,len(Dax)))
  if (len(i1)==0|| len(i2)==0)return(0)
  return(i2)
}

##########################################################################
# ist die Spalte colnames des Xts  leer ?
##########################################################################

isEmptyCol<-function (Xts,colname)
{
  Col= Xts[,colname]
  Col = Col[!is.na(Col)]
  if (len(Col) ==0) return(TRUE)
  e1 = (0==len(  Col[is.finite(Col)] ))
  e2 =last(cumsum(nchar(Col))==0)
  return (e1&&e2)
}
############################################################################


#########################################################################
# eine try - Variante die sich wie try bedient und auch durchl�uft - aber
#fehler und Warnungen wenigstens anzeigt
#########################################################################

tryM<- function(expr)  #MMA
{
  W <- NULL
  w.handler <- function(w){ # warning handler
    W <<- w
    invokeRestart("muffleWarning")
  }
  res=  list(value = withCallingHandlers(tryCatch(expr, error = function(e) e),
                                         warning = w.handler),
             warning = W)
  
  if (is.null(res) || len(res)==0)
    res = list(value="???")
  if (is.null(res$value ) || len(res$value)==0)
    res.value="??"
  
  if (!is.null(res) && !is.null(res$warning))
  {
    mw = toString(res$warning)
    traceback()
    if (len(mw))
      print(mw)
    res$value = NULL
  }
  if (!is.null(res) )
    if( mm.strFind("Error",res$value))
    { 
      print("tryM-Error-Case")
      #browser()
      mw = toString(res$value)
      tb=traceback()
      if (!is.null(tb) && len(tb) >0)
        print(tb)
      if (len(mw))
        print(mw)
      res$value = NULL
      browser()
    }
  #  browser()
  return (res$value)
}



#x=tryM( log( NULL ) )
#tryM(  1/0  )

#####################################################################################################
#die Steigungen im rollierenden Fenster- hier darf ein ganzes, breites xts-Objekt kommen . dank lm.fit()
#####################################################################################################

#####  ist wie length(x) bzw. dim(x)[1]
shape<-function(Y)
{
  if (is.vector(Y))
    return(len(Y))
  return(dim(Y)[1])
}


rollRange<-function(Y,win=1000)
{
  norm.i =function(clos){ra = range(clos,na.rm=T);ret= ra[2]-ra[1]}
  
  ret=rollapplyr(Y, win, FUN=norm.i, by.column = T)
  return(ret)
}
if (F)
{
  PN=rollRange(mNorm(prices),90)
  plot(PN)
  PN=rollNorm(prices)
  mchart(PN)
}

rollRegressionXTS<-function(Y,win=60)
{
  #browser()
  vec=F
  if (dim(Y)[2]==1)
  {  Y = cbind(Y,Y)
     vec = T
  }
  dolm1 <- function(Y){ret=coef(stats::lm.fit(cbind(Intercept=1,index(Y)-index(first(Y))),coredata(Y))) }
  
  slope90=rollapplyr(Y, win, dolm1, by.column = F)

  #pick Dir nur die Steigungen raus 
  ret=slope90[,seq(2,ncol(slope90),2)]
  colnames(ret)=  sapply(colnames(Y),function(x) sprintf("%s_slope%d",x,win))
  if (vec)
    ret = ret[,1]
  return(ret)
}

w.rollRegressionXTS<-function(Y,win=60)
{
  #browser()
  vec=F
  if (dim(Y)[2]==1)
  {  Y = cbind(Y,Y)
     vec = T
  }
  
  dolm <- function(Y){X=as.matrix(c(1:shape(Y)));W=X;coef(lm.fit(X,coredata(Y),w=W))}
  
  slope90=rollapplyr(Y, win, dolm, by.column = F)
  #pick Dir nur die Steigungen raus 
  ret=slope90[,seq(2,ncol(slope90),2)]
  colnames(ret)=  sapply(colnames(Y),function(x) sprintf("%s_slope%d",x,win))
  if (vec)
    ret = ret[,1]
  return(ret)
}


############# langsamer und lm basiert
rollRegressionXTS.lm<-function(Y,win=60)
{
  #browser()
  vec=F
  
  if (dim(Y)[2]==-1)
  {  Y = cbind(Y,Y)
     vec = T
  }
  #  dolm <- function(Y){coef(lm.fit(cbind(Intercept=1,index(Y)-index(first(Y))),coredata(Y)))}
  
  dolm<-function(Y) {x=as.matrix(c(1:shape(Y))); y=coredata(Y);res=coef(lm(y~x))[2]}
  
  slope90=rollapplyr(zoo(Y), win, dolm, by.column = T)
  #pick Dir nur die Steigungen raus  ???  nach Umsellung auf r.3.0 anders
  #ret=slope90[,seq(2,ncol(slope90),2)]
  ret=slope90
  #  browser()
  
  #dim(ret)
  #dim(Y)
  #len(colnames(Y))
  colnames(ret)=  sapply(colnames(Y),function(x) sprintf("%s_slope%d",x,win))
  if (vec)
    ret = ret[,1]
  ret=as.xts(ret)
  return(ret)
}




#SCHROTT ? winvec ist ein vektor, so lang wie y und enth�lt die jeweils zu nutzende Fensterl�nge
rollRegressionXTSw.lm<-function(Y,winvec=c(60,30,20))
{
  #geth so erst mal nur f�r 
  
  #  dolm <- function(Y){coef(lm.fit(cbind(Intercept=1,index(Y)-index(first(Y))),coredata(Y)))}
  
  #dolm<-function(Y) {wlen=Y[,1];browser();res=coef(lm.fit(x=as.matrix(c(1:shape(Y)), y=coredata(Y[,-1])));  as.vector(res)}
  
  #dolm<-function(Y) {x=as.matrix(c(1:shape(Y))); y=coredata(Y);res=coef(lm(y~x))[2]}
  
  
  dolm<-function(Y) {wlen=nval(last(Y[,1])); x=as.matrix(c(1:wlen)); y=coredata(last(Y[,-1],wlen)); res=coef(lm(y~x))[2]}
  
  win=max(winvec)
  slope90=rollapplyr(zoo(cbind(winvec,Y)), win, dolm, by.column = F)
  
  
  #  browser()
  # win=max(winvec)
  #slope90=rollapplyr(zoo(merge(winvec,Y)), win, dolm, by.column = F)
  #pick Dir nur die Steigungen raus  ???  nach Umsellung auf r.3.0 anders
  #ret=slope90[,seq(2,ncol(slope90),2)]
  ret=slope90
  #dim(ret)
  #dim(Y)
  #len(colnames(Y))
  
  #browser()
  #colnames(ret)=  sapply(colnames(Y),function(x) sprintf("%s_wslope%d",x,win))
  
  
  ret=as.xts(ret)
  return(ret)
}
########################################################
##########################################################
nval<-function(x)
{
  res=0
  if (len(x)==0)
    return(0)
  if (is.xts(x) )
     return(as.numeric(coredata(x)))
   if (is.vector(x) )
     return(as.numeric(x))
  if (is.na(x))
    res=0
  res=try(as.numeric(x))
  return(res)
}
#########################################################################
#schreib die wichtigste Ergebnisse eines bt-Experiments auf pdf und xls
#########################################################################

pdf_Report<-function(models,repName,data=NULL)
{
  pdf =sprintf("Models/%s/%s.pdf", dataSet, repName)
  mP("Write Data Charts to %s",pdf)
  browser()
  pdf(file = pdf, width=8.5, height=11) 
  #DataInfo<<-NULL
  print(ls(models))
  k=compareViewModels(models,data$prices,alloc=T)
  custom.period.chart(models)
  #  dev.off()
  dev.off()
  mP("Write Data Charts to %s",pdf)
  
  writeModelDataXls(models,xlsName=sprintf("Models/%s/Results.xls/%s.xls",dataSet,repName), universe=DataInfo)
}
#########################################################################
# get Transaktions
#########################################################################

getTrades<-function(model)
{
  return(  model$trade.summary$trades)
}

#########################################################################
#########################################################################


showNa<-function(p)
{
  mP("showNa ------>")
  cat(class(p))
  cat(str(p))
  print ("range")
  print(range(p))
  #browser()  
  if (!is.null(dim(p))  && dim(p)[2] >1)
  {print("matrix")
   apply(p,2,function(col) col[which(is.na(col))])
  }
  else
  {print ("vector")
   k=(p[!is.finite(p)])
   cat(head(p))
  }
}
#########################################################################
#http://stackoverflow.com/questions/5671149/permute-all-unique-enumerations-of-a-vector-in-r
#permutate(c(1,3,5))
#siehe auch gtools - lib
#########################################################################
permutate <- function(d) {
  dat <- factor(d)
  N <- length(dat)
  n <- tabulate(dat)
  ng <- length(n)
  if(ng==1) return(d)
  a <- N-c(0,cumsum(n))[-(ng+1)]
  foo <- lapply(1:ng, function(i) matrix(combn(a[i],n[i]),nrow=n[i]))
  out <- matrix(NA, nrow=N, ncol=prod(sapply(foo, ncol)))
  xxx <- c(0,cumsum(sapply(foo, nrow)))
  xxx <- cbind(xxx[-length(xxx)]+1, xxx[-1])
  miss <- matrix(1:N,ncol=1)
  for(i in seq_len(length(foo)-1)) {
    l1 <- foo[[i]]
    nn <- ncol(miss)
    miss <- matrix(rep(miss, ncol(l1)), nrow=nrow(miss))
    k <- (rep(0:(ncol(miss)-1), each=nrow(l1)))*nrow(miss) + 
      l1[,rep(1:ncol(l1), each=nn)]
    out[xxx[i,1]:xxx[i,2],] <- matrix(miss[k], ncol=ncol(miss))
    miss <- matrix(miss[-k], ncol=ncol(miss))
  }
  k <- length(foo)
  out[xxx[k,1]:xxx[k,2],] <- miss
  out <- out[rank(as.numeric(dat), ties="first"),]
  foo <- cbind(as.vector(out), as.vector(col(out)))
  out[foo] <- d
  t(out)
}

#########################################################################
#combine2(spl("a,b,c"),spl("Vater,Mutter"))
#
#x <- seq(0,1,0.05)
#y <- seq(0,1,0.05)
#xy <- expand.grid(x,y)
#newdat <- data.frame(y1=0, x1=xy[,1], x2=xy[,2])
#
#expand.grid(height = seq(60, 80, 5), weight = seq(100, 300, 50),  sex = c("Male","Female"))
#combn(letters[1:4], 2)

#
#########################################################################

combine2 <-function(v1,v2,sep="")
{require(utils)

  sort(apply(expand.grid(v1, v2), 1, paste, collapse = sep, sep = ""))
}

#randperm(seq(2, 10, by=2))  #random permutations  in pracma

#########################################################################
#########################################################################

meanEQ <-function(models)
{
  for(i in c(2:len(ls(models))))
  {  #ignoriere buy hold
    if (i==2)
      eq = models[[i]]$equity
    else
      eq = eq + models[[i]]$equity
  }
  
  norm_Win(2)
  plot(data$prices)
  plot(eq)
  ret = mROC(eq)
  compute.sharpe(ret)
  compute.max.drawdown(eq)
  compute.cagr(eq)
}
#########################################################################
#########################################################################

#l�sche alle Eintr�ge in a deren Dat�mer in b sind
killallIn<-function(Dax,b)
{  
  C = Dax[-c(xts2Index(index(b),Dax)),]  
}
#killallIn(Dax,b)

#########################################################################
#########################################################################

clr<-function()
{
  
  try(while(T)
    dev.off())
}

#########################################################################
# wie na.omit aber f�r mehr spaltige xts
#########################################################################

allFinite<-function(dscd) 
{apply(dscd,2, function(Col) Col[is.finite(Col)])
}
#########################################################################


#### gibt die Zahlen 1.. des Index der Zeitreihe
Index<-function(xtsPrice)
{
  return(endpoints(xtsPrice,"daily")+1)
  
  
  
  x=time(xtsPrice)
  xi=as.numeric(x)-as.numeric(x[1])+1
  return(xi)
}

#########################################################################
#gem. acf sind die folgende Lags die spannenden AutoKorrelationen
#http://a-little-book-of-r-for-time-series.readthedocs.org/en/latest/src/timeseries.html
#schau Dir nur maximal n  Lags an !!
#Gib die Indizes der Lags.. nach Wichtigkeit sortiert zur�ck.

#########################################################################

HotLags<-function(xtsPrice,n=60,visual=F)
{
  xtsPrice=xtsPrice[,1]
  #beer<-ts(coredata(xtsPrice),freq=12)
  if (visual)
    acf(ts(coredata(mROC(xtsPrice)),freq=12), lag.max=n)
  xacf=acf(ts(coredata(mROC(xtsPrice)),freq=12), lag.max=n,plot=F)
  
  ci=0.95
  sigLvl=qnorm((1 + ci)/2)/sqrt(xacf$n.used)
  
  Acf=xacf$acf
  acfi=order(abs(Acf),decreasing=T)
  #ACf = abs(Acf[acfi])
  ACf = (Acf[acfi])
  mcfT= last(which(abs(ACf) >sigLvl))  #so viele der n Lags sind significant
  #browser()
  hotLags=acfi[1:mcfT] 
  
  return(hotLags)  
}

##########################################################################
# Wie HotLags2 aber gib einen 2. Vector mit den vorzeichenbehafteten
# Werten der Lags zur�ck.
##########################################################################
HotLags2<-function(xtsPrice,n=60,nLag=10,visual=F)
{
  xtsPrice=xtsPrice[,1]
  #beer<-ts(coredata(xtsPrice),freq=12)
  if (visual)
    acf(ts(coredata(mROC(xtsPrice)),freq=12), lag.max=n)
  
  xacf=acf(ts(coredata(mROC(xtsPrice)),freq=12), lag.max=n,plot=F)
  
  ci=0.95
  sigLvl=qnorm((1 + ci)/2)/sqrt(xacf$n.used)
  
  Acf=xacf$acf
  acfi=first(order(abs(Acf),decreasing=T),nLag)
  
  #ACf = abs(Acf[acfi])
  ACf = (Acf[acfi])
  mcfT= last(which(abs(ACf) >sigLvl))  #so viele der n Lags sind significant
  #browser()
  res = list()
  
  res$lag=acfi[1:mcfT] 
  res$value = ACf[1:mcfT]
  
  return(res)  
}

#######################################################################
# Gibt einen Vector mit den mom-Werten f�r den letzten Kurs in prices
#wobei die mom-Lags den nLag wichtigsten  HotLags entsprechen
#Das Teil ist Multidim einsetzbar - berechnet aber NUR f�r den LEZTEN Wert
#in prices die HotLagMom - ... brauch mindestens 100 Tag in prices !!
#######################################################################
HotLagMom<-function(prices, nLag=10,mode="justRowSum",visual=F) { 
  
  Res=  unlist(lapply(colnames(prices),
                      function(colN)
                      {
                        close=na.omit(prices[,colN])
                        today = DateS(last(close))
                        hotLag2 = HotLags2(close,n=100-1,nLag=nLag,visual=visual)  #schau Dir die letzten 100 Tage an
                        #resHOT__[today]<<-sum(hotLag2$lag)
                        if (visual)
                        {
                          mP("%s %s ",today,toString(hotLag2$lag))
                          mP("%s %s ",today,toString(hotLag2$value))
                        }
                        maxL = min(len(hotLag2$lag),nLag)  #maximal 10 HotLags-Werte ber�cksichtigen
                        diffLag = lapply(c(1:maxL),
                                         function(x) 
                                         {
                                           LAG = hotLag2$lag[x]; VAL = hotLag2$value[x];
                                           #if (sum(hotLag2$lag) < 2 && LAG==1) LAG=zlemaN  #oft gibts nur den HotLag 1 .. dann muss ein anderer Wert ran... 
                                           last(momentum(close,n=LAG))*VAL  #gewichtet mit der Wichtigkeit es Lags
                                           #ROC(ZLEMA(close, lag=abs(LAG))) * -VAL
                                           #bad: ROC(ZLEMA(close, lag=abs(LAG)),n=abs(LAG)) * -VAL
                                         })
                        #bilde �ber alle Lag-Momentum-Werte die (data.frame)-Row-Summe
                        res = (na.omit(as.xts(data.frame(diffLag))))
                        rs=rowSums(res)
                        if (mode=="justRowSum")
                          return(rs)
                      }) )
  
  names(Res) = sapply(colnames(prices),function(x) paste("HotLag",x,sep="."))
  return(Res)
  #res = cbind(rowSum=rs,res)
  #print(res)
  #return(res)
  #  res[] = rowSums(res)
  #res = last(res[,1]) 
  #
}
if (F)
  x=HotLagMom(prices,nLag=20)

#########################################################################

last = xts::last
globalCAT=""  #wenn "" wird auf alles gestoppt  .. wenn "no"  auf nichts -sondern immer nur auf das zu pos passende..

if (F)
  list_R_functions('Mlib/InputConfig_Portfolio_TD.R')

#########################################################################
#http://cartesianfaith.wordpress.com/2013/03/10/better-logging-in-r-aka-futile-logger-1-3-0-released/
#MM_LOG:
#library(futile.logger)
#flog.info("Got covariance matrix")
#flog.debug("This %s print", "won't")
#flog.warn("This %s print", "will")

#flog.info("This inherits from the ROOT logger", name='logger.a')
#flog.threshold(DEBUG, name='logger.a')
#flog.debug("logger.a has now been set to DEBUG", name='logger.a')
#flog.debug("But the ROOT logger is still at INFO (so this won't print)")

#flog.appender(appender.file("other.log"), name='logger.b')
#flog.info("This writes to a %s", "file", name='logger.b')


DateS<-function(d)
{
  return(toString(as.Date(index(d))))
}


####################################################################
#Filter aus der data-Liste lediglich die items raus die auch unter
#data$symbolnames gelistet sind
#data2=isSymbol(data)
####################################################################

isSymbol<-function(data)
{
  res = list()
  for(sy in data$symbolnames)
  {
    print(sy)
    print(dim(data[[sy]]))
    
    res[[sy]]=data[[sy]]
  }
  
  return(res)
}

###############################################################################
# Wenn 
#position.score = bt.apply(data, function(x)  TSI(HLC(x)) )    
#auf nen Bug l�uft geht:
#position.score = TSIsymbol(data)
#################################################################################
TSIsymbol<-function(data,sym=NULL)
{
  res = list()
  if (is.null(sym))
  {
    for(sy in data$symbolnames)
    {
      print(sy)
      #print(dim(data[[sy]]))
      
      re=res[[sy]]=TSI(HLC(data[[sy]]))
      re[is.na(re)] <-0
      res[[sy]]=re
    } 
    block=NULL
    for(sy in ls(res))
    {
      if (is.null(block))
        block=as.xts(res[[sy]])
      else
        block=merge(block,as.xts(res[[sy]]))
    }   
  }
  else
  {
    sy = sym
    res[[sy]]=TSI(HLC(data[[sy]]))
    block=as.xts(res[[sy]])
  }
  
  return(block)
}


#########################################################################
#########################################################################

plotM<-function(price,Today=Sys.Date())
{
  plot(price)
  abline(v=as.POSIXct(as.Date(Today)),col=col.add.alpha("red" , 80),lwd=3)
}

## plotOBOS -- displaying overbough/oversold as eg in Bespoke's plots
##
## Copyright (C) 2010 - 2011  Dirk Eddelbuettel
##
## This is free software: you can redistribute it and/or modify it
## under the terms of the GNU General Public License as published by
## the Free Software Foundation, either version 2 of the License, or
## (at your option) any later version.
library(RColorBrewer )

plotOBOS <- function(symbol, n=50, type=c("sma", "ema", "zlema"), years=1, blue=TRUE) {
  
  today <- Sys.Date()
  X <- getSymbols(symbol, src="yahoo", from=format(today-365*years-2*n), auto.assign=FALSE)
  x <- X[,6]                          # use Adjusted
  
  type <- match.arg(type)
  xd <- switch(type,                  # compute xd as the central location via selected MA smoother
               sma = SMA(x,n),
               ema = EMA(x,n),
               zlema = ZLEMA(x,n))
  xv <- runSD(x, n)                   # compute xv as the rolling volatility
  
  strt <- paste(format(today-365*years), "::", sep="")
  x  <- x[strt]                       # subset plotting range using xts' nice functionality
  xd <- xd[strt]
  xv <- xv[strt]
  
  xyd <- xy.coords(.index(xd),xd[,1]) # xy coordinates for direct plot commands
  xyv <- xy.coords(.index(xv),xv[,1])
  
  n <- length(xyd$x)
  xx <- xyd$x[c(1,1:n,n:1)]           # for polygon(): from first point to last and back
  
  if (blue) {
    blues5 <- c("#EFF3FF", "#BDD7E7", "#6BAED6", "#3182BD", "#08519C") # cf brewer.pal(5, "Blues")
    fairlylight <- rgb(189/255, 215/255, 231/255, alpha=0.625) # aka blues5[2]
    verylight <- rgb(239/255, 243/255, 255/255, alpha=0.625) # aka blues5[1]
    dark <- rgb(8/255, 81/255, 156/255, alpha=0.625) # aka blues5[5]
  } else {
    fairlylight <- rgb(204/255, 204/255, 204/255, alpha=0.5)         # grays with alpha-blending at 50%
    verylight <- rgb(242/255, 242/255, 242/255, alpha=0.5)
    dark <- 'black'
  }
  
  plot(x, ylim=range(range(xd+2*xv, xd-2*xv, na.rm=TRUE)), main=symbol, ) 
  # basic xts plot
  lines(x,col=fairlylight)
  polygon(x=xx, y=c(xyd$y[1]+xyv$y[1], xyd$y+2*xyv$y, rev(xyd$y+xyv$y)), border=NA, col=fairlylight)   # upper
  polygon(x=xx, y=c(xyd$y[1]-1*xyv$y[1], xyd$y+1*xyv$y, rev(xyd$y-1*xyv$y)), border=NA, col=verylight)# center
  polygon(x=xx, y=c(xyd$y[1]-xyv$y[1], xyd$y-2*xyv$y, rev(xyd$y-xyv$y)), border=NA, col=fairlylight) 	# lower
  lines(xd, lwd=2, col=fairlylight)   # central smooted location
  lines(x, lwd=3, col=dark)           # actual price, thicker
  invisible(NULL)
}

if (F)
  plotOBOS("^GDAXI")


#########################################################################
#rportModels ist ein Liste mit SysInvestor-Modellen
#deren Daten werden in ein xls-workbook geschrieben:
#Ergebnisse, Gewichte, Equity
#########################################################################

if (F)
  writeModelDataXls(models,"test.xls")

writeModelDataXls<-function(reportModels,xlsName="modelData",universe=NULL)
{
  mP("writeModelDataXls %s",xlsName)
  dir.create(dirname(xlsName),recursive=T)
  
  wb <- loadWorkbook(xlsName, create = TRUE)
  # Create a worksheet called 'mtcars'
  if (!is.null(universe))
  {
    createSheet(wb,name="Universe")
    writeWorksheet(wb, data.frame(universe), sheet = "Universe",rownames="Number")
  }
  createSheet(wb, name = "Ergebnisse")
  # Write built-in dataset 'mtcars' to sheet 'mtcars' created above
  out = plotbt.strategy.sidebyside(reportModels, return.table=T)
  ergebnisse = data.frame(out)
  writeWorksheet(wb, ergebnisse, sheet = "Ergebnisse",rownames="Number")
  
  for(modName in ls(reportModels))
  {
    
    if (T || modName=="EW" ) #TEST=
    {
      
      #browser()
      mod=reportModels[[modName]]
      
      sheetName = sprintf("%s_weights",modName)
      createSheet(wb, name=sheetName)
      w = data.frame(cbind(rownames(mod$weight),mod$weight))
      w=mod$weight
      writeWorksheet(wb, w, sheet = sheetName,rownames="Date")
      
      sheetName = sprintf("%s_equity",modName)
      createSheet(wb, name=sheetName)
      eq = data.frame(mod$equity)
      writeWorksheet(wb, eq, sheet = sheetName,rownames="Date")
      sheetName = sprintf("%s_trades",modName)
      createSheet(wb, name=sheetName)
      
      #data$weight=NULL
      mod$trade.summary$trades
      tradelist = mod$trade.summary$trades #bt.trade.summary(data,mod)
      
      writeWorksheet(wb, tradelist, sheet = sheetName)
    }
  }
  
  mP("writeModelDataXls to %s",xlsName)
  # Save workbook - this actually writes the file 'saveMe.xlsx' to disk
  saveWorkbook(wb)
}
###############################################################################
library("XLConnect")
writeTable<-function(table,xlsName="modelData.xls",rownames=NULL)
{
  wb <- XLConnect::loadWorkbook(xlsName, create = TRUE)
  # Create a worksheet called 'mtcars'
  XLConnect::createSheet(wb, name = "Table")
  # Write built-in dataset 'mtcars' to sheet 'mtcars' created above
  ergebnisse = table
  XLConnect::writeWorksheet(wb, ergebnisse, sheet = "Table",rownames=rownames)
  
  mP("writeTable to %s",xlsName)
  # Save workbook - this actually writes the file 'saveMe.xlsx' to disk
  dir.create(dirname(xlsName),recursive=T)
  
  # We now create a (unnamed) cellstyle to be used for wrapping text in a cell
  #wrapStyle <- createCellStyle(wb)
  # Specify the cellstyle to wrap text in a cell
  #setWrapText(wrapStyle, wrap = F)
  
  # Write the data set to the worksheet created above;
  # offset from the top left corner and with default header = TRUE
  #writeWorksheet(wb, data, sheet = "cellsize", startRow = 4, startCol = 2)
  
  # Set the wrapStyle cellstyle for the long text cells.
  # Note: the row and col arguments are vectorized!
  #setCellStyle(wb, sheet = name, row = 5:6, col = 2, cellstyle = wrapStyle)
  
  
  XLConnect::saveWorkbook(wb,file=xlsName)
  
  #writeNamedRegion(object,data,name,header,rownames)
}

###########################################################################################

#demo(package = "XLConnect")
readTable<-function(xlsName="modelData.xls",table="Table")
{
  wb <- XLConnect::loadWorkbook(xlsName, create = T)

  data <- XLConnect::readWorksheet(wb, sheet = table)
}
if (F)
  {
  X1= readTable(xlsName="d:\\DataInfo.xls",table="Table")
  X1= readTable(xlsName="Models\\Orders\\customers.xls",table=1)
  getwd()
  wb=data.frame(date=c(todayS2()), model=c("testmodel"), orders =c(2))
  writeTable(wb,xlsName="D:\\OrderLog.xls")
}


#as.numeric(forecast(cur, h = predictDays)$mean)
#############################################################################
############################################################################
#wenn  nicht geht:
#    dv = bt.apply(data, function(x) { DV(HLC(x), 1, TRUE) } )  
#mach
#  dv = m.apply(data, function(x) { DV(HLC(x), 1, TRUE) } )  
#############################################################################



m.apply_<-function(data, Fun=function(x)x, PreFun = function(x)x, ...,ignore = c(), onlysym=c(),frame="",select="",newName="")
{
  fun=match.fun(Fun)
  symbolnames=data$symbolnames
  block=NULL
  if (len(onlysym)>0)
    symbolnames = onlysym
  if (len(ignore)>0 && len(which(symbolnames==ignore))>0)
    symbolnames= symbolnames[-(which(symbolnames==ignore))]
  
  #browser("m.apply1")
  
  if (len(symbolnames) >0)
  {
    res=list()
    isbuggy=F
    
    
    block=foreach(sy =symbolnames, .combine = cbind) %do%      
{    
  
  temp= try(bt.apply.matrix(data[[sy]][frame], m.ifna.prev))
  temp = try(PreFun(temp))
  #a=c(...)
  temp = try(fun(temp,...))
  
  if (!is.numeric(temp))
    if( mm.strFind("Error",temp))
    {
      cat(  tail(data[[sy]]))
      mP("Bug at m.apply %s",sy)
      
      browser()
      
      isbuggy=T
    }
  
  if (select !="")
  {
    #mP("select")
    #browser()
    if (!is.null(strfind(select,"$")))
      temp= (temp)[[select]]
    else
      temp= (temp)[,spl(select)]
    
  }
  
  ##res[[sy]]=temp
  
  temp
}  #foreach
    
    
    if (isbuggy)
    {
      mP("m.apply:     return NULL because:    isbuggy")
      return(NULL)
    }
    
    
  }
  else
  {
    block = bt.apply.matrix(data$weight, fun,...)
  }
  # mP("#################>>")
  #browser()  
  if (newName =="")      
  {
    if (select == "" )
    {
      if (len(block)> 0 && len(ncol(block))>0)
        colnames(block) = symbolnames  
    }
    else
      if (len(spl(select))==1)
        colnames(block)=sapply(symbolnames, function(x)sprintf("%s.%s",x,select))
    else  
    {
      
      k=sapply(symbolnames,  function(x) {x1__<<-x; sapply(spl(select),function(sel) { sprintf("%s.%s",x1__,sel)})})
      #browser()
      colnames(block)=k[,1]
      
    }
  }
  else
    colnames(block) = sapply(symbolnames, function(x)sprintf("%s.%s",x,newName))
  
  return(block)
}
m.apply<-cmpfun(m.apply_)

library("doParallel")
library("parallel")

if (!exists("CORES_"))
{
  CORES_=detectCores()
  mP("############ registerDoParallel for %d Cores",CORES_-1)
  registerDoParallel(cores = CORES_-1)
}

m.par.apply_<-function(data, Fun=function(x)x, PreFun = function(x)x, ...,ignore = c(), onlysym=c(),frame="",select="",newName="")
{
  
  len <- function
  (
    x  # vector
  )
  {
    return(length(x)) 
  }
  
  #is.ok(matrix(4,4)[0,1])
  mP<-function(...)
  {
    #browser()
    tryM(print(sprintf(...)))
  }
  
  tryM<- function(expr)  #MMA
  {
    W <- NULL
    w.handler <- function(w){ # warning handler
      W <<- w
      invokeRestart("muffleWarning")
    }
    res=  list(value = withCallingHandlers(tryCatch(expr, error = function(e) e),
                                           warning = w.handler),
               warning = W)
    
    if (is.null(res) || len(res)==0)
      res = list(value="???")
    if (is.null(res$value ) || len(res$value)==0)
      res.value="??"
    
    if (!is.null(res) && !is.null(res$warning))
    {
      mw = toString(res$warning)
      traceback()
      if (len(mw))
        print(mw)
      res$value = NULL
    }
    if (!is.null(res) )
      if( mm.strFind("Error",res$value))
      { 
        print("tryM-Error-Case")
        browser()
        mw = toString(res$value)
        tb=traceback()
        if (!is.null(tb) && len(tb) >0)
          print(tb)
        if (len(mw))
          print(mw)
        res$value = NULL
        browser()
      }
    #  browser()
    return (res$value)
  }
  
  
  
  mm.strFind<-function(pat,s)
  {
    if (is.null(s) || len(s)==0)
      return(F)
    return(  grepl(pat, s)[1])
  }
  
  
  
  fun=match.fun(Fun)
  symbolnames=data$symbolnames
  block=NULL
  if (len(onlysym)>0)
    symbolnames = onlysym
  if (len(ignore)>0 && len(which(symbolnames==ignore))>0)
    symbolnames= symbolnames[-(which(symbolnames==ignore))]
  
  #browser("m.apply1")
  
  if (len(symbolnames) >0)
  {
    res=list()
    isbuggy=F
    
    
    block=foreach(sy =symbolnames, .combine = cbind,.packages=spl("TTR,quantmod,xts")) %dopar%
      #block=foreach(sy =symbolnames, .combine = cbind) %do%      
{    
  
  temp= try(bt.apply.matrix(data[[sy]][frame], m.ifna.prev))
  temp = try(PreFun(temp))
  #a=c(...)
  temp = try(fun(temp,...))
  
  if (!is.numeric(temp))
    if( mm.strFind("Error",temp))
    {
      cat(  tail(data[[sy]]))
      mP("Bug at m.apply %s",sy)
      
      browser()
      
      isbuggy=T
    }
  
  if (select !="")
  {
    #mP("select")
    #browser()
    if (!is.null(strfind(select,"$")))
      temp= (temp)[[select]]
    else
      temp= (temp)[,spl(select)]
    
  }
  
  ##res[[sy]]=temp
  
  temp
}  #foreach
    
    
    if (isbuggy)
    {
      mP("m.apply:     return NULL because:    isbuggy")
      return(NULL)
    }
    
    
  }
  else
  {
    block = bt.apply.matrix(data$weight, fun,...)
  }
  # browser()
  if (newName =="")      
  {
    if (select == "")
      colnames(block) = symbolnames
    else
      if (len(spl(select))==1)
        colnames(block)=sapply(symbolnames, function(x)sprintf("%s.%s",x,select))
    else  
    {
      
      k=sapply(symbolnames,  function(x) {x1__<<-x; sapply(spl(select),function(sel) { sprintf("%s.%s",x1__,sel)})})
      #browser()
      colnames(block)=k[,1]
      
    }
  }
  else
    colnames(block) = sapply(symbolnames, function(x)sprintf("%s.%s",x,newName))
  
  return(block)
}
m.par.apply<-cmpfun(m.par.apply_)


if (F)
{
  
  x=m.apply(data, function(x) {print(colnames(x)); return(Hi(x)-Cl(x))}, ignore=c("Zinsen"))
  x=m.par.apply(data, function(x) {mP("... %s %d",colnames(x[,1]),dim(x)[2]); return(x[,1]-x[,3]);}, ignore=c("Zinsen"))
  tail(x)
  tail(Hi(data$DAX)) - tail(Cl(data$DAX))
  m.apply(arg$dat,onlysym=colnames(arg$clos),Fun=BBands, PreFun=HLC, n=as.integer(par$bbM),maType = SMA)
}
############ wie m.apply
data.apply<-function(data, Fun,...)
{
  
  fun=match.fun(Fun)
  if (len(data$symbolnames) >0)
  {
    res=new.env()
    for(sy in data$symbolnames)
    {
      print(sy)
      temp= try(bt.apply.matrix(data[[sy]], m.ifna.prev))
      
      assign(sy,try(fun(temp,...)),envir=res)
    } 
    assign("symbolnames",data$symbolnames,envir=res)
    assign("prices", m.apply(res, function(x) Cl(x)), envir=res)
    w = res$prices; w[]=NA;
    assign("weights",w,envir=res)  
    
  }
  
  return(res)
}
############ f�ge eine neues Symbol hinzu
data.add<-function(data, symNam,symbol)
{
  print(symNam)
  #browser()
  assign(symNam,symbol,envir=data,pos=1)
  ls(data)
  assign("symbolnames",c(symNam,data$symbolnames),envir=data)
  assign("prices", m.apply(data, function(x) Cl(x)), envir=data)
  w = data$prices; w[]=NA;
  assign("weights",w,envir=data)  
  
  return(data)
}


data.first<-function(data,symbol)
{
  dax = data[[symbol]]
  #data$symbolnames
  #ls(data)
  data.rm(data,symbol)
  data.add(data,symbol,dax)
  print(data$symbolnames)
}



if (F)
{
  
  ls(data     )
  
  data.first(data,"DAX")
  #Dax=data$HealthCare
  ls(data)
  
  data.rm(data,"Dax")
  data$symbolnames
  colnames(data$prices)  #BUG dax fehlt
  data.add(data,"Dax",Dax)  
  colnames(data$price)
  #aus rollierender zeitreihenbetrachtung .. sharep und Cgar berechnen  und MAXdd->daraus
  #attraktivi�tt schlieesen
}


#### symbolnames ist ein vector von strings
data.rm<-function(data, symbolnames)
{
  if (len(symbolnames) >0)
  {
    for(sy in symbolnames)
    {
      data$symbolnames = data$symbolnames[-which(data$symbolnames==sy)]  
    }
    rm(list=symbolnames,envir=data)
    print("assign new prices+weights")
    assign("prices", m.apply(data, function(x) Cl(x)), envir=data)
    w = data$prices; w[]=NA;
    assign("weights",w,envir=data)  
    
  }
  
  return(data)
}
if (F)
{
  data.rm(data,c("Utilities"))
  ls(data)
  data$symbolnames
  
  sapply(spl("GOLD,JAKARTA_COMPOSITE"),FUN=function(stock)
  {data$symbolnames=data$symbolnames[-(which(data$symbolnames==stock))]})
  
}
####################### datenspr�nge im Dialog beheben ##############################
data.repair<-function(prices) 
{
  #source("attention.r")
  #repariere augenf�llige Preisspr�nge - nach R�ckfrage beim User  #siehe attention.r
  problems=  show.attention(prices,fn="level.price",fn.signal="signal.sprung.repair",fak=6,Lag=5,Q="99%")
}

###########################################################
mchart<-function(prices,main = "chart",ylimCol=0)
{
  #colS=getColSet(length(colnames(prices)))
  if (ylimCol > 0)
    plot(prices[,1],ylim=c(min(prices[,ylimCol],na.rm=T),max(prices[,ylimCol],na.rm=T)),main = main)
  else
    plot(prices[,1],ylim=c(min(prices,na.rm=T),max(prices,na.rm=T)),main = main)
  for (cn in seq(1,length(colnames(prices)) ))
    lines(na.omit(prices[,cn]),col=cn)#colS[cn])
}
mchart2<-function(Dax,r,main="")
{
  plota(Dax,type="l",ylim=range(Dax,na.rm=T),LeftMargin=3,main=main)
  plota2Y(r,type="l",ylim=range(r,na.rm=T),las=1,col="blue",col.axis="blue")
  plota.legend(sprintf("%s,%s",colnames(Dax[,1]),colnames(r[,1])),"black,blue")
}
################################################################################
#Infos zum geladenen Daten .. etwas weniger zeitaufw�ndig wie data.Info()
#und es gibt die sharedPrices zur�ck
##########################################################################
data.info<-function(data,ignore = c(),visual =T)
{
  #browser()
  mP("data$symbolnames: %s",data$symbolnames)
  for(i in data$symbolnames) {colnames(data[[i]])=normColnameS(data[[i]])}
  
  dataf = m.apply(data,PreFun=function(x) na.omit(Ad(x)),ignore=ignore) #ein xts mit allen 
  #browser()
  sharedPrices = (na.omit(merge(dataf)))
  #browser()
  ##.Close abschneiden
  if (F)
    colnames(sharedPrices)  =unlist(
      lapply(colnames(sharedPrices),
             FUN= function(x) trim(unlist(strsplit(x,"\\."))[1] ))  )
  
  res=fromTo(sharedPrices)
  print(toString(res))
  #universum ohnen Gold
  
  if  (visual)
    purePlot(mNorm(sharedPrices))
  
  #try(mchart(mNorm((merge(dataf)))))
  #coint=data.coint(data)#~~~~~~~~~~~~~~~~~~~~~
  
  #  browser()
  #  LongName=SecList[Name==colSym(first(names(dataf)))]$LongName
  
  dataInfo=try(
    rbindlist( lapply(dataf, function(x)
    {
      sym=colSym(names(x))
      print(sym)
      ft=fromTo(na.omit(data[[sym]])); list(name=sym, LongName=trim(toString(SecList[Name==colSym(names(x))]$LongName)),  from=ft[1],to=ft[2],Min=min(x,na.rm=T),Max=max(x,na.rm=T),len=shape(data[[sym]]))} )))
  
  #mP("%s       %s %s    |%s|%s",dataInfo[["name"]],"|", dataInfo[["LongName"]],"|",dataInfo[["from"]],dataInfo[["to"]],dataInfo[["Min"]],dataInfo[["Max"]])
  #MXXXXXX
  
  #browser()
  if (visual)
  {
    DataInfo <<-data.frame(dataInfo)  #damit auch im Workspace in RStudio anschaubar
    View(DataInfo)
  }
  print(res)
  return(sharedPrices)
}
###############################################################
###################################################################

colSym<-function(colname)
{
  #colname="hh.cl"  -> hh
  trim(unlist(strsplit(colname,"\\.")[1]))[1]
}

priceSyms<-function(xtsS)
{  sapply(colnames(xtsS), function(x)  colSym(x))
}

normColname<-function(colname)
{
  #colname "hh..Close" ->  hh.Close
  # browser()
  v=unlist(strsplit(colname,"\\."))
  res = trim(toString(v[1]))
  #browser()
  if (len(v)>1)
    res = paste(res,trim(toString(last(v))),sep=".") 
  res = toupper(res)
  return(res)
}

firstColname<-function(colname)
{
  #colname "hh..Close" ->  hh.Close
  # browser()
  v=unlist(strsplit(colname,"\\."))
  res = trim(toString(v[1]))
  res = toupper(res)
  return(res)
}
normColnameS<-function(prices)
{
  newColnames= sapply(colnames(prices), normColname)
  names(newColnames) = newColnames
  unlist(newColnames)
}
if (F)
  lapply(data, function(x) colnames(x) = normColnameS(x))

data.rename<-function(data,olds,news)
{
  #browser(mP("data.rename"))
  merk = data[[olds]]
  #alle spalten in merk umbenennen
  sapply(colnames(merk),function(x,news){rest= unlist(strsplit(x,news))[2]; sprintf("%s%s",news,rest)},news=news)
  
  data.rm(data=data,olds)
  
  data$symbolnames
  colnames(data$prices)
  data.add(data,news,merk)
}

################################################################################
#Infos zum geladenen Daten
#sym="5YEARNOTE"
#as.numeric("dd")
################################################################################
data.Info<-function(data, filename="Data",frame="2001::")
{
  # benenne   5YEARNOTE   in X5YEARNOTE Note um ,   das macht sonst foreach..unkontrolliert
  
  for(sym in data$symbolnames)
    if (!is.na(as.numeric( substring(sym, 1, 1))))# der erste Buchstabe ist eine Ziffer
    {
      new_sym=sprintf("X%s",sym)
      data.rename(data,sym, new_sym)
    }
  
  
  dataf = m.apply(data,function(x) na.omit(Cl(x))) #ein xts mit allen Daten
  
  sharedPrices = mNorm(na.omit(merge(dataf)))
  res=fromTo(sharedPrices)
  print(toString(res))
  #universum ohnen Gold
  
  pdf(file=sprintf("%s.pdf",filename), width=15,height=8.5)
  try(mchart(sharedPrices))#[,-which(colnames(sharedPrices)=="Gold.Close")])
  try(mchart(mNorm((merge(dataf)))))
  dev.off()
  #coint=data.coint(data)#~~~~~~~~~~~~~~~~~~~~~
  
  dataInfo=rbindlist( lapply(dataf, function(x){ft=fromTo(na.omit(x)); list(name=colnames(x),  from=ft[1],to=ft[2],Min=min(na.omit(x)),Max=max(na.omit(x)))} ))
  mP("%s       %s %s    |%s|%s",dataInfo[["name"]],dataInfo[["from"]],dataInfo[["to"]],dataInfo[["Min"]],dataInfo[["Max"]])
  
  DataInfo <<-data.frame(dataInfo)  #damit auch im Workspace in RStudio anschaubar
  
  writeTable(DataInfo,xlsName=sprintf("%s.xls",filename),rownames=NULL)
  
  #nicht gelieferte Daten
  print("bad Data")
  print(toString(dataInfo[is.na(dataInfo$Min) | is.na(dataInfo$Max)]$name))
  
  #ls(data)
  save(data,file=sprintf('T2data/%s.Rdata',filename))   ;#  Load("gv")
  print( toString(fromTo(data$prices)))
  
  #tail(data$prices)  
  #prices = m.apply(data, function(x) tail(x[frame,],1))
  #p=m.apply(data, function(x) {print(tail(x,1)); Cl(na.omit(x[frame,]))})
  prices = m.apply(data, function(x) mNorm(na.omit(Cl(x[frame,]))))
  #purePlot(prices)
  #frame="2001::"
  #print(coint)
  return(res)
}

##########################################################################

contains<-function(what,vec)
{
  return (len(which(vec==what))>0)
}
if (F)
  contains("price",spl("price,coint,target,score"))

##########################################################################
#Berechne eine Reihe von Basis-Aufgaben auf preisdaten und gib diese als Liste zur�ck:
#evtl. sehr zeitaufw�ndig - darum kann man mit dem mode-vektor die Aufgaben w�hlen die einen
#interessierren
#Info,
#cointegration
#targetByDD
##########################################################################
data.analysis<-function(data, xlsFile="DataAnalysis", mode=spl("price,priceCleaned,coint,target,score"))
{
  data=data.Info(data,xlsFile) 
  res=list()
  res$data=data
  
  #mdata= data.analysis(data, xlsFile="DataAnalysis", mode=spl("price"))
  #global_Targets=compute.Targets(mdata$prices)
  
  #ret = Return.clean(ret, method = c("none", "boudt", "geltner")[2])
  #browser()
  frame=sprintf("%s::",DateS(data$prices[1]))
  if (contains("priceCleaned",mode)) #MM_TODO:  hier checken ob �berhaupt ein Preissprung > 10% vorkommt .. sonst kann man sich das schenken und Zeit sparen
    res$prices= data$prices = tryM(m.apply(data, function(x) mNormCleaned(na.omit(Cl(x[frame,])))))      
  else
    if (contains("price",mode))
      res$prices=data$prices = tryM(m.apply(data, function(x) mNorm(na.omit(Cl(x[frame,])))))
  if (contains("coint",mode))
    res$coint=tryM(data.coint(data))#~~~~~~~~~~~~~~~~~~~~~
  
  if (contains("target",mode))
  {global_Targets <<- tryM(compute.Targets(data$prices,0.16,0.05))
   colnames(global_Targets)<<-pureColnames(data$prices)
   
   res$target = global_Targets
  }
  if (contains("score",mode))
    #erzeuge ein bin-matrix die zeigt wann welche zeitreihe zu den top titeln geh�rt hat
    res$score=tryM(calc.score.nk(data$prices,n=10, K=7, wlen=150))
  
  return(res)
}

if (F)
{
  data.analy = data.analysis(data)
  global_Targets <<- tryM(compute.Targets(data$prices,0.16,0.05))
  
  
}
##########################################################################################################
# die colnames - aber ohne das was rechts vom . steht .. also ohne  .Close...
##########################################################################################################
pureColnames<-function (Xts)
{
  unlist( lapply(colnames(Xts),
                 FUN= function(x) 
                 {
                   norm.ret=toupper(paste(sapply(strsplit(x,"\\."),trim)[1],collapse="."))
                   spli=unlist(strsplit(x,"\\."))
                   abgeschni=""
                   if (shape(spli)>1) abgeschni=spli[2]
                   if (abgeschni == "DE") return(x)  #wenn ich Dax-Titel direkt bei yahoo geladen hab, k�nnen die auf ".DE" enden .. dann darf nichts abgeschnitten werden
                   return(norm.ret)
                 }))
}
##########################################################################################################
#Liste alle cointegrierten Datenpaare
#Siehe auch das globale data.frame - Objekt COINT
#  #http://quanttrader.info/public/testForCoint.html
##########################################################################################################
data.coint<-function(data,frame="")
{
  res = list()
  cointRes = list()
  for(sy1 in data$symbolnames)
  {
    l= list()
    part=data$symbolnames
    part2=data$symbolnames[c(which(part==sy1):len(data$symbolnames))]
    part1=data$symbolnames[c(1:which(part==sy1))]
    for(sy2 in  part1)  #matrix ist symmetrisch - die h�lfte zu rechnen reicht
    {
      l[[sy2]]="."
    }
    for(sy2 in  part2)
    {
      l[[sy2]] =  is.cointegrated(na.omit(Cl(data[[sy1]])[frame,]),na.omit(Cl(data[[sy2]])[frame,]))   
      if (l[[sy2]] !="")
        res[[sy1]]=sy2
      
    }
    cointRes[[sy1]] = l    
  }
  
  COINT<<- data.frame(rbindlist(cointRes))
  COINT<<-cbind(colnames(COINT),COINT)
  return(res)
}


if (F)
{
  SektorSpdrUSA<<- T2$new(PortfolioName = "SektorSpdrUSA", bench="Dax",visual = T, online=T )
  data<-SektorSpdrUSA$t0data
  # data.Info(data,"SektorSpdrUSA")
  
  coint=data.coint(data)
  print(coint)
}


###############################################################################
if (F)  #entferne Leerzeichen in Colnames
{
  lapply(data$symbolnames, FUN=function(symb) {
    #  print(symb)
    colnames(data[[symb]])=
      lapply(colnames(data[[symb]]),
             FUN= function(x) paste(sapply(strsplit(x,"\\."),trim),collapse=".") )})
}
##################################################################################
#sind zwei zeitreithen cointegriert
##################################################################################
is.cointegrated<-function(gld,gdx)
{
  library(tseries)
  
  if (colnames(gld[,1])==colnames(gdx[,1] ))
    return("")
  
  t.zoo <- mNorm( merge(gld, gdx, all=FALSE))
  
  t <- as.data.frame(na.omit(t.zoo))
  print(colnames(t))
  
  cat("Date range is", format(start(t.zoo)), "to", format(end(t.zoo)), "\n")
  
  m <- lm(sprintf("%s ~ %s + 0",colnames(t)[1],colnames(t)[2]), data=t)#gld ~ gdx + 0
  beta <- coef(m)[1]
  
  cat("Assumed hedge ratio is", beta, "\n")
  
  #sprd <- t$gld - beta*t$gdx
  sprd <- t[[1]] - beta*t[[2]]
  ht <- adf.test(sprd, alternative="stationary", k=0)
  
  cat("ADF p-value is", ht$p.value, "\n")
  
  if (ht$p.value < 0.05) {
    cat("The spread  is likely mean-reverting\n")
    #browser()
    return (toString(ht$p.value) )
  } else {
    cat("The spread is not mean-reverting.\n")
    return("")
  }
}

#########################################################################
#  w�hle einige Spalten c(selection) aus block und bilde daraus ein neues xts.
#########################################################################
sub.block<-function(block,selection=colnames(block))
{ as.xts(data.frame(lapply(selection, function(x) block[,x]))) }
#######################################################################


#####################################################
# Du willst den Kurs vom atDate.
# evtl. ist atDate aber ein Wochenende .. dann willst
# du den letzten Kurs der vorher in p(rices) enthalten ist
#####################################################
fitDate<-function(p,atDate)
{
  atDate = tryCatch(as.Date(atDate),error=function(e){ return("")})
  if (toString(atDate) == "")
  {
    mP("strange Daten at fitDate %s",atDate)
    browser()
  }
  
  atDate2= as.Date(index(last(p[as.Date(index(p))<=as.Date(atDate)])))
  if (abs(atDate2-atDate) > 4) #maximal 4 Feiertage am St�ck tolerieren
    return("")
  return(atDate2)
}

### �bergib einen xts-Wert (z.B. last(prices[,1]))
# und bau aus dem und den wlen-Tagen vorher liegendem Datum einen frame-string
#######################################################################
get.frame<-function(xtsWert,wlen=100 )
{
  l2 = as.Date(index(xtsWert))
  l1 = l2-wlen
  frame=sprintf("%s::%s",l1,l2)
}
if (F)
  apply.monthly(prices[,1], FUN=function(x) 
  {  frame=get.frame(last(prices)) ; score.nK(prices[frame]) })


#############################################################################
#gib mir den Index (integer 1...) in prices (die wievielte Pos im xts-vektor ist at Date),  mach evtl. vorher  fitDate()  
#nun vektor-tauglich
####################################################################

get.Index_<-function(prices,atDate,lineal=F,nextValue=1)
{

  if (len(prices[atDate])==0)
    atDate=DateS(first(prices[as.Date(index(prices))>=atDate]))
  
  if (len(atDate)==0)
    {
    sag("get.Index missing %s",atDate,warte=T)
    return(0)
  }
  if (F)
  {
    if (nextValue <2)  #falls Du nach einem Wochenende fragst, gib den freitag vorher an...
    {
      #browser(mP("get.Index - unknown date"))
     return(get.Index(prices,atDate-1,lineal=lineal, nextValue=nextValue+1))
    }
  else return(0)
  }
  
  if (lineal) return(coredata(prices[atDate])  )

  
  if (F)
  {
    p=prices[sprintf("::%s",atDate)]
    ep=endpoints(p,"days")
    ep = ep[ep > 0]   
    res = last(ep)
    print(res)
    return(res)
  }
  
  res=  vapply(atDate,1,FUN=function(x){
    p=prices[sprintf("::%s",x)]
    ep=endpoints(p,"days")
    ep = ep[ep > 0]   
    res = last(ep)
    return(res)
  })


  return(res)
}
get.Index<-cmpfun(get.Index_) #compilier das Teil

###################################################################


get.frame2<-function(prices,atDate,wlen=200 )
{
  l2 = get.Index(prices,fitDate(prices,atDate))
  l1 = l2-wlen
  
  if (l1 <= 0)
  {
    mP("Warning at get.frame2 - first date %s", DateS(prices[wlen+1]))
    return("")
  }
  frame=sprintf("%s::%s",DateS(prices[l1]),atDate)
  #dim(prices[frame])
}

if (F)
  pre = get.frame2(prices,atDate,wlen)



####################################################
####################################################
diffCount<-function(x)
{
  x=na.omit(x)
  dx=sum(sign(na.omit(diff(x))))
}

#### die eigentliche Target-Funktions f�rs Ranking des Monats B
# eigentlich blos  last(equity) / maxDD .. aber es wird zus�tzlich verlangt,
#dass maxdd nicht gr��er ist als maxDD und der Gewinn wenigstens ein 1% ist.
#anderfalls ist xcalmar 0
xcalmar <-function(eq,maxdd,maxDD)
{
  maxDD=maxDD/100
  #tes=cummax(c(1,x))[-1]
  if (abs(maxdd) > abs(maxDD))
    return(0)  #maxloss
  
  if ( last(mNorm(eq)) < 1/100)  #min SollGewinn im Monat:1% 
    return(0)
  
  return(last(mNorm(eq)))
}

getColSet<-function( n)
{
  rgb = colorRampPalette(c("red","black", "blue"),  space = "rgb") #Lab)
  colSet = c("green",rgb(n))
  
}
#######################################################
#geneneriere den lm-formular-string .. besonders f�r multivar-...
# gewicht ~ name + alter
#######################################################
lmFormular<-function(DF,yCol)
{
  coln=colnames(DF)
  ycol=coln[yCol]
  
  xcol=coln[-c(yCol)]
  xcol=paste(xcol,collapse=" + ")
  res = paste(ycol,xcol,sep=" ~ ")
}
if (F)
{
  DF=data.frame(name=c("markus","christine","stefan","tina"),
                alter=c(54,53,18,23) , gewicht=c(1,2,3,5))
  
  x = lmFormular(DF,3)
}

##############################################################################
#Zwei Hilfsmethoden f�r techScore ...
#............................................................................
getTableDataNames<-function(listOfXts)
{
  if (is.null(listOfXts)) return(c())
  return(names(listOfXts))
}
#............................................................................
# list aus einer Liste von xts-Objekte die Werte die zu atDate und coln passen

getTableData<-function(listOfXts,atDate,coln)
{
  if (is.null(listOfXts)) return(c())
  
  res=unlist(lapply(listOfXts,function(x.xts)
  {
    coredata(x.xts[atDate,coln])
  }))
  
  names(res) = names(listOfXts)
  #  print(res)
  #  print(getTableDataNames(listOfXts))
  #  browser()
  return(res)
}
##########################################################################
#wie lag, aber die ersten n Werte werden mit 0 gef�llt (statt NA)
##########################################################################
mlag.0<-function(x,n=1)
{
  res = lag(x,n)
  
  res[c(1:n),]<-0
  res
}


######################################################################################################


########################################### Was bringen eigentlich die Targets ###########
## Die Targets und prices seien von identischer dim und identischen colnames,
#Targets sind 0,1,-1 - signale 
# und werden geplottet
showTargets<-function(prices,Targets)
{
  sapply(colnames(Targets),FUN=
           function(sym){ mP("showTargets %s",sym); if(len(prices[,sym])==0) sag("sym %s not at prices",sym,warte=T) else 
             plotSigPrice(signal=Targets[,sym],prices=mNorm(na.omit(prices[,sym])),indi=NULL) })
  
}
##############################################################################
#nimm als Signal die Kristallkugel eines globalTarget
##############################################################################

signal.global_Target<-function(arg, par = mlist( Target=c(global_Targets3)),visual=F, Target=NULL, ...)
{
  Target=par$Target
  
  if (is.null(Target))
    stop("BedienungsFehler signal.global_Target - das Target darf nicht NULL sein")
  
  sym=colnames(arg$clos)
  if (len(Target[,sym]) ==0)
    stop(sprintf("BedienungsFehler signal.global_Target - das Target muss eine Spalte mit %s enthalten",sym) )
  
  #sma200 =SMA(na.omit(p),n=winLen)
  
  signal = Target[,sym]
  
  return(list(Signal=signal, Indi=NULL))
}

if(F)
  x=indi.Generic("signal.global_Target", global_arg, par=list(Target=global_Targets3),visual=T, TRAINSYM =-1)

###############################################
showTargets2<-function(prices,Targets)
{
  arg=list(clos=prices)
  x=indi.Generic("signal.global_Target", arg, par=list(Target=Targets),visual=T, TRAINSYM =-1)  
}

########################################################################
coarse.code <-function(dax,method = "n", b=100,visual=F)  #univariat, 
  #method q verformat - weil:  equal binning    rattle::binning(p, bins=4, method="quantile",    labels=NULL, ordered=TRUE, weights=NULL) #ave
  #wie viele sind dann eigentlich im jeweiligen bin
  #  AV=ave(res,cut(res,b=b,labels=F),FUN=count)   #ave wendet FUN auf jedes Element der gruppe an ... 
  # sapply(1:b,FUN=function(x)  first(AV[res==x]))
  #einfacher  bin - z�hler
  #  sapply(1:b,FUN=function(x)  count(res[res==x])) oder  mit netten namen:
  #  sapply(1:b,FUN=function(x) {res= count(cp[cp==x]);names(res)<-x;return(res)})
  
  #  
{
  #dax = na.omit(dax)
  
  if (F)
  {
    #coarse codeing
    plot(as.numeric(cut(dax,b=b)))  #unterteile den Wertebereich einfach in 10 gleichweite Intervalle 
    
    #w�hle hier nicht einfach "gleichweite" - Intervalle , sondern die Intervalle so,
    #dass jeweils gleich viele dax-werte hineinfallen- das wirkt im plot aber gestalt ver�ndernd
    quantile.range <- quantile(dax, probs = seq(0, 1, 0.1),na.rm=F)
    plot(diff(quantile.range))
    plot(as.numeric(cut(dax,breaks=as.numeric(quantile.range)  )))
    
    dax.r = na.omit(mROC(dax))
    library(Hmisc)  #hdquantile ist besser als quantile
    quantile.range <- hdquantile(coredata(dax.r), probs = seq(0, 1, 0.05),na.rm=F)
    plot(diff(quantile.range))
    
    plot(as.numeric(cut(dax.r,breaks=as.numeric(quantile.range)  )))
    plot(dax.q)
  }
  #------------------------------------------------------------------>
  if (method != "q")  # n  #default-methode 
  {
    res=as.numeric(cut(dax,b=b,labels=F), include.lowest=T)
    if (visual)
    {
      plot(scaleTo(dax,c(0,b)));r = dax;r[]=res;    lines(r,col="red")
      #einfacher bin z�hler
      print("freq.loc: ")
      freq.loc =sapply(1:b,FUN=function(x) {res= count(cp[cp==x]);names(res)<-x;return(res)})
      
      print (freq.loc)
    }
  }
  else  
    # q- methode
    #w�hle hier nicht einfach "gleichweite" - Intervalle , sondern die Intervalle so,
    #dass jeweils gleich viele dax-werte hineinfallen
  {
    #browser()
    library(Hmisc)  #hdquantile ist besser als quantile
    quantile.range <- hdquantile(coredata(dax), probs = seq(0, 1, 1/b),na.rm=F)
    quantile.range = unique(quantile.range) #manchmal macht hdquantile identische Werte
    res =as.numeric(cut(dax,breaks=as.numeric(quantile.range) ))# ,labels =F))
    plot(scaleTo(dax,c(0,b)));r = dax;r[]=res;    lines(r,col="red")
    
    #
    browser(mP("no bug at coarse.code"))
  }
  Res=dax[,1];Res[]=NA
  # browser(mP("coarse.code"))
  
  if (shape(res)!=  shape(Res))
    browser(mP("bug at coarse.code"))
  else
    Res[]=res
  
  return(Res)
}
if (F)
{
  plot(dax["1994::"])
  plot( coarse.code(dax["1994::"],b=100,method="n"))
  plot( coarse.code(dax["1994::"],b=100,method="q"))
  plot( coarse.code(dax["1994::"]))
  
} 
#################################################################
#vorsicht: nutzt zuk�nftige daten
#################################################################
ksmooth<-function(p,glaettung = 1)
{
  library(KernSmooth)
  p=m.ifna.prev(p)
  
  gridsize <-nrow(p)
  t=c(1:nrow(p))
  bw <-dpill(t,p,gridsize=gridsize)#findet sehr gute bandweite
  bw=bw*glaettung
  lp<-locpoly(x=t,y=p,bandwidth=bw,gridsize=gridsize)
  smooth <-lp$y
  s=p;s[]=smooth
  s
}



###########################################################################
#das Teil separiert super scharf (insample) Trendsegmente- kann also als 
#schneller Generator f�r Trainingssignale dienen
#fast.smoothing() liefert ein so sch�nes signal, dass man seine steigungs-wechsel 
#zum segmentieren nutzen kann
#nicht zum traden geeignent wg. lag(-1)
###########################################################################
fast.smoothing<-function(p,glaettung = 1,visual=F,p0=NULL,roll=F)
{
  #...... smoothing
  #aus dem r-cookbook
  library(KernSmooth)
  p=m.ifna.prev(p)
  
  gridsize <-nrow(p)
  t=c(1:nrow(p))
  bw <-dpill(t,p,gridsize=gridsize)#findet sehr gute bandweite
  bw=bw*glaettung
  lp<-locpoly(x=t,y=p,bandwidth=bw,gridsize=gridsize)
  smooth <-lp$y
  s=p;s[]=smooth
  sig=sign(ROC(s,n=1,type="continuous"))#einfach die tagesdiff der glatten kurve
  
  sd = sig#sign(diff(sig))
  rS=runSum(na.omit(sd),n=2)
  rS=lag(rS,-1)
  peaks <- p[ as.Date(index(rS[rS==0]))]
  
  if (!roll)
  {
  if (len(peaks) < 2)
  {highx=p[1];lowx=p[1];}
  else
  {
    print(".")
    highx = peaks[peaks >= lag(peaks,1)]
    lowx = peaks[peaks < lag(peaks,1)]
    
    f=""
    if (F && visual) #zus�tzlicher Hilfsplot
    {
      plot(p[f])
      points(peaks[f])
      points(highx,col="blue",lwd=3)
      points(lowx,col="red",lwd=3)
    }
    
    highx=as.Date(index(highx))
    lowx=as.Date(index(lowx))
    peaks=as.Date(index(peaks))
    
  }
  }
  if (visual)
  {
    if(F)#zus�tzlicher Hilfsplot
    {
      plot(p);lines(s,col="red")
      lines(scaleTo(sig,range(p)),col="green")
      amark(peaks)
    }
    frame=""
    if (is.null(p0))
      ret= plotSigPrice(signal = lag(sig[frame],-1),prices=p[frame],indi=list(f=merge(p,s)))
    else
      ret= plotSigPrice(signal = lag(sig[frame],-1),prices=p[frame],indi=list(f=merge(p,ZLEMA(p,20),s, scaleTo(p0,range(na.omit(p))))))
  }
  
  if (nrow(s)!=nrow(p))
    browser(mP("bug"))
  
  if (roll)
    return(last(s))
  
  
  
  return(list(smooth = s,highs =highx,lows = lowx,hl=peaks ,sig=sig))
  
}
if(F)
{#MM_STOPSYS
  x=fast.smoothing(p,glaettung = 10,visual=T)  #h�here Werte 2,3...machen alles glatter
  ls(x)
  
  #plot(x$smooth)
  amark(x$lows)
  amark(x$highs,col="blue")
  
 # wie sah denn damals, vor dem high die situation aus ?
  h1=x$highs[1]
  frame=sprintf("::%s",h1)
  x=fast.smoothing(p[frame],glaettung = 10,visual=T)  #h�here Werte 2,3...machen alles glatter
  #schreite in der long-pos voran bis es zum stop kommt
  h1=h1+10
  frame=sprintf("::%s",h1)
  x=fast.smoothing(p[frame],glaettung = 10,visual=T)  #h�here Werte 2,3...machen alles 
  
  last.segment.start=last(x$hl[as.Date(x$hl)<as.Date(h1)])
  last.frame=sprintf("%s::%s",last.segment.start,h1)
  p.seg=p[last.frame]
  x.seg=x$smooth[last.frame]
  #lines(p.seg,col="green")
  #lines(x.seg,col="magenta")
  d.low=p.seg-x.seg; 
  d.low[d.low > 0]<-0
plot(d.low)
  #x.seg#die smooth  linie im lezten segment
  y2=rollapplyr(abs(d.low),30, roll.quantile, allPrices=abs(d.low),maxWin=shape(d.low),Q="99%" )
  plot(p.seg);lines(x.seg,col="magenta")
  lines(x.seg-y2,col="red")
plot(d.low)  
  
  
  layout(1:3)
  plot(p.seg)
  r=ROC(p.seg,1);r[1]<-0; r[r>0]<-0
  plot(r)  
  y=-runquantile(-r, 365, probs=c(   0.99))
  Y=r;Y[]=y
  lines(Y,col="red")
  
  r=ROC(p.seg,1);r[1]<-0; r[r<0]<-0
  plot(r)  
  y=runquantile(r, 365, probs=c(   0.99))
  Y=r;Y[]=y
  lines(Y,col="blue")
  
  
  n=5
  layout(1:3)
  plot(p.seg)
  r=ROC(p.seg,5);r[1]<-0; r[r>0]<-0
  plot(r)  
  y=-runquantile(-r, 365, probs=c(   0.99))
  Y=r;Y[]=y
  lines(Y,col="red")
  
  r=ROC(p.seg,5);r[1]<-0; r[r<0]<-0
  plot(r)  
  y=runquantile(r, 365, probs=c(   0.99))
  Y=r;Y[]=y
  lines(Y,col="blue")
  
  
ls(data$prices)
  
  n=20
  layout(1:3)
  plot(p.seg)
  r=ROC(p.seg,n);r[1]<-0; r[r>0]<-0
  plot(r)  
  y=-runquantile(-r, 250, probs=c(   0.99))
  Y=r;Y[]=y
  lines(Y,col="red")
  Ydown=Y
  
  r=ROC(p.seg,n);r[1]<-0; r[r<0]<-0
  plot(r)  
  y=runquantile(r, 250, probs=c(   0.99))
  Y=r;Y[]=y
  lines(Y,col="blue")
  Yup = Y
  
  YY=Yup+Ydown
  YY[is.na(YY)]<-0
  sig=sign(YY)
  plotSigPrice(sig, p.seg,main="DAX")

  
  if (F)
{
  y=runquantile(abs(d.low), 500, probs=c(    0.95, 0.99))
  
  stop.lines=merge(x.seg,x.seg); stop.lines[]=y[,1,c(1,2)]
  stop.lines[,1]= stop.lines[,1]
  stop.lines[,2]= stop.lines[,2]
  
  col = c(  "green", "blue")
  lines(-stop.lines[,1], col=col[1]) #runmean(y[,1,1],K)
  lines(-stop.lines[,2], col=col[2]) #runmean(y[,1,1],K)
} 
  
  
  
  #wahrscheinlich wird das sig im rollapplyr viel schlechter: 
  #aber mit zunehmender width auch besser (> 500)
  s = rollapplyr(p,FUN=function(x)fast.smoothing(x,glaettung=15,roll=T), width= 300,by.column=F)
  plot(p)
  lines(s,col="green",lwd=2)
  lines(x,col="red")
  lines(EMA(p,50),col="blue")
  sig=sign(ROC(s,n=20,type="continuous"))#einfach die tagesdiff der glatten kurve
  
  plot(p);lines(s,col="green");lines(x$smooth,col="red")
  lines(sig*3,col="green")
  
  frame=""
  ret= plotSigPrice(signal = sig[frame],prices=p[frame],indi=list(f=merge(p,s)))
  
}
##############################################################################################
#technischer signal-generator
#wie fast.smoothing - nur kann hier die Glaettungs-Funktion �bergeben werden
#entscheidungen k�nnen wahlweise getroffen werden 
#mit und ohne hysterese  (wahlweise statisch mit vorgestelltem # in q.w - oder rollierender schwellenermittlung)
#als cut (dw < 0) oder als richtungs-�nderung (dw >0)  - 
#als macd  eines gegl�etteten mit dem zus�tzlich gegl�tteten dw <0
#oder als macd eines geglaetteten mit einem andere geglaetteten
##############################################################################################
any.smoothing<-function(p,glaettung = 200,dw=1,visual=F,p0=NULL,roll=F,fn="EMA",fn2="SMA",glaettung2=40,onlyLong=T,q.w="")#q.w="#60%" oder q.w = "60%"
{
  
   mP("any.smoothing")
  #...... smoothing
  #aus dem r-cookbook
  p=na.omit(p[,1])
  
  t=c(1:nrow(p))
  fn=match.fun(fn)
  smooth <-fn(p,glaettung)
  #smooth <-ZLEMA(smooth,10)
  s=p;s[]=smooth
  
  
  #s2=SMA(s,40)  #falle es zu viele signale gibt, kann man mit fn2 auch noch mal eine zweite Glaettung durchf�hren
  s2=s
  #s[is.na(s)]<-first(na.omit(s))
  
  if (dw >0)  #kr�mmung der zweifach gegl�tteten
  {
    if (fn2 !="" && glaettung2 >= 1)
    { 
      fn2=match.fun(fn2)
      S2 <-fn2(na.omit(s),glaettung2)
      s2=merge(s,S2)[,2]
      #browser(mP("#2"))
      #s2[]=S2
      
      #s2[is.na(s2)]<-first(na.omit(s2))
    }
    else  
      s2=s
    decide = mROC(s2,n=dw,type="continuous")
    
    sig=sign(decide)#einfach die tagesdiff der glatten kurve
  }
  else
    if (dw <0) #schnittpunkt zwischen der einfach und der zweifach gel�tteten
    {
      if (fn2 !="" && glaettung2 >= 1)
      { 
        fn2=match.fun(fn2)
        S2 <-fn2(na.omit(s),glaettung2)
        s2=merge(s,S2)[,2]
        #s2[]=S2
        #s2[is.na(s2)]<-first(na.omit(s2))
      }
      else  s2=s
      #sig=sign(ROC(s2,n=dw,type="continuous"))#einfach die tagesdiff der glatten kurve
      decide = s - s2
      sig = sign(decide)
    }
  
  else #faber/macd: schnittpunkt mit preise oder einfach glatt1 mit glatt2
  {
    if (fn2 !="" && glaettung2 >= 1)
    {
      fn2=match.fun(fn2)
      S2 <-fn2(na.omit(p),glaettung2)
      s2=merge(s,S2)[,2]
      #s2=s
      #s2[]=S2
      #s2[is.na(s2)]<-first(na.omit(s2))
    }
    else 
      s2=p
    
    decide = s2 - s
    sig = sign(decide)
  }
  thresh=0
  
  offset.D=DateS(first(sig[!is.na(sig)]))
  
  if (q.w !="")  #hysterese - entscheid   #wenn vor q.w ein # wird das quantile statisch ermittelt
  {
    t.indi = decide
    # thresh=0.2
    #q.w="#60%"
    if (substr(q.w,1,1)=="#")
    {
      q.w=substr(q.w,2,10)
      thresh=quantile(abs(t.indi),probs=seq(0,1,0.01),na.rm=T)[q.w] #"60%"
    }
    else
    {
      #thresh.old=rollapplyr(abs(t.indi),20, roll.quantile, allPrices=abs(t.indi),maxWin=60,Q=q.w )
      
      # browser(mP("teste speedup von roll.quantile"))
      library(caTools)
      
      thresh=t.indi;
      S=seq(0,1,0.01)
      s.s=sapply(S,function(x)sprintf("%.0f%s",100*x,'%'))#%02.0f%s
      y= runquantile(coredata(abs(t.indi)), 60, probs=S,  align = "right")
      spalte=which(s.s==q.w)
      if (!len(spalte))
        sag("Mist - schreib q.w anders",T)
      #endrule=c("quantile", "NA", "trim", "keep", "constant", "func"),
      thresh[]=y[,1,spalte]
      #browser()      
      #plot(abs(t.indi))
      #plot(thresh)
      #lines(thresh.old,col="red")
      #plot(thresh2)
    }
    
    #hysterese schwelle 
    d.signal = iif(abs(t.indi)< thresh,NA, sign(t.indi))
    #damit nicht gleich das erste signal falsch ist
    d.signal[1] = sign(first(na.omit(diff(p,20))))
    #der auff�ller ...
    #browser(mP("head sig"))
    #head(sig)
    #bug 
    offset.D=DateS(first(sig[!is.na(sig)]))
    
    sig = as.xts(m.ifna.prev(d.signal)) ; sig[is.na(sig)]<-0
    sig[sprintf("::%s",offset.D)]<-NA   #stell den offset wieder auf NA 
  }
  
  #  sig = -sig.cut
  #browser()
  #amark (as.Date(index(sig[sig.cut != sig])))
  
  #View(merge(p,s,ROC(s,n=dw,type="continuous"),sign(ROC(s,n=dw,type="continuous")))["2005"])
  #sig[is.na(sig)] <- first(na.omit(sig))
  if (onlyLong)
    sig[sig <0]=0
  ##########################################################################
  
  
  sd = sig#sign(diff(sig))
  rS=runSum(na.omit(sd),n=2)
  #rS=lag(rS,-1)
  peaks <- p[ as.Date(index(rS[rS==0]))]
  
  if (len(peaks) < 2)
  {highx=p[1];lowx=p[1];}
  else
  {
    print(".")
    highx = peaks[peaks >= lag(peaks,1)]
    lowx = peaks[peaks < lag(peaks,1)]
    
    f=""
    if (F && visual) #zus�tzlicher Hilfsplot
    {
      plot(p[f])
      points(peaks[f])
      points(highx,col="blue",lwd=3)
      points(lowx,col="red",lwd=3)
    }
    
    highx=as.Date(index(highx))
    lowx=as.Date(index(lowx))
    peaks=as.Date(index(peaks))
    
  }  
  ##f�r eine visualisierung
  #
#   browser()
  Indi=list(f=merge(p,s,s2),d=merge(decide,0,thresh,-thresh))#,diff=merge(mROC(s2,7),mROC(s,7)))
  
  if (visual)
  {
    if(F)#zus�tzlicher Hilfsplot
    {
      plot(p);lines(s,col="red")
      lines(scaleTo(sig,range(p)),col="green")
      amark(peaks)
    }
    frame=""
    
    
    
    if (is.null(p0))
      ret= plotSigPrice(signal = sig[frame],prices=p[frame],indi=Indi)
    else
      ret= plotSigPrice(signal = sig[frame],prices=p[frame],indi=list(f=merge(p,ZLEMA(p,20),s, scaleTo(p0,range(na.omit(p))))))
  }
  
  if (nrow(s)!=nrow(p))
    browser(mP("bug"))
  
  if (roll)
    return(last(s))
  
  
  return(list(smooth = s,highs =lowx,lows = highx,hl=peaks ,sig=sig,indi=Indi))
  
}

if (F)
{
  
  x=any.smoothing(dax,glaettung = 200,dw=5,visual=T)
  x=indi.Generic("signal.Faber.base", global_arg, par=list(sma.w=300),visual=T, TRAINSYM ="DAX")
  
  x=indi.Generic("signal.Faber.base", global_arg, par=list(sma.w=300),visual=T, TRAINSYM =-1)
  
  x=any.smoothing(dax,glaettung = 300,dw=0,visual=T,fn="SMA",fn2="",glaettung2=0,onlyLong=T)
  
  x=indi.Generic("signal.any.smoothing", global_arg, par=list(glaettung=300,glaettung2=0,dw=0),xarg=list(fn="SMA",fn2="",,onlyLong=T,q.w=""),visual=T, TRAINSYM ="DAX")
  
  
  x=any.smoothing(dax,glaettung = 200,dw=1,visual=T,fn="ZLEMA",fn2="SMA",glaettung2=50,onlyLong=T)
  x=any.smoothing(dax,glaettung = 300,dw=1,visual=T,fn="EMA",fn2="SMA",glaettung2=0,onlyLong=T)
  
  x=any.smoothing(dax,glaettung = 200,dw=1,visual=T,fn="EMA",fn2="SMA",glaettung2=10,onlyLong=F)
  
  dax=dax["2003::"]
}


##############################################################################
##############################################################################

signal.any.smoothing <-function(arg, par = mlist( 
  glaettung=c(200,120,220,20),
  glaettung2=c(5,5,20,10),
  dw = c(-1,-1,1,1)
),visual=F,xarg=list(fn="SMA",fn2="",onlyLong=T,q.w=""),...)
{
  p=mNorm(arg$clos)[,1]
  
  res  =any.smoothing(p,glaettung = as.integer(par$glaettung),dw=as.integer(par$dw),visual=F,fn=xarg$fn,fn2=xarg$fn2,glaettung2=as.integer(par$glaettung2),onlyLong=xarg$onlyLong,q.w=xarg$q.w)
  
  #Q
  #browser(mP("signal.any.smoothing####"))  
  
  signal = res$sig
  Indi= res$indi
  
  return(list(Signal=signal, Indi=Indi))
}

if (F)
{
  x=indi.Generic("signal.any.smoothing", global_arg, par=list(glaettung=300,glaettung2=0,dw=0),xarg=list(fn="SMA",fn2="",onlyLong=T,q.w=""),visual=T, TRAINSYM ="DAX")
  
  x=indi.Generic("signal.Faber.base", global_arg, par=list(sma.w=300),visual=T, TRAINSYM =-1)
  
  x=any.smoothing(dax,glaettung = 300,dw=2,visual=T,fn="EMA",fn2="SMA",glaettung2=0,onlyLong=F)
  
  x=indi.Generic("signal.any.smoothing", global_arg, par=list(glaettung=300,glaettung2=10,dw=1),xarg=list(fn="EMA",fn2="",onlyLong=F,q.w="#1%"),visual=T, TRAINSYM =-1)
}
##############################################################################
##############################################################################
m.write.xls<-function(outData,xlsName="modelData.xls",sheetname="Ergebnisse")
{
  library(XLConnect)
  wb <- XLConnect::loadWorkbook(xlsName, create = TRUE)
  XLConnect::createSheet(wb, name = sheetname)
  ergebnisse = data.frame(outData)
  rownames(ergebnisse)=c(1:nrow(ergebnisse))
  
  XLConnect::writeWorksheet(wb, ergebnisse, sheet = sheetname,rownames="Number")
  XLConnect::saveWorkbook(wb)
}
if (F)
  m.write.xls(normP,"test2.xls","sheet")

#########################################################################


lm.FIT_<-function(Y) {x=as.matrix(c(1:shape(Y))); y=coredata(as.numeric(Y)); res=coef(lm(y~x))}
lm.FIT<-cmpfun(lm.FIT_)

if (F)
{
  slope200=lm.FIT(last(na.omit(p),200))[1]
  slope90=rollapplyr(p, 200, lm.FIT, by.column = F)
}




#Gewichtung gem. Abstand 
lm.FITmw_old<-function(Y) {x=c(1:shape(Y)); w = x/last(x); w=expm1(10*w); x=as.matrix(x); 
                        y=coredata(as.numeric(Y)); res=lm(y~x,weights=w)}

#################################################################################
#filter in dax alle MonatsEnden  -
#wenn ein monatsende auf ein Wochenende f�llt nimm den letzten arbeitstag.
#################################################################################
m.to.monthly<-function(dax)
{
  DateVector=as.Date(index(dax))
  head(DateVector)
  dm=Dates.month.ends(DateVector)
  
  #Problemf�lle wo monatsenden auf einem Wochenende liegen - das Monatsende darf aber nicht einfach fehlen - statt dessen muss dann der letzte businessday des Monats erscheinen 
  we=dm[is.weekend(dm)]
  #alle Wochentage
  bd=DateVector[!is.weekend(DateVector)]
  datePreWE=
    sapply(we,function(x) {preWE=bd[as.Date(bd)<as.Date(x)];dax.preWE=DateS(last(dax[preWE]))})
  #alle monatsenden die nicht auf ein wochenende fallen
  dm=dm[!is.weekend(dm)]
  #f�r die monatsenden die auf ein Wochenende fallen werden die Vorg�nger businessdays hinzugef�gt
  all.dm = sort(as.Date(append(as.character(dm),as.character(datePreWE))))
  dax[all.dm]
}

m.to.daily<-function(dax)
{
  dm=as.Date(index(dax))
  return(dax[!is.weekend(dm)])
}
####################################################################
lm.FITmw_<-function(p,visual=F,getIndex=F)
{
  firstDate=DateS(first(p))
  
  if (!getIndex)
     xdat=x=1:shape(p) 
  else
  {
    xdat=as.Date(as.Date(index(first(p))):as.Date(index(last(p))))
    xdat.Lineal=xts(1:len(xdat), xdat)
    xdat= get.Index(xdat.Lineal, as.Date(index(p)),lineal=T)
    x=xdat
  }
  w = x/last(x); w=expm1(10*w);
  train <- data.frame(x=x, y=coredata(head(p,shape(p))))  
  colnames(train) = c("x","y")
  mod= lm(y ~ x, train,weights=w)

  if (!visual) return(mod)
  
  n=shape(p)
  
  x=predict(mod,newdata=data.frame(x=xdat))#,interval="prediction")#,level=c(80,90))
  #x=  bt.apply.matrix(x,function(x) iif(x<0,0,x))
  
  nplus=n*2
  pre = xts(1:nplus, as.Date(firstDate)+0:(nplus-1));  
  pre = head(pre[!is.weekend(time(pre))],n)
  
  pre=merge(pre,pre,pre)
  pre[]=x
  mchart(merge(pre,p))
  points(p)
  
  
  mod
  
}

lm.FITmw<-cmpfun(lm.FITmw_)
#####################################################################

lm.FITm_<-function(p,visual=F,getIndex=F)
{
 # browser(mP("lm.FITm"))
  p.org=p  #p.org enth�lt keine Wochenenden, somit 604 tage
  firstDate=DateS(first(p))
  p=(as.numeric(p))
  

  xdat=c(1:shape(p))
  if (!getIndex)
     train <- data.frame(x=1:shape(p), y=coredata(p))  
  else
  { 
   # browser(mP("lm.Fitm"))
    #if (F)
    #   lm.FITm(upper,getIndex=T)
    #hier liegen die x nicht dicht .. also muss man spreizen
    xdat=as.Date(as.Date(index(first(p.org))):as.Date(index(last(p.org))))
    xdat.Lineal=xts(1:len(xdat), xdat)
    
    xdat= get.Index(xdat.Lineal, as.Date(index(p.org)),lineal=T)
    train <- data.frame(x=xdat, y=coredata(p))  
  }
  colnames(train) = c("x","y")
  
  mod = lm(y~x, data=train)
  
  if (!visual) return(mod)
  
  n=shape(p)
  x=predict(mod,newdata=data.frame(x=xdat),interval="prediction")#,level=c(80,90))
  x=  bt.apply.matrix(x,function(x) iif(x<0,0,x))
  
  nplus=n*2
  pre = xts(1:nplus, as.Date(firstDate)+0:(nplus-1));  
  pre = head(pre[!is.weekend(time(pre))],n)
  
  pre=merge(p.org,p.org,p.org)
  pre[]=x
  mchart(merge(pre,p))
  points(p.org)
  
  mod
  
}
lm.FITm<-cmpfun(lm.FITm_) #compilier das Teil

############################################################################

############################################################################
lm.lowess_<-function(p,visual=F,getIndex=F,main="lowess")
{
  p.org=p  #p.org enth�lt keine Wochenenden, somit 604 tage
  firstDate=DateS(first(p))
  p=(as.numeric(p))
  
  if (!getIndex)
    train <- data.frame(x=1:shape(p), y=coredata(p))  
  else
  { 
    # browser(mP("lm.Fitm"))
    #if (F)
    #   lm.FITm(upper,getIndex=T)
    #hier liegen die x nicht dicht .. also muss man spreizen
    xdat=as.Date(as.Date(index(first(p.org))):as.Date(index(last(p.org))))
    xdat.Lineal=xts(1:len(xdat), xdat)
    xdat= get.Index(xdat.Lineal, as.Date(index(p.org)),lineal=T)
    train <- data.frame(x=xdat, y=coredata(p))  
  }
  colnames(train) = c("x","y")
  lowe=lowess(y~x,data=train) # und damit dann die Quantile machen ...

  if (visual)
  {
    p.o=p.org; p.o[]=lowe$y
    #plot(p.org,main=main); 
    points(p.org,col="blue")    
    lines(p.o,col="red",lwd=2)
  }
  return(lowe)
}
lm.lowess<-cmpfun(lm.lowess_) #compilier das Teil

###################################################################
#gib model, p.value,r.squared  zur�ck
#w=T heisst weighted .. j�ngere Werte sind dann wichtiger
####################################################################
m.lm.fit<-function(p,visual=F,getIndex=F,w ="")
{
browser(mP("m.lm.fit"))
  if (len(p)<2)
    {res = list(fit=NA, m=NA, b= NA,r.squared=NA,p.value=NA)
      return(res)
    }
  if (w == "lowess")
  {
    res = list(fit=NA, m=NA, b= NA,r.squared=NA,p.value=NA)
    A=lm.lowess(p,visual=visual,getIndex=getIndex)
    x2=shape(A)
    res$m=(A$y[x2]-A$y[x2-1]) / (A$x[x2]-A$x[x2-1])
    res$xy = A
    return(res)
  }
  else
  if (w=="")
    fit=lm.FITm(p ,visual=visual,getIndex=getIndex) 
  else
    if (w=="lm.w")
       fit=lm.FITmw( p ,visual=visual,getIndex=getIndex)
     else
        sag("Wrong usage of m.lm.fit - unknown w %s",as.character(w),warte=T)
  
  fit.m= coef(fit)[2]
  r.squared=summary(fit)$r.squared
  fstatistic=summary(fit)$fstatistic
  p.value=pf(fstatistic[1], fstatistic[2], fstatistic[3],   lower.tail = FALSE)

  res = list(fit=fit, m=fit.m, b= coef(fit)[1],r.squared=r.squared,p.value=p.value)
  
  if (visual)
    print(res)
  res
}

#lm.FITm_<-function(Y) {x=as.matrix(c(1:shape(Y))); y=coredata(as.numeric(Y)); res=lm(y~x)}
#lm.FITm<-cmpfun(lm.FITm_)

m.predict<-function(lm.mod,firstDate="2012-01-03",n=10,y=NULL,interval="prediction",visual =F)#confidence)
{
  if (!is.null(y))
  {
    firstDate=DateS(first(y))
    y=(as.numeric(y))  #entscheident
    n=shape(y)+n
  }
  
  x=predict(lm.mod,newdata=data.frame(x=1:n),interval="prediction")#,level=c(80,90))
  x=  bt.apply.matrix(x,function(x) iif(x<0,0,x))
  
  
  nplus=n*2
  pre = xts(1:nplus, as.Date(firstDate)+0:(nplus-1));  
  pre = head(pre[!is.weekend(time(pre))],n)
  
  pre=merge(pre,pre,pre)
  pre[]=x
  
  if (visual && !is.null(y))
  {
    pre=merge(pre,y)
    mchart(pre,p)
    
  }
  return (pre)
  
  
  
  pre = xts(1:n, as.Date(firstDate)+0:(n-1))
  
  pre=merge(pre,pre,pre) ; 
  
  pre[]=predict(lm.mod,data.frame(x=1:n),interval =interval)# "confidence") #"prediction"
  
  pre=  bt.apply.matrix(pre,function(x) iif(x<0,0,x))
  pre
  
  
}





#What are the functions that you wrote, don't quite deserve a package, but you wish to share?
setdiff2 <- function(x,y) {
  #returns a list of the elements of x that are not in y 
  #and the elements of y that are not in x (not the same thing...)
  
  Xdiff = setdiff(x,y)
  Ydiff = setdiff(y,x)
  list(X_not_in_Y=Xdiff, Y_not_in_X=Ydiff)
}


#In the most useful R trick posting I saw a post by Keving from Nov 3 '09 bout dropping unused levels. The first function was provided there. and I took the best step in the second function to drop levels from a subset.

drop.levels <- function (dat) {if (is.factor(dat)) dat <- dat[, drop = TRUE] else dat[] <- lapply(dat, function(x) x[, drop = TRUE]); return(dat) ;};

subset.d    <- function (...) drop.levels(subset(...)); # function to drop levels of su


#I will throw in some of mine:

destring <- function(x) {
  ## convert factor to strings
  if (is.character(x)) {
    as.numeric(x)
  } else if (is.factor(x)) {
    as.numeric(levels(x))[x]
  } else if (is.numeric(x)) {
    x
  } else {
    stop("could not convert to numeric")
  }
}

pad0 <- function(x,mx=NULL,fill=0) {
  ## pad numeric vars to strings of specified size
  lx <- nchar(as.character(x))
  mx.calc <- max(lx,na.rm=TRUE)
  if (!is.null(mx)) {
    if (mx<mx.calc) {
      stop("number of maxchar is too small")
    }
  } else {
    mx <- mx.calc
  }
  px <- mx-lx
  paste(sapply(px,function(x) paste(rep(fill,x),collapse="")),x,sep="")
}
###############################################################

.eval <- function(evaltext,envir=sys.frame()) {
  ## evaluate a string as R code
  eval(parse(text=evaltext), envir=envir)
}


#######################################################################
# Gets the frequencies returned by the FFT function
getFFTFreqs <- function(Nyq.Freq, data)
{
  if ((length(data) %% 2) == 1) # Odd number of samples
  {
    FFTFreqs <- c(seq(0, Nyq.Freq, length.out=(length(data)+1)/2), 
                  seq(-Nyq.Freq, 0, length.out=(length(data)-1)/2))
  }
  else # Even number
  {
    FFTFreqs <- c(seq(0, Nyq.Freq, length.out=length(data)/2), 
                  seq(-Nyq.Freq, 0, length.out=length(data)/2))
  }
  
  return (FFTFreqs)
}

# FFT plot
# Params:
# x,y -> the data for which we want to plot the FFT 
# samplingFreq -> the sampling frequency
# shadeNyq -> if true the region in [0;Nyquist frequency] will be shaded
# showPeriod -> if true the period will be shown on the top
# Returns a list with:
# freq -> the frequencies
# FFT -> the FFT values
# modFFT -> the modulus of the FFT
plotFFT <- function(x, y, samplingFreq, shadeNyq=TRUE, showPeriod = TRUE)
{
  Nyq.Freq <- samplingFreq/2
  FFTFreqs <- getFFTFreqs(Nyq.Freq, y)
  
  FFT <- fft(y)
  modFFT <- Mod(FFT)
  FFTdata <- cbind(FFTFreqs, modFFT)
  plot(FFTdata[1:nrow(FFTdata)/2,], t="l", pch=20, lwd=2, cex=0.8, main="",
       xlab="Frequency (Hz)", ylab="Power")
  if (showPeriod == TRUE)
  {
    # Period axis on top        
    a <- axis(3, lty=0, labels=FALSE)
    axis(3, cex.axis=0.6, labels=format(1/a, digits=2), at=a)
  }
  if (shadeNyq == TRUE)
  {
    # Gray out lower frequencies
    rect(0, 0, 2/max(x), max(FFTdata[,2])*2, col="gray", density=30)
  }
  
  ret <- list("freq"=FFTFreqs, "FFT"=FFT, "modFFT"=modFFT)
  return (ret)
}

#As an example you can try this

# A sum of 3 sine waves + noise
if (F)
{
  x <- seq(0, 8*pi, 0.01)
  sine <- sin(2*pi*5*x) + 0.5 * sin(2*pi*12*x) + 0.1*sin(2*pi*20*x) + 1.5*runif(length(x))
  par(mfrow=c(2,1))
  plot(x, sine, "l")
  res <- plotFFT(x, sine, 100)
  #class(sine)
  #or
  
  plot(dax)
  res <-plotFFT(1:len(dax),diff(log(coredata(dax[frame]))),100)
  frame="::1995"
  m=2
  y=na.omit(coredata(SMA(dax[frame],m)))
  res <-plotFFT(1:y,y,100)
  frame="1999:2000"
  res <-plotFFT(1:len(dax),coredata(dax[frame]),100)
  frame="::1995"
  res <-plotFFT(1:len(dax),coredata(dax[frame]),100)
  
  
  
  
  linearChirp <- function(fr=0.01, k=0.01, len=100, samplingFreq=100)
  {
    x <- seq(0, len, 1/samplingFreq)
    chirp <- sin(2*pi*(fr+k/2*x)*x) 
    
    ret <- list("x"=x, "y"=chirp)
    return(ret)
  }
  
  chirp <- linearChirp(1, .02, 100, 500)
  par(mfrow=c(2,1))
  plot(chirp, t="l")
  res <- plotFFT(chirp$x, chirp$y, 500, xlim=c(0, 4))
}

######################################################################################################
# kleine hilfsmethode:  zeigt alle elemente einer liste an, und wartet nach jedem auf tastendruck
#sehr gut um z.B. sysinvestor-modelle anzusehen
######################################################################################################

inspect<-function(mod)
{
  lapply(names(mod),function(x){mP("###### >> vari %s",x);print(mod[[x]]); print(str(mod[[x]])); mP("###### << vari %s",x);browser()})
}

####################################################################
#baut ein sch�n benamste Liste  mit l.red=l.red,  l.orange=l.orange...
#mkList(l.red,l.orange,l.magenta,m.red,m.orange,m.magenta,sig.red,sig.orange,sig.magenta,sig.sum, d.red,dm.red, dp.red)
#####################################################################
mkList<-function(...)
{
  res =list()
  args=list(...)
  arg.names <- as.list(substitute(list(...)))  
  for(i in 2:len(arg.names))
  {
    list.nam=as.character(arg.names[[i]])
    list.val=args[[i-1]]
    res[[list.nam]]=list.val
  }  
  res
}

mkTable<-function(...)
{
 # mlist=list(list(a=3,b=5))
  mlist=list(mkList(...))
  res.l=data.frame(rbindlist(mlist))
}
####### man kann einfach beliebige Variablen �bergeben.. die werden zu einer Tabelle
appendTable<-function(tabName,...)
{
tabName <- deparse(substitute(tabName))

if (exists(tabName) || is.null(tabName))
   eval(parse(text=sprintf("%s<<-rbind(%s,mkTable(...))",tabName,tabName)))
else 
   eval(parse(text=sprintf("%s<<-mkTable(...)",tabName)))
}


if (F)
{
a=3
b=4
x112=mkTable(a,b)
rbind(x111,x112)
appendTable(t1Result, a,b)
}
#########################################################################

find.wlen_<-function(p,target.range=3)  #vorsicht - nimm lieber find.Wlen()
{
  l=len(p)
  res =l
  for(w in 2:l)
  {       
    rag=range(p[(l-w):l])
    #rg=diff(rag)/rag[1]*100
    rg = diff(rag)
    # mP("%d %f  %f",w, diff(rag),rg)
    if (rg >= target.range)
    {res=max(1,w-1); break}
  }
  #  res = as.xts(as.numeric(res),order.by=as.Date(index(last(p))))
  return(res)
}
find.wlen<-cmpfun(find.wlen_) #compilier das Teil
###########################################################################
###########################################################################

get_rob<-function(p,iw=11,ow=110)
{
  library(robfilter)
  #y=Cl(p);newXts=Cl(p)
  y=coredata(p)[,1]
  # Filtering with all methods:
  #y.dw <- dw.filter(y,online=T, outer.width=31, inner.width=11, method="all")
  # Plot:
  #browser(mP("get_rob"))
  #plot(y.dw)
  #coole-online-filter 
  # Filtering with trimmed RM and double window TRM only:
  y2.dw <- dw.filter(y, online=T,outer.width=ow, inner.width=iw, method=spl("MED,RM,MTM,TRM,DWMTM,DWTRM"))
  #Auf dem DWMTM sollte man mom(3) ganz guten Trend-Detektor bauen (geringe Werte)
  #stehe dann f�r horizontale St�cke
  #der RM ist schnell und glatt genug - und schneidet den langsamen MTM
  #ein signal ist aber nur dan, wenn der DWMTM nicht horizontal ist.
  
  #tail(y2.dw$slope)
  #tail(y2.dw$level)
  
  newXts=xts(y2.dw$level, index(p))
  newXts.slope=xts(y2.dw$slope, index(p))
  #browser()  
  ind= merge(p,newXts,SMA(p,200))
  # mchart(ind)
  purePlot(na.omit(ind))
  #mPlots(ind)
  #mchart(ind)
  #lines(SMA(p,200),lwd=2)
  #die DWMTM haben nur 1 bis 2 Tage delay
  #apply(ind,2,function(indi) which(indi==min(indi))) #3Tage Delay!!!
  list(filter=newXts, slope=newXts.slope) 
}

if (F)
  res =get_rob(dax,ow=220)


########################################################################## 
#4 klarer Cut  (auch ein Vorg�ngerTag war schon mindestes bei 3) 
#......................  3  in der Touchier-Zone (cut)
#2   overbought
#1
#...................     0
#-1
#-2 oversold
#.......................-3  in der Touchier Zone (cut)
#-4  klare Cut (auch ein Vorg�nger Tag war schon bei mindestens -3)
########################################################################## 
#Moving Window Quantiles (smoothed %s %d)
# wenn opt.getQ == get.Quantile.M - werden sign der quantil-Steigerungen zurr�ckgegeben
# wenn opt.getQ == 2 - obere und untere Kan�le linear gefitted

in.Trend.pos_<-function( p, up.low = NULL,date=NULL,visual=F,main="",last=F,opt.getQ="get.Quantile.M",k=160) #mid,low,up
{
  P=NULL
  name <- deparse(substitute(p)) 
  if (F)
    if (name=="itp.dp.red" && DateS(last(p))=="2004-03-03") #TEST
      browser(mP("in.Trend.pos - TEST"))
  #browser(mP("in.Trend.pos - TEST"))
  
  if (is.null(date))
  {
    if (is.null(up.low)) #kein Kanal gegeben - nimm einfach die Quantile
    {
      k=min(shape(p),k);  #das moving-window in dem quantile gez�hlt werden 
      K=50
      x=coredata(p)
      y=runquantile(x, k, probs=c(0.05,  0.5,  0.95))
      
      up.low=merge(p,p,p)
      up.low[,2]=runmean(y[,1,1],K)
      up.low[,1]=runmean(y[,1,2],K)
      up.low[,3]=runmean(y[,1,3],K)
      mid=up.low[,1]
      low= up.low[,2]
      up=up.low[,3]  
      sig = iif(p>=mid,1,-1)
      res = iif (sig >=0, round((p-mid)/((up-mid)/3)), round((p-mid)/((mid-low)/3)))
      if (visual)
      {
        col = c( "red", "green", "blue")        
        plot(x, col="black", main = sprintf("in.Trend.Pos(%s,%s smoothed %d)",name,main,K))
        lines(runmean(y[,1,1],K), col=col[1])
        lines(runmean(y[,1,2],K), col=col[2])
        lines(runmean(y[,1,3],K), col=col[3])
        abline(h=last(x),lwd=3)
      }
      if(last)
        res = last(res)
      if (visual)mP("in.Trend.Pos %s %s %f",main,name,res)
      
      if (opt.getQ == "get.Quantile.M") #gib zus�tzlich die groben Steigungen der einh�llenden Quantile zur�ck
      {
         #tlen=shape(na.omit(mid))
        Q.m =Q.m=merge(m.mid=m.sig(mid,tlen=k),m.low=m.sig(low,tlen=k),m.up=m.sig(up,tlen=k))
        if (last)
          Q.m=merge(m.mid=last(m.sig(mid,tlen=k)),m.low=last(m.sig(low,tlen=k)),m.up=last(m.sig(up,tlen=k)))
        return(list(itp=res, Q.m=Q.m ))
      }
      return(res)  
      
    }
    else
    {
      #if (shape(p) > 1) browser(mP("roll in.Trend.Pos"))
      res= rollapplyr(as.Date(index(p)),FUN=function(date) in.Trend.pos(p,up.low,date=date),width=1)
      res.1=p[,1];  res.1[]=res
    }
    return(res.1)
  }
  else
  {
    if (is.null(up.low))
    {
      P=last(p) #der aktuelle Kurs
      date=as.Date(index(P))
      #browser(mP("itp"))
      k=min(shape(p),k);  #das moving-window in dem quantile gez�hlt werden  
      K=3
      x=coredata(p)
      y=runquantile(x, k, probs=c(0.05,  0.5,  0.95))
      
      up.low=merge(P,P,P)
      up.low[,2]=last(runmean(y[,1,1],K))
      up.low[,1]=last(runmean(y[,1,2],K))
      up.low[,3]=last(runmean(y[,1,3],K))
      sig = iif(p>=mid,1,-1)
      res = iif (sig >=0, round((P-mid)/((up-mid)/3)), round((P-mid)/((mid-low)/3)))
      if (visual)
      {
        col = c( "red", "green", "blue")
        
        plot(x, col="black", main =sprintf("2in.Trend.Pos(%s ,%s smoothed %d)",name,main,K))
        lines(runmean(y[,1,1],K), col=col[1])
        lines(runmean(y[,1,2],K), col=col[2])
        lines(runmean(y[,1,3],K), col=col[3])
        abline(h=last(x),lwd=3)
      }
      
      if (visual) mP("2in.Trend.Pos %s %s %f",main,name,res)
      return(res)
    }
    
{
  # browser(mP("itp"))
  P=nval(p[date]) #der aktuelle Kurs
  up=nval(up.low[date,3])
  low=nval(up.low[date,2])
  mid=nval(up.low[date,1])
  if (is.na(P) || is.na(up) || is.na(low) || is.na(mid))
    return(NA)
}
    
    sig = ifelse(P>=mid,1,-1)
    if (sig >=0)
    {
      d=(up-mid)/3
      res = round((P-mid)/d)
    }
    else
    {
      d=(mid-low)/3
      res = round((P-mid)/d)
    }
    
    #browser(mP("in.Trend.pos %d",res))
    if (visual)mP("3in.Trend.Pos %s %f",name,res)
    
    res
  }
}
in.Trend.pos<-cmpfun(in.Trend.pos_) #compilier das Teil

#####################################################################
#kleines schiebregister - nimmt tlen werte auf und entfernt ab dann
#den �ltesten wert.
#entweder als vector .. oder als xts (wenn new.xts ein xts ist)
#####################################################################
pipe.xts_<-function( new.xts,old.xts=NULL, tlen=10)
{
if (shape(new.xts)==1 && is.na(new.xts)) #keine na aufnehmen
  return(old.xts)

new.xts=tail(new.xts,tlen)  #neuere Werte passen eh nicht rein
   

  if (is.null(old.xts))
  {  if (is.xts(new.xts))
    res = new.xts
     else
       res = c(new.xts)
  }
  if (is.xts(new.xts))
    res=rbind(old.xts,new.xts)
  else
    res=c(old.xts,new.xts)
  
  if (shape(res)>tlen)
    res = res[-1]
#  browser(mP("pipe.xts"))
  res
}
pipe.xts<-cmpfun(pipe.xts_) #compilier das Teil
#............................................
if (F)
{
  pipe=NULL
  k=  last(dax,10)
  for(i in 1:len(k))
  {
    nv=  nval(k[i])
    nv = k[i]
    pipe=  pipe.xts(nv,pipe,3)
  }
}

######################################################################
#er schreibt eine pipe in  die Globale:   itp.PIPES$<nameOf(new.xts)>
#als r�ckgabewert gibt er - sobald die pipe voll ist - die inTrendPos()
#zur�ck .. bezogen auf die Top,Low-Quantile der vergangenen Werte.
# er sagt einem also, ob der neue Wert zu den alten Werten passt... -
# oberhalb oder unterhalb der Mitte ist - oder aus dem Rahmen f�llt (>abs(3))
######################################################################
itp.pipe<-function( new.xts, tlen=10,visual=T,last=T,opt.getQ="")
{
  name=name = deparse(substitute(new.xts))
  
  if (!is.xts(new.xts))
     sag(sprintf("itp.pipe-Warning - no xts at %s",name),warte=T)
    
  name=name = deparse(substitute(new.xts))

  if (!exists("itp.PIPES"))
     itp.PIPES<<-list()

#pipe.name=sprintf("itp.PIPES%s%s","$",name)
if (len(itp.PIPES[[name]]) <1)
  itp.PIPES[[name]]<<-NULL

  if (last)
  new.xts=last(new.xts)
  
  
s=itp.PIPES[[name]] <<- pipe.xts(new.xts,itp.PIPES[[name]],tlen)
#s = pipe.xts(new.xts,old.xts,tlen)
if (shape(s)<tlen) return(NA)  

if (!is.xts(s))
{
   mP("itp.pipe-Warning - no xts at %s",name)
    s=xts(s,Sys.Date()+1:len(s))
}
# browser(mP("itp.pipe-TEST1 %s",name))
itp.s= in.Trend.pos(s,visual=visual,main=sprintf("itp.pipe %s %d",name,tlen),last=last,opt.getQ=opt.getQ)
  
if (visual)
  browser(mP("itp.pipe-TEST1 %s",name))
if (last && opt.getQ =="") return(last(itp.s))
itp.s
}

#............................................
if (F)
{
  itp.PIPES<<-list()
  itp.PIPES$nv=NULL
  names(itp.PIPES)
  
  k=  last(dax,100)
  for(i in 1:len(k))
  {
    nv=  nval(k[i])
    nv = k[i]
    itp=  itp.pipe(nv,30)
    mP("itp %d = %f",i,itp)
    if (i> 30)
      browser(mP("check"))
  }
}
########################################################################
#mit Returns ansteuern
#Alternative
#chart.Correlation(ROC(euro.indi["2010::2014"],30),main="2010::2014") 

#correlogramm(ROC(euro.indi["1997::"],30),main=" euro.indi")

#########################################################################
correlogramm<- function(xts.data,main = "")
{
  #delete missing data which is denoted by -0.9999
  xts.data[which(xts.data < -0.99,arr.ind=TRUE)[,1],
           unique(which(xts.data < -0.99,arr.ind=TRUE)[,2])] <- 0
  
  #get a vector of the end of years
  evaldates <- endpoints(xts.data,"years")
  
  for(i in 2:length(evaldates)) {  
    #do correlation table
    ca <- cor(xts.data[evaldates[i-1]:evaldates[i],])
    
    #replace na with 0
    ca[which(is.na(ca),arr.ind=TRUE)[,]] <- 0
    
    #get colors to use for heat map
    brew <- brewer.pal(name="RdBu",n=5)
    #get color ramp
    cc.brew <- colorRampPalette(brew)
    #apply color ramp
    cc <- cc.brew(nrow(ca))
    #do heatmap and sort by degree of correlation to VFINX (Vanguard S&P 500)
    #heatmap(ca,symm=TRUE,Rowv=NA,Colv=NA,col=cc,RowSideColors=cc,main="")
    #title(main=paste("Correlation Table\n",index(french_industry_xts)[evaldates[i]],sep=""),font.main=1,outer=TRUE,line=-2,cex.main=1.3)
    #do with dendrogram ordering
    heatmap(ca,symm=TRUE,col=cc,RowSideColors=cc,main="")
    title(main=paste("Correlation Table (Dendrogram Ordered)\n",index(xts.data)[evaldates[i]],main,sep=""),font.main=1,outer=TRUE,line=-3,cex.main=1.3,adj=0)  
  }
}


################################################################################################################
#damit kann ich Eckhards xls-Sheets  jeweils in ein xts einlesen
################################################################################################################
read.EckhardsXLS <-function( modelDir="EM4_November", xlsName="EuropeMM.xls",sheet.i = 1,startRow=14,belowColnames=1,visual=T,debug=F,dec=",",date.format="%d.%m.%Y",to.month.end=F)
{
  #startRow=startRow-1
  #Beispiel:  Einlesen von xls-File#######################
  library(XLConnect)
  
  dataPath =sprintf("Models/%s",modelDir) #da liegen die xls-files
  mP("read at path %s",dataPath)
  #F�r alle xls-Files
  xlsPat = glob2rx("*.xls") #wildcard-Transfer
  
  for (xlsfile in 
       dir(path = dataPath, pattern = xlsPat, all.files = T,
           full.names = F, recursive = FALSE,
           ignore.case = FALSE, include.dirs = FALSE)
  )
    print(xlsfile)
  
  
  
  #ueberlies die ersten 5 Zeilen
  xlsfile=sprintf("%s/%s",dataPath,xlsName)  #TEST
  
  mP("read: %s",xlsfile)
  bm <- readWorksheetFromFile(xlsfile, sheet=sheet.i, startRow=startRow, header=F)
  print(head(bm))
  bm2=bm
  #Gib der ersten Spalte einen anderen Namen:   "Index"
  print("#############################################")  
  newColnames=head(bm2,1) #TEST
  
  print(newColnames)
  mP("<<<- newColnames")
  #newColnames[5]
  if (belowColnames>0)
    bm2=bm2[c(-1:- belowColnames),]
  
  b.test=min(10,len(newColnames))
  print("first colnames")
  print(newColnames[1:b.test])
  print("first datarow")
  print(head(bm2[,c(1:b.test)],1))
  
  #finde die erste Spalte in der wirklich das Datum steht - also die vorletzte die keinen Col-Bezeichner hat .. (Eckhards-format ...?)
  firstCol  = 0
  for  (cN in 1:len(colnames(bm2)))  
  {
    #if (substr(cN, 1, 3) == "Col" && !isEmptyCol(bm2,cN))
    if (!isEmptyCol(bm2,cN))
    { firstCol = firstCol+1
      break
    }
  }
  mP("%s first Column has Date at Col Nr %d", xlsfile ,firstCol)
  print(head(bm2[,firstCol]))
  if (debug)
    browser()
  gesamt.xts = NULL
  
  for ( i in (firstCol+1): dim(bm2)[2])   #firstCol zeigt auf die  Datum-Spalte
  {
    if (!isEmptyCol(bm2,colnames(bm2[i])))
    {
      #i=firstCol+1 #TEST
      #erzeuge einen 2 Spalen-Tabelle
      #mP(" use Col  %d",i)
      bm3 = na.omit(bm2[,c(firstCol,i)])
      
      if (!is.null(bm3))  #MM1
        if ( dim(bm3)[1] > 0)
        {
          #hol den wpNamen als Namen der Spalte 2
          
          wpName0 = as.character(newColnames[i])  #colnames(bm3)[2] 
          wpName = prettyWpName(wpName0)
          if (debug)
            browser(mP("debug column %s",wpName))
          #umtauschen von  , in . und umwandeln des datums in standardformta
          if (date.format == "%b %y")
            normDate=strptime(paste("01",trim(c(bm3[,1]))),"%d %b %y")
          else
            normDate=strptime(trim(c(bm3[,1])),date.format)
          
          if (is.na(normDate[1]))
          {
            sag("unknow-Date-Format ",warte=F)
            browser(mP("#!# press key"))
          }
          
          if (dec == ",")
            bm3.xts=xts(as.numeric(gsub( ",", ".",bm3[,2],fixed=TRUE)),as.Date(normDate))  
          else
            bm3.xts=xts(as.numeric(bm3[,2]),as.Date(strptime(normDate)))
          
          
          #umsetzen der dat�mer aufs montasenden
          if (to.month.end)
            bm3.xts=xts( coredata(bm3.xts),Dates.month.ends(as.Date(index(bm3.xts))))
          colnames(bm3.xts) = c(wpName)
          bm3 = bm3.xts
          if (is.null(gesamt.xts))
            gesamt.xts = bm3
          else
            gesamt.xts = merge(gesamt.xts,bm3)
        }
    }
  }
  
  mP(".... gesamt.xts ist fertig")
  
  if (visual)
  {
    View(gesamt.xts)
    colnames(gesamt.xts)
    print(fromToS(gesamt.xts))
    purePlot(gesamt.xts)
  }
  gesamt.xts
}
#...................................................................................................................
if (F)
{
  #einlesen von xls -sheets in xts- variable
  euro.macros= read.EckhardsXLS(xlsName="EuropeMM.xls",startRow=15,date.format = "%b %y",to.month.end=T,debug=F)
  euro.indi= read.EckhardsXLS(xlsName="Index01.xls",startRow=5,belowColnames=5,debug=F)
  
  if (F)  #ist viel Schrott in den Spalten ?
  {
    colSums(diff(euro.macros["1997::"],30),na.rm=T)
    colSums(euro.macros["1997::"],na.rm=T)
    colSums(ROC(euro.indi["1997::"],30),na.rm=T)
    colnames(euro.macros)
  }
  
  euro.macros.n= mNorm(lag(euro.macros))["1997::"] #hier schon mal gelagged weil die Teile ja einen Monat Lieferversp�tung haben
  euro.indi.n = mNorm(euro.indi)["1997::"] #wichtig:  die Anfangslag normiert die (fr�hen) Werte
  
  purePlot(ROC(euro.macros["1997::"],1),main="roc 1 euro.macros")  #kaum was zu sehen
  purePlot(ROC(euro.macros["1997::"],30),main="roc 30 euro.macros")  #starke vola-cluster
  purePlot(ROC(euro.indi["1997::"],30),main="roc 30 euro.indi")
  
}
#########################################################################

source("MLib/CustomerReport.r")
source("MLib/Gui.r")
source("MLib/attention.r")
print("########### load InputConfig_Portfolio_TD.R")

if (F)
  list_R_functions('MLib/InputConfig_Portfolio_TD.R')
