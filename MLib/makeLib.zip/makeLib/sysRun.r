####################################################################################
#####################################################################################
options(error = quote({
  #  sink(file="error.txt");
  dump.frames();
  print(attr(last.dump,"error.message"));
  traceback();
  #  sink();
}))

options(warn=1)

##################################################################################


sys.Run<-function(prices,signal, compare=F, viewLevel=spl("portfolio,timingsys"),main="",hilfs.Indi=NULL,stopSys="",nTop=1,safe="",experiment="",signal.fun="model",data=NULL,T.arg=list(),S.arg=list(),A.arg=list())
{
  prices=na.omit(prices)
  n=dim(prices)[2] #anzahl der Wertpapiere
  if (!exists("global_commission"))
    global_commission <<- 0.00001
  
  if (len(A.arg$commission))
    commission = A.arg$commission
  else
   commission =   list(cps = 0.1, fixed = 0.0, percentage = global_commission)
  #commission=global_commission
  n.vol = 60 # (offsetage)
  nsym = ncol(signal)
  n.top= round(nsym/nTop)
  k.top=n.top
  
  capital=100000
  models = list()
  period = "months"
  month.ends = endpoints(prices, 'months')
  month.ends = month.ends[month.ends > 0]    
  week.ends = endpoints(prices, 'weeks')
  week.ends = week.ends[week.ends > 0]    
  
  if (period == "months")
  {
    period.annual.factor=12
    period.ends = month.ends  
  }
  else
    if( period == "weeks")
    {
      period.annual.factor=54
      period.ends = week.ends  
    }
  
  if (is.null(data) || !contains(viewLevel,"portfolio"))
  {
    #mP("no data given")
    mdata = list()
    mdata$prices = prices
    mdata$symbolnames = pureColnames(prices)
    mdata$weight = prices; mdata$weight[]=NA
    colnames(prices)=colnames(signal)= mdata$symbolnames
  }
  else
    mdata = clone(data)
  
  

  
  
  mP("sys.Run: %s",viewLevel) ; #browser()
  if (contains(viewLevel,"portfolio"))
    mP("----------------########################### Portfolio-Analyse:")
  #browser()
  if (n > 1 )#&& experiment=="")
    if (compare || contains(viewLevel,"portfolio")) #vergleich  mit der BuyHold - strategie gew�nscht  (compare==visual)
    {
      new_Win(1)
      models=list()
      ############# Das Buy-Hold-Vergleichsmodell
      #browser(mP("bh"))   
      #patch  /n
      mdata$weight=prices
      mdata$weight[]=1
      mdata$execution.price=prices;mdata$execution.price[]=NA
      
      offset.D=DateS(first(signal[signal[,1] !=0,1]))
      offset.frame=sprintf("::%s",offset.D)  #stell den offset wieder auf NA 
      mdata$weight[offset.frame,] <- 0
      mdata$weight[1:n.vol,] <- 0
      
      capital = 100000
      mdata$weight[] = ((capital/ n)  /   prices) * bt.exrem(mdata$weight)      
      mdata$execution.price=prices; mdata$execution.price[]=NA
      mP("sys.Run: -----Buy and Hold ----")
      #browser(mP("#32"))
      models$buyHold = bt.run(mdata, type='share', capital=capital, trade.summary=T,commission=commission$percentage)#global_commission)
      
      mod=models$buyHold 
      mod$trade.summary$trades 
      
      #################  DAX
      bench=mdata$BENCH
      mdata$weight=prices
      mdata$weight[]=NA
      mdata$weight[,bench]=1
      head(mdata$weight)
      offset.D=DateS(first(signal[signal[,1] !=0,1]))
      offset.frame=sprintf("::%s",offset.D)  #stell den offset wieder auf NA 
      mdata$weight[offset.frame,] <- 0
      capital = 100000
      mdata$weight[] = ((capital/ 1)  /   prices) * bt.exrem(mdata$weight)      
      mdata$execution.price=prices; mdata$execution.price[]=NA
      mP("sys.Run: -----BENCH ----")
      
      models[[bench]] = bt.run(mdata, type='share', capital=capital, trade.summary=T,commission=commission$percentage)
      
      mod=models[[bench]] 
      mod$trade.summary$trades 
      
      ##################### TF timing - general full allocated  - NO select
      mdata$weight=prices;    mdata$weight[]=1
      mdata$execution.price=prices;mdata$execution.price[]=NA
      
      position.score = bt.apply.matrix(prices*signal, function(pS) iif(!is.na(pS) & pS > 0 , 1 ,NA))
      universe = capital*ntop.keep(position.score[period.ends,],10000, 10000) / prices[period.ends,]
      obj = portfolio.allocation.helper(prices, 
                                        periodicity = period,
                                        period.ends=period.ends,
                                        lookback.len = n.vol, 
                                        universe=universe,
                                        shrinkage.fns = "ledoit.wolf.shrinkage",
                                        min.risk.fns  = list(EW.full=equal.weight.portfolio))
      
      #models=list()
      mP("sys.Run: -----timing - full allocated ----")
      browser()
      #lies noch mal im commission-paper nach
      
      models$Tfill = create.strategies(obj, mdata,commission=commission$percentage,trade.summary=T)$models[[1]]
      # ls(models$TF)
      #  models[[1]]
      #  names(models)
      #strategy.performance.snapshoot(models, one.page=T,title="Timing 100 allocated")
      mP("Timing 100pct allocated ")
      
      if (experiment!="")
      {
        
        ##################### TF1 timing - full single allocated  just on max.sharpe Title- NO select
        if (len(S.arg$rankfn)>0) #.........zu hoher turnover............................................
        { #hier weiter
          rank=  get.cashed.rank("rank.sharpe")#*signal[]

          maxSharpeSym="MDAX"
          
          #signal maskiert die preise aus, die gerade zu long systemen geh�ren
          #rank=bt.apply.matrix(prices,function(p) {p-SMA(p,200)})
          
          
          #welcher titel hat an welchem tag das beste ranking ?
          rank.max=(unlist(apply(rank,1,FUN=function(r) names(which(r==max(r))[1]))))
          rank.max.sym=xts(rank.max,order.by=as.Date(names(rank.max)))
          ############  
          mdata$weight = prices; mdata$weight[]=NA
          mdata$weight[]=signal
          mdata$weight[] = (1/n)*signal#*bt.exrem(signal)  
          
          head(mdata$weight)
          head(rank.max.sym)
          #fill up- mit dem jeweils besten symbol
          no=sapply(as.Date(index(rank.max.sym)),FUN=function(date)
          {
            maxSharpeSym=coredata(rank.max.sym[date])
            #  mP("%s %s %f %f",date, maxSharpeSym,mdata$weight[date,maxSharpeSym],rowSums(mdata$weight[date,]))
            #das symbol mit der besten maxSharpeSym kriegt das ganze Gewicht das bis 1 noch fehlt
            mdata$weight[date,maxSharpeSym] = 1+mdata$weight[date,maxSharpeSym] -rowSums(mdata$weight[date,],na.rm=T)
          })
          rowSums(mdata$weight,na.rm=T)
          
          #  mdata$weight[] =mdata$weight[]* bt.exrem(signal) #exrem entfernt zeitlich aufeinanderfolgende identische signale
          
          models$TfillSharpe = bt.run(mdata, type='weight', capital=capital, trade.summary=T,commission=commission)
          
          mP("sys.Run: -----timing - single full allocated ----")
        #  strategy.performance.snapshoot(models, one.page=F,title="Timing 100 single allocated", data=mdata)
         # mP("Timing 100pct single allocated - pressKey"))
        }
        ##############################TS(sharpe)######################
        
        mdata$weight=prices;    mdata$weight[]=1
        mdata$execution.price=prices;mdata$execution.price[]=NA
        position.score = bt.apply.matrix(prices*signal, function(pS) iif(!is.na(pS) & pS > 0 , sharpe ,NA))
        universe = capital*ntop.keep(position.score[period.ends,],n.top, k.top) / prices[period.ends,]
        obj = portfolio.allocation.helper(prices, 
                                          periodicity = period,
                                          period.ends=period.ends,
                                          lookback.len = n.vol, 
                                          universe=universe,
                                          shrinkage.fns = "ledoit.wolf.shrinkage",
                                          min.risk.fns  = list(TS=equal.weight.portfolio))
        
        #models=list()
        mP("sys.Run: -----TS(sharpe)----")
        models$TS = create.strategies(obj, mdata,commission=commission$percentage,trade.summary=T)$models[[1]]
        
        mod=models$sharpe
        mod$trade.summary$trades 
        mod$trade.summary$stats 
      } #experiment != ""
      
      #strategy.performance.snapshoot(models, one.page=F,title="Timing 100 single allocated", data=mdata)
      #browser(mP("TS(sharpe)A - pressKey"))
      
      ###########################################################
      
      # 
      #  writeModelDataXls(models,xlsName=sprintf("Models/%s/Results.xls/%s.xls",dataSet,"X2"))    
    }  
  #if (contains(viewLevel,"portfolio"))  #<<###################
  #   browser(mP("TEST")) 
  ############################################  das reine Timing -modell #######################################################
  #das Modell f�r signal
  mdata$weight = prices; mdata$weight[]=NA
  mdata$weight[]=signal
  
  mdata$weight[] = ((capital/n) / prices) * bt.exrem(signal) #exrem entfernt zeitlich aufeinanderfolgende identische signale
  mdata$execution.price=prices;mdata$execution.price[]=NA
  #N=prices[,1];  N[]=rowSums(abs(signal)) #wie viele Titel sind wann investiert
  mP("sys.Run:   -----model-%s ---  commission: %f",signal.fun,commission)  ######### der Aufruf f�r das Timing-System
  #browser(mP("#334"))
  models[[signal.fun]] = bt.run(mdata, type='share', capital=capital, trade.summary=T,commission=commission$percentage)
  
  mod=models[[signal.fun]]
  mod$trade.summary$trades 
  mod$trade.summary$stats 
  
  
  if (contains(viewLevel,"portfolio"))
  {
    
    #browser(mP("######### %d",len(models)))
    #browser(mP("################# TEST"))
    data$symbolnames
    #models = append(models,models$TF )
    barplot.with.labels(sapply(models, compute.turnover, data), 'Average Annual Portfolio Turnover')
    tryM( strategy.performance.snapshoot(models,one.page= F,title="just Timing + BuyHold + BENCH",data=data)    )
    
    browser(mP("just timing - compared with bench and buy and hold - EW, pressKey"))
  }
  ####################################################################################
  ####################################################################################
  
  if (contains(viewLevel, "portfolio") && experiment!="")
  {
    #safe="DAX"
    if (safe !="")
    {
      mP("all unused money to %s",safe)
      #++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      #immer alles Geld investieren ### falls einige flat sind, wird deren geld gleichm��ig verteilt
      mdata$weight = prices; mdata$weight[]=NA
      mdata$weight[]=signal
      
      #mdata$weight[] = ((capital/n) / prices) * bt.exrem(mdata$weight) #exrem entfernt zeitlich 
      #N=prices[,1];  N[]=n-rowSums(abs(signal))+1 #wie viele Titel sind wann nicht investiert
      mdata$weight[,safe] = 1 + mdata$weight[,safe] - rowSums(mdata$weight)
      #mdata$weight[] = ((capital/n) / prices) * bt.exrem(mdata$weight) #exrem entfernt zeitlich 
      
      mdata$execution.price=prices;mdata$execution.price[]=NA
      
      models$XtoSafe = bt.run(mdata, type='weight', capital=capital, trade.summary=T,commission=commission$percentage)
    }
    #sr
    #+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    if (experiment != "")
    {
      mP("all assetallocs") #aal
      browser()
      #################################################################################################
      cluster.group = cluster.group.kmeans.90
      
      min.risk.fns = list(
        EW=equal.weight.portfolio,
        #    RP=risk.parity.portfolio,
        #MV.tim=min.var.portfolio,
        MVE=min.var.excel.portfolio,
        # target retunr / risk
        TRET.12 = target.return.portfolio(12/100),    						
        TRISK.10 = target.risk.portfolio(10/100),
        #    MD=max.div.portfolio,
        #    MC=min.corr.portfolio,
        #    MC1=min.cdar.portfolio,
        #    MC2=min.mad.downside.portfolio,
        #MO=max.omega.portfolio,  #l�uft nicht, geht wohl nur mit Rdonlp2
        #MR=min.risk.portfolio,  #mittelm�ig . wie MV
        #ML=min.maxloss.portfolio,  schlecht
        #MR=min.risk.downside.portfolio,  #genau wie MV
        #MP=max.geometric.return.portfolio,  #l�uft nicht
        
        # MC2=min.corr2.portfolio,  #schrott
        # MCE=min.corr.excel.portfolio,    #schrott
        # cluster
        C.EW = distribute.weights(equal.weight.portfolio, cluster.group),
        C.RP = distribute.weights(risk.parity.portfolio, cluster.group),
        
        MS=max.sharpe.portfolio())
      
      names.min.risk.fns=names( min.risk.fns)
      
      ############################## timing.select.allocate
      mP("nTopK %d ( timing*faber-ranking )  & Allocation",n.top)
      
      #universe[] = ((capital/ n)  /   prices) 
      #nur f�r long-only-modelle:  prices*signal maskiert alle technisch ausgestoppten
      #systeme weg - das ntop-ranking geht danach dann �ber pS-SMA(200)
      ranking <-function(p){p-SMA(p,200)} 
      
      #alternatives ranking:
      #Cagr*Sharpe/abs(maxDD)
      
      position.score = bt.apply.matrix(prices*signal, function(pS) iif(!is.na(pS) & pS > 0 , ranking(pS) ,NA))
      #position.score = bt.apply.matrix(prices*signal, function(pS) iif( pS > 0 , pS-SMA(pS,200) ,NA))
      
      universe = capital*ntop.keep(position.score[period.ends,],n.top, k.top) / prices[period.ends,]
      
      dim(signal)
      dim(universe)
      dim(prices)
      dim(ntop.keep(position.score[period.ends,],n.top, k.top) )
      dim(prices[period.ends,])
      
      names(min.risk.fns)=sapply(names.min.risk.fns, function(x)sprintf("%s.TSA",x))
      
      obj = portfolio.allocation.helper(prices, 
                                        periodicity = period,
                                        period.ends=period.ends,
                                        lookback.len = n.vol, 
                                        universe=universe,
                                        shrinkage.fns = "ledoit.wolf.shrinkage",
                                        min.risk.fns =min.risk.fns 
      ) 
      
      #Cagr*Sharpe/abs(maxDD)
      
      models.TSA = create.strategies(obj, mdata,commission=commission$percentage,trade.summary=T)$models
          
      strategy.performance.snapshoot(append(list (BENCH=models[[bench]]),models.TSA), one.page=F,title="Timing.Selection.Allocation", data=mdata)
      browser(mP("Timing.Selection.Allocation - pressKey"))
      models$buyHold=NULL
      
      #obj = bt.shrinkage.best.sharpe('S,SA,A', 252, obj, data)
      #models = create.strategies(obj, data, dates = dates, leverage = leverage)$models
      #  list(title = title, stats = bt.summary.report(models, title, data, obj,
      #control = list(plot.weight.transition.maps = F,  plot.risk.contribution.transition.maps = F)   ) )
      
      #####################
      #auch die neuen shrinkage- ausprobieren 
      if (F)  #scheint nicht viel auszumachen !!
      {
        #http://www.systematicportfolio.com/adaptive-shrinkage
        #source("MLib/bt.adaptive.shrinkage.R")
        
        mP("source MLib/bt.adaptive.shrinkage.R")    
        S_SA_A=function(h,a) 1/3*(shrink.average.david(1)(h,a)+ sample.shrinkage(h,a) + sample.anchored.shrinkage(h,a))
        
        obj = portfolio.allocation.helper(prices, 
                                          periodicity = period,
                                          period.ends=period.ends,
                                          lookback.len = n.vol, 
                                          universe=universe,
                                          shrinkage.fns = "S_SA_A",
                                          min.risk.fns =min.risk.fns
        ) 
        
        asm_models_S = create.strategies(obj, mdata,commission=commission$percentage)$models
        strategy.performance.snapshoot(asm_models_S, one.page=T)
        browser(mP("with new shrinkage - pressKey"))
      }
      
      ##################### NOtiming.select.allocate
      
      browser(mP("#33"))
      position.score = bt.apply.matrix(prices, function(pS) iif(!is.na(pS) & pS > 0 , ranking(pS) ,NA))
      universe = capital*ntop.keep(position.score[period.ends,],n.top, k.top) / prices[period.ends,]
      
      names(min.risk.fns)=sapply(names.min.risk.fns, function(x)sprintf("%s.SA",x))
      
      obj = portfolio.allocation.helper(prices, 
                                        periodicity = period,
                                        period.ends=period.ends,
                                        lookback.len = n.vol, 
                                        universe=universe,
                                        shrinkage.fns = "ledoit.wolf.shrinkage",
                                        min.risk.fns =min.risk.fns 
      ) 
      
      
      models.SA=asm_models.nonTiming = create.strategies(obj, mdata,commission=commission$percentage,trade.summary=T)$models
      #pdf(file = 'report.pdf', width=8.5, height=11)
      strategy.performance.snapshoot(append(list (BENCH=models[[bench]]),models.SA), one.page=F, title="NOTiming.Selection.Allocation", data=mdata)
      #dev.off()
      browser(mP("NOtiming.Selection.Allocation - pressKey"))
      
      
      #####################NOtiming.NOselect.allocate
      #universe[]=1
      universe[] = ((capital/ n)  /   prices)
      names(min.risk.fns)=sapply(names.min.risk.fns, function(x)sprintf("%s.A",x))
     # browser(mP("Bug ##############>"))
      
      obj = portfolio.allocation.helper(prices, 
                                        periodicity = period,
                                        period.ends=period.ends,
                                        lookback.len = n.vol, 
                                        universe=universe,
                                        shrinkage.fns = "ledoit.wolf.shrinkage",
                                        min.risk.fns =min.risk.fns 
      ) 
      
      
      models.A = create.strategies(obj, mdata,commission=commission$percentage,trade.summary=T)$models
      #pdf(file = 'report.pdf', width=8.5, height=11)
      
      strategy.performance.snapshoot(append(list (BENCH=models[[bench]]),models.A), one.page=F, title="NOTiming.NOSelection.just Allocation", data=mdata)
      
      #dev.off()
      browser(mP("NOtiming.NOSelection.Allocation:  just allocation - pressKey"))
      
      #models = append(asm_models,models)
      
      #strategy.performance.snapshoot(models, one.page=T)
      #browser(mP("all together - pressKey"))
      
      
      
      ###################################################################
      if (F)
      {
        cluster.group = cluster.group.kmeans.90
        
        universe=prices
        universe[]=1  #alle einschalten
        universe[] = ((capital/ n)  /   prices) #* bt.exrem(universe)
        
        
        
        min.risk.fns = list(
          EW.nTopk=equal.weight.portfolio,
          RP=risk.parity.portfolio,
          MD=max.div.portfolio,                      
          
          MV=min.var.portfolio,
          MVE=min.var.excel.portfolio,
          MV2=min.var2.portfolio,
          
          MC=min.corr.portfolio,
          MCE=min.corr.excel.portfolio,
          MC2=min.corr2.portfolio,
          
          MS=max.sharpe.portfolio(),
          ERC = equal.risk.contribution.portfolio,
          
          # target retunr / risk
          TRET.12 = target.return.portfolio(12/100),                             
          TRISK.10 = target.risk.portfolio(10/100),
          
          # cluster
          C.EW = distribute.weights(equal.weight.portfolio, cluster.group),
          C.RP = distribute.weights(risk.parity.portfolio, cluster.group),
          
          # rso
          RSO.RP.5 = rso.portfolio(risk.parity.portfolio, 5, 500),
          
          # others
          MMaxLoss = min.maxloss.portfolio,
          MMad = min.mad.portfolio,
          MCVaR = min.cvar.portfolio,
          MCDaR = min.cdar.portfolio,
          MMadDown = min.mad.downside.portfolio,
          MRiskDown = min.risk.downside.portfolio,
          MCorCov = min.cor.insteadof.cov.portfolio
        )
        
        obj = portfolio.allocation.helper(prices, 
                                          periodicity = period,
                                          period.ends=period.ends,
                                          lookback.len = n.vol, 
                                          universe=universe,
                                          shrinkage.fns = "ledoit.wolf.shrinkage",
                                          min.risk.fns =min.risk.fns 
        ) 
        asm_models.nonTiming = create.strategies(obj, mdata,commission=commission$percentage)$models
        #models = append(models,asm_models.nonTiming)
        pdf(file = 'report.pdf', width=8.5, height=11)
        
        strategy.performance.snapshoot(asm_models.nonTiming, one.page=T)
        dev.off()
        
        browser(mP("pressKey"))
        
        #    tryM(strategy.performance.snapshoot(asm_models, T))
        #    tryM(plotbt.custom.report.part1(asm_models)  )
      }
    }
  }
  #----------------------------------------------------------------------------------------
  
  
  if (stopSys !="")  #die gehen gar nicht gut -----------------------------------------
{
  mdata$weight[] = NA
  if (stopSys == "trailing.stop")
    mdata$weight[] = custom.stop.fn(coredata(signal), coredata(prices), trailing.stop,  pstop = 0.01)
  if (stopSys=="trailing.stop.profit.target")
    mdata$weight[] = custom.stop.fn(coredata(signal), coredata(prices), trailing.stop.profit.target,   pstop = 1/100, pprofit = 1.5/100)
  
  models$ma.cross.trailing.stop = bt.run.share(mdata, clean.signal=T, trade.summary = TRUE)
}#-------------------------------------------------------------------------------------
  
  #tryM(plotbt.custom.report.part1(models)  ) 
  
  #tail(signal)
  #mchart(mNorm(mdata$prices["2012"]))
  #EQ<<-data.frame(models[[signal.fun]]$equity)
  #plot(models[[signal.fun]]$equity)
  #plotbt.custom.report.part1(models[[signal.fun]])
  #strategy.performance.snapshoot(models,F)
  #browser(mP("Compare"))
  if (compare )  #hier wird compare als synonym zu "visual" benutzt ...
  {
    norm_Win(1)
    #plotbt.custom.report.part1(models)
    #strategy.performance.snapshoot(models, one.page=T)
    #meine einzel-asset-model-charts
    if (contains(viewLevel, "timingsys")  )#|| len(mdata$symbolnames) ==1 )
    {
      mP("sys.Run:  plot each single Sym: ")
      #browser()
      
      #welche Spalten der hilfs.Indi geh�ren zum Wertpapier sym ?:
      if (len(mdata$symbolnames)==1)
      {
        sym=mdata$symbolnames[1]
        hilfs.sym = c()
        for(sy in colnames(hilfs.Indi[[1]]))
        {
          if (len(strfind(sy,sym))>0)
            hilfs.sym=c(hilfs.sym,sy)    
        }   
      }
      else 
        hilfs.sym=NULL
      
      #browser()
      #einzel-wp-charts ausdrucken ... 
      for (sym in mdata$symbolnames)
        if (is.null(hilfs.sym))
          tryM(plotSigPrice(signal=signal[,sym],prices=prices[,sym],
                            indi=hilfs.Indi[[1]],main=main)  )  #uneingeschr�nkt
      else
        tryM(plotSigPrice(signal=signal[,sym],prices=prices[,sym],
                          indi=hilfs.Indi[[1]][,hilfs.sym],main=main)  )
    }
    #.......................................................
    
    #browser()
    
    #tryM(strategy.performance.snapshoot(models$buyHold))
    #if (len(mdata$symbolnames)>1)
  }
  
  if (contains(viewLevel, "portfolio") )  ################################################################################
{
  #*****************************************************************
  # Create Report
  #******************************************************************    
  mP("Start experiment Reporting %s ######>",experiment)
  browser()
  #  model$trade.summary
  #kurzreport
  #tryM(plotbt.custom.report.part1(models)  )   
  #models$DAX=NULL
  #tryM(strategy.performance.snapshoot(models, F))
  #ls(models)
  tryM(plotbt.custom.report.part2(models[[signal.fun]],main=signal.fun )  ) 
  
  
  #strategy.performance.snapshoot(models.SA, one.page=F,data=data)
  
  #Lang-Report und schreiben von pdf und xls
  if (experiment !="")
  {
    all.models = append(models,models.TSA)
    all.models= append(all.models, models.SA)
    all.models= append(all.models,models.A)
    
    #compareViewModels(models=append(models.SA,models),prices,alloc=T)
    pdf_Report(models=all.models,experiment,data)
    
    # Plot Portfolio Turnover for each strategy
    if (F)
    {
      layout(1)
      barplot.with.labels(sapply(models, compute.turnover, data), 'Average Annual Portfolio Turnover')
      
      pdf_Report(experiment)
      dev.off()
    }
  }
}
  
  ret = mROC( models[[signal.fun]]$equity)
  eq = models[[signal.fun]]$equity 
  #as.double( as.double(last(eq,1))^(1/compute.nyears(eq)) - 1 )
  cgar=compute.cagr(eq)*100
  calmar = abs(compute.calmar(eq))*sign(cgar);
  
  if (len(mdata$symbolnames)>1)
  {
    mP("  ---- MultiAsset-Results---of %d series on  %d days, commission = %f",dim(eq)[1],dim(eq)[2],global_commission)
    nt=try(as.numeric(numTrades(signal)$allT))
    if (len(nt)==0 || nt==0)
      nt = 1
    mP("%d Trades #",nt)
    mP ("Haltedauer %f Tage", (n*len(ret[,1])) / nt)
    mP("sharpe: %f",compute.sharpe(ret))
    
    mP("Cgar %f",compute.cagr(eq)*100)
    mP("MaxDD %f",compute.max.drawdown(eq)*100)
    mP("calmar %f",calmar)
  }
  
  if (is.na(calmar))
  {
    mP("WARING:  Tquality is NA")
    models[[signal.fun]]$Tquality =-1000
  }
  else
    models[[signal.fun]]$Tquality =calmar   #Qualtit�tskriteriumg f�r den Optimierer  (der sucht minima)
  models[[signal.fun]]$Signal=signal
  mP("------------------------------------>>>Tquality= %f",models[[signal.fun]]$Tquality)
  return(models[[signal.fun]])
  
  
}
#sys.Run<-cmpfun(sys.Run_) #compilier die Funktion
#################################################################################
##################################################################################

mP("########### load sysRun.R")

