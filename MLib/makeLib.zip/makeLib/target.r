###############################################################################################
#allgemeine ASM-Methoden die zu fachspezifisch sind, als dass sie nach InputConfig geh�ren
###############################################################################################

if (F)  
  data$Target   <- compute.Target.by.method(data=data, TargetMethod=1)

ls(data)

#######################################################################################

##########################################################################
#methode 1

###########################################################################
###suche nun Werte f�r maxDDtoleranz , minReturn die die
#quality maximieren

sys.Target<-function(arg,visual=F)
{
  
  maxDDtoleranz=arg[1]
  minReturn=arg[2]
  
  runNr__<<-runNr__+1
  print(runNr__)
  Today ="2012-05-01"
  price=xtsPrice["2012::"]
  
  PeakPos__<<-0;lastPos__<<-0;eqPos__<<-0
  oaw <<-lapply(as.Date(index(price)),function(x)  targetByDD( Today=x, price=price, maxDDtoleranz = maxDDtoleranz, minReturn = minReturn))
  lasti = len(oaw)-1
  quality = oaw[[lasti]]$eqPos  #suche nun Werte f�r maxDDtoleranz , minReturn die die
  
  if (!visual)
    return(quality)
  #quality maximieren
  #coredata(targetXts) = as.numeric(targetXts[])
  #die Listen von liste -> data.table
  OAW = rbindlist(oaw) #data.table aus liste von listen ...
  #den data.table ->xts
  targetXts=as.xts(OAW, order.by = as.Date(OAW$Date))[,-1]; 
  
  block=merge(price,targetXts)
  block = block[-dim(block)[1]]  #letzte Zeile entfernen weil nicht gerechnet
  block[is.na(block)]=0
  
  plota(block[,7],main="SumSinglePosEq")
  col =iif(block[,"ContinuePos"]==1,"red",  iif(block[,"ContinuePos"]== -1,"blue","gray"))
  plota.lines(block[,7], type='l', col=col,lwd=2)               
  
  
}

if (F)
{
  
  lev=list(seq(0.01,0.9,0.05),  seq(0.06,0.59,0.05))
  lev=list( seq(0.01,0.9,0.05), 0.05)#maxDDtoleranz = 0.1, minReturn = 0.05))
  
  
  runs = len(combine2(seq(0.01,0.19,0.05),  seq(0.01,0.19,0.05),sep="|"))
  mP("Expect time for %d runs ",runs)
  runNr__=0  
  ores <<- gridSearch(sys.Target, levels=lev)  ##### der zeitaufw�ndige optimierungslauf
  #ores1=ores
  ovalues<<-ores$values[is.finite(ores$values)]
  plot(ovalues)
  
  
  besti=which.max(ovalues)
  best=ores$values[besti]
  mP("BestVal %f",best)
  print(ores$levels[besti])
  
  sys.Target(unlist(ores$levels[besti]),T)
  
  
  #~~~~~~~~~~~~~~~~~~~~~~~~ Auswertung
  #die Listen von liste -> data.table
  OAW = rbindlist(oaw) #data.table aus liste von listen ...
  #den data.table ->xts
  targetXts=as.xts(OAW, order.by = as.Date(OAW$Date))[,-1]; 
  #head(targetXts)
  #targetXts[] = as.numeric(coredata(targetXts))
  #coredata(targetXts) = as.numeric(targetXts[])
  block=merge(price,targetXts)
  block = block[-dim(block)[1]]  #letzte Zeile entfernen weil nicht gerechnet
  block[is.na(block)]=0
  
  plota(block[,7],main="SumSinglePosEq")
  col =iif(block[,"ContinuePos"]==1,"red",  iif(block[,"ContinuePos"]== -1,"blue","gray"))
  plota.lines(block[,7], type='l', col=col,lwd=2)               
  
}

############### so kann man das Target gut aufrufen
#f�r ein singel-Spalten xts
########################
compute.Target<-function(price,  maxDDtoleranz=0.16, minReturn=0.05)
{
  sym=toString(colnames(price))
  mP("compute.Target of %s ",sym)
  #if (sym=="USDEUR")
  #    browser()
  
  PeakPos__<<-0;lastPos__<<-0;eqPos__<<-0
  oaw <<-lapply(as.Date(index(price)),function(x)  targetByDD( Today=x, price=price, maxDDtoleranz = maxDDtoleranz, minReturn = minReturn))
  lasti = len(oaw)-1
  quality = oaw[[lasti]]$eqPos  #suche nun Werte f�r maxDDtoleranz , minReturn die die
  
  #quality maximieren
  #coredata(targetXts) = as.numeric(targetXts[])
  #die Listen von liste -> data.table
  OAW = rbindlist(oaw) #data.table aus liste von listen ...
  #den data.table ->xts
  targetXts=as.xts(OAW, order.by = as.Date(OAW$Date))[,-1]; 
  
  block=merge(price,targetXts)
  block[dim(block)[1]] = last(price) 
  #block = block[-dim(block)[1]]  #letzte Zeile entfernen weil nicht gerechnet
  block[is.na(block)]=0
  return (block)  
}
############### so kann man das Target gut aufrufen
#f�r ein multi-Spalten xts,  z.b  data$prices
########################
compute.Targets<-function(prices, maxDDtoleranz=0.16, minReturn=0.05)
{  
  global_T  <<-NULL
  browser(mP("xxxxxx"))
  #compute.Target() gibt immer eine ganze Liste von Vektoren raus             
  T__<<-lapply(colnames(prices),FUN=function(x)
  {PeakPos__<<-0;lastPos__<<-0;eqPos__<<-0;
   priceCol=prices[,x]; 
   cp = try(compute.Target(priceCol,maxDDtoleranz,minReturn))
   if (!is.null(cp) && len(cp$ContinuePos)>0)
     if (is.null(global_T ))
       global_T =cp$ContinuePos
   else
     global_T <<- merge(global_T , cp$ContinuePos)
  })
  mP("... now build global_Targets ...")
  names(T__) = colnames(prices)       
  #nimm von dieser Vektorenliste nur den Slot:  ContinuePos            
  TcontinuePos=lapply(colnames(prices),FUN=function(x){T__[[x]]$ContinuePos})
  names(TcontinuePos) = colnames(prices)             
  #bau aus der Liste von Zeitreihen eine einzige Zeitreihe
  OAW=data.frame(TcontinuePos)
  targetXts=as.xts(OAW, order.by = as.Date(rownames(OAW))); 
  colnames(targetXts) = colnames(prices)             
  return(targetXts)
}

if (F)
{  
  compute.Target(price,0.16,0.05)
  global_Targets <<-compute.Targets(price,0.06,0.005)
  plot(price)
  lines(price,col=(global_Targets+3),type="h")
  prices=na.omit(data$prices)
  
  prices = mNorm(data$prices[,c("USDCHF","USDGBP")])
  purePlot(prices)
  global_Targets <<-compute.Targets(prices,0.16,0.05)
  
  plot(prices[,1])
  lines(prices[,1],col=(global_Targets[,1]+3),type="h")
  
}


##########################################################################
#methode 2
##########################################################################


###############################################################################
#Zeige an, ob er an einem Tag long gehen w�rde, wenn er einen maxDD akzeptiert und 
#bis dahin wenigstens minEQ verdient haben will.

#Jeder Tag wird (unabh�ngig von einer evtl. schon eingenommenen marketpos) entschieden #Ob in den Folgekursen ein minEQ vor ein stop bei maxDD erziehlt werden kann
#das kann zu super - short-term-positions f�hren (weil die posl�nge keine rolle spielt)
#Wichtig:  der signal=1- Bereich zeigt keinesweg die Dauer einer Sollposition !!!!

################################################################################
roll.Target_<-function(old_prices, Prices,   maxDD=10,minEQ=10)
{
  sym=colnames(old_prices)
  Prices=Prices[,sym]
  lastDay = DateS(last(old_prices))
  #if (lastDay=="2010-05-05")
  #  browser()
  lastDayPrice=nval(Prices[lastDay])
  futPrices = Prices[sprintf("%s::",lastDay)]
  LongThresh = lastDayPrice-lastDayPrice/100*maxDD
  #browser()
  stopOutAt=futPrices[which(futPrices <  LongThresh)]
  toleratedPrices = futPrices[sprintf("::%s",DateS(first(stopOutAt)))]
  bestLongEQ= (max(toleratedPrices,na.rm=T)-lastDayPrice)/ lastDayPrice*100
  #browser()
  res=ifelse(bestLongEQ >= minEQ,1,0)
  if (res==1)
  { LongUntil = DateS(last(toleratedPrices))
    #if (res==1)
    mP("%s:  %s %f %d bis %s",sym,lastDay,lastDayPrice, res, LongUntil)
  }
  return(res)
}
roll.Target<-cmpfun(roll.Target_) #compilier das Teil


if (F)
{
  Dax = na.omit(Cl(data$DAX))["2007::"]
  mchart(Dax)
  roll.Target(Dax["2008-03-04"],Dax,maxDD=10,minEQ=10 )
  roll.Target(Dax["2008-03-05"],Dax,maxDD=10,minEQ=10 )
  
  Entry.signal=rollapplyr(Dax, 1, roll.Target, by.column = T,Prices=Dax, maxDD=10,minEQ=10)
  plotSigPrice(signal=Entry.signal,prices=mNorm(Dax),indi=NULL)
  View(targetPos["2008"])
  #eigentlich bekomm ich eine (pfadabh�ngige) Pos-Realisierung erst durch eine weitere Transformation des signals:  immer wenn ich long geh, bleib ich long bis zum Stop  (und erst dann schau ich nach einem neuen Entry.signal ... ) - dann wird aber der Trading-Verlauf sehr abh�ngig von der Wahl des analysierten PriceIntervalls (weil pfadabh�nig)
  ls(data)
  Dax=Cl(data$DAX)
  #bau ein data2  -env mit einem subset von symbols aus data:
  data2=new.env()
  data2$Dax=data$DAX
  data2$USDEUR=data$USDEUR
  data2$symbolnames=list("USDEUR","Dax")
  ls(data2)
  #Kristallkugel zur TargetDefinition
  Entry.signals=
    m.apply(data2,function(Dax) 
    {
      #      Dax=data2$Dax
      #    
      #browser()
      zLarge=ZigZag(na.omit(HLC(Dax)),change=10)
      
      Dax = na.omit(Cl(Dax))#["2007::"]
      plot(zLarge)
      lines(Dax,col="blue")
      deTrend=(Dax-zLarge)/Dax*100
      plot(deTrend)
      
      
      Entry.signal<<-rollapplyr(na.omit(Dax), 1, roll.Target, by.column = T,Prices=Dax, maxDD=10,minEQ=20)
      #browser()
      plotSigPrice(signal=Entry.signal,prices=mNorm(Dax),indi=NULL)
      mZ=mZigZag2(Dax=Dax,dd=50,F)
      #ein vektor mit datums-strings
      zpeak =unlist(lapply(mZ,function(x){ amark(x$peak,"green");DateS(x$peak) }))  
      #ein vector mit von-bis- datums-strings - intervalle
      frames<<- unlist(apply(cbind(c("no",zpeak),zpeak)[-c(1,len(zpeak)+1),],1,FUN=function(x){ sprintf("%s::%s",x[1],x[2])}))
      #iteriere �ber die Zeitintervalle in frames
      maxWinLen =1000
      
      #FeatureExtraktion:  
      allSegments=
        # sapply(frames,FUN=function(x)
        foreach(x = frames, .combine=rbind) %dopar%  #baue die segment-informationen zu einem dicken xts zusammen
{
  daxSegment = na.omit(Dax[x])
  firstD = index(first(daxSegment))
  lastD = DateS(last(daxSegment))
  lastD.brk = as.Date(lastD)+400# .. �ber die segment-grenze hinweg
  daxSegment = Dax[sprintf("%s::%s",DateS(first(daxSegment)),lastD.brk)]
  plot(daxSegment)
  amark(lastD,"green")
  print(x)
  #geh durch das ganze Segment - mach jedesmal eine lm vom Anfang des Segments
  #bis zum aktuellen Wert und berechen in y2 den letzten fit.lm-Wert
  #for (dx in c(1:len(daxSegment)))
  #browser()
  #gib pro Tag eine ganze Liste von Werten zur�ck 
  
  seg=lapply(c(1:len(daxSegment)), FUN=function(dx)
  {
    #im gleitenden Fenster von maxWinLen jeden Tag den fit.lm-Wert bei y2 berechen
    if (dx >=10)
    { 
      first.i=max(1,dx-maxWinLen)
      X=c(first.i:dx)
      Y=coredata(daxSegment[X])
      fit.lm=lm(Y~X)
      print(dx)
      y2=nval(last(fitted(fit.lm)))
      #browser()
      pred1<-predict(fit.lm,newdata=data.frame(X=c(dx)),interval="prediction",level=0.95)
      #mchart(pred1)
      #head(pred1)  # 3 spalen: (y,upper,lower)
      rsquare=summary(fit.lm)$r.square  #goodnes of fit; m�glichst gut hei�t nahe 1
      beta=nval(coef(fit.lm)[2])
      result=list(fit=y2,lwr=pred1[2],upr=pred1[3],rsquare=rsquare,beta=beta )
      # browser()
    }
    else
    {
      dax=nval(daxSegment[dx])
      result=list(fit=dax,lwr=dax,upr=dax,rsquare=0.5 ,beta=0)
    }
    return(result)
  })
  OAW = rbindlist(seg) ;  resSegment=as.xts(OAW, order.by = as.Date(index(daxSegment)))
  browser(mP("................"))
  mchart(resSegment);lines(daxSegment,col="blue")
  amark(lastD,"green")
  ####################################
  browser()
  features= buildFeatures(Dax,resSegment)
  
  
  
  #head(resSegment)
  #plot(resSegment[,"rsquare"])
  #mchart(resSegment[,"beta"])
  
  #lines(SMA(resSegment[,1],90),col="red")
  return(resSegment)
  # browser()        
}  
      browser() 
      mchart(allSegments)
      
      lines(Dax,col="blue")
      lines(ZigZag(na.omit(Dax),change=50),col="magenta")
      #berechne aus den Rohdaten Features () 
      
      
      #berchne die Target-Kategorien (Long,Flat)
      
      Entry.signal<<-rollapplyr(na.omit(Dax), 1, roll.Target, by.column = T,Prices=Dax, maxDD=10,minEQ=20)
      #browser()
      plotSigPrice(signal=Entry.signal,prices=mNorm(Dax),indi=NULL)
      #View(Entry.signal["2010"])
      return(Entry.signal)
    },newName="LongEntry")  #  <--- univariate-Feature-Map fertig
  
}
##########################################################################################
#geh in ein pos gem. signals und bleib so lang drin bist du augestoppt wirst
#signals sind Entry-signale aus roll.Target  .. diese werden diesmal bis zum maxDD durchgeritten, bevor ein neues Entry-Signal bemerkt wird.
##########################################################################################

eval.Target_<-function( Prices, signals,   maxDD=10, visual=F)
{
  pos=0
  temp=na.omit(merge(Cl(Prices),signals)); Prices=temp[,1]; signals=temp[,2]
  N=shape(Prices)
  res = Prices ; res[]=0
  DD=res
  wlen=10
  
  library(foreach)
  
  foreach(i=1:N, .combine="cbind") %do% {
    if (i > wlen)
    {
      if (pos==0)
      {
        today=i
        mPos = sum(signals[c((i-wlen):(i-1))])/wlen#mittlere pos
        print(mPos) 
        if(mPos > 0.2)
          pos=as.numeric(signals[i-1,1])
        
        #browser()
        if (pos != 0 )
        {
          entry.date = today
          entry.price=as.numeric(Prices[i])
        }
      }
      if (pos!=0)
      {
        dd =(entry.price-Prices[i-1])/entry.price*100
        stop.me= (nval(dd) < -abs(maxDD)) 
        #print(dd)
        #browser()
        #if(as.numeric(signals[i,1])==0)
        #  stop.me=T
        if (stop.me )
          pos=0
        DD[i]=dd
      }
      
      res[i]=pos
    }
  }
  if (visual)
    plotSigPrice(signal=res,prices=mNorm(Prices),indi=list(ts=res,dd=DD))
  
  return(res)
}

eval.Target<-cmpfun(eval.Target_) #compilier das Teil

if (F)
{
  plot(Dax)
  realised.signals= eval.Target(Prices=Dax,signals= Train.signal,maxDD=10)
  #realised.signals = Train.signal
}

###########################################################################
#die Sammel-Rufmethode zu Berechnung von Targets nach unterschiedlichen Ans�tzen
###########################################################################
compute.Target.by.method<-function(data, TargetMethod,glaettung=5,visual=T)
{
  #  browser()
  
  if (TargetMethod ==0)
  {
    res=foreach(sym=colnames(data$prices), .combine=cbind) %do%
{ 
  
  res=fast.smoothing(p=na.omit(data$prices[,sym]),visual=visual,glaettung=glaettung)$sig
  
}
    data$Target=res
    #showTargets(data$prices,res)
    res
    
  }
  if (TargetMethod ==1)
  {
    res=compute.Targets(na.omit(data$prices),0.16,0.05)
    
    showTargets(data$prices,res)
    res
    
  }
  if (TargetMethod ==2)
  {
    res=foreach(sym=colnames(data$prices), .combine=cbind) %do%
{ Entry.signal<-rollapplyr(na.omit(data$prices[ ,sym]), 1, roll.Target, by.column = T,Prices=data$prices[,sym], maxDD=10,minEQ=20) }
    
    showTargets(data$prices,res)
    res
  }
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  
  if (TargetMethod==3) #klassisch: daily-return als Target
  {
    res<-  foreach(sym=colnames(data$prices), .combine=cbind, .packages=c("quantmod")) %do%
{res=iif(lag(dailyReturn(data$prices[,sym], type='log'),-1)>=0,1,-1); colnames(res)=sym ;res}
    
    showTargets2(data$prices,res)  
    res
  }
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  
  if (TargetMethod==4) #klassisch: monthly-return als Target   GUTES MODELL - auch ohne lag(-1).
  {
    res  <-  foreach(sym=colnames(data$prices), .combine=cbind, .packages=c("quantmod")) %do%
{res=iif(lag(monthlyReturn(data$prices[,sym], type='log'),-1)>=0,1,0); colnames(res)=sym ;res}
    
    #monats-signale auf tagespositionen projezieren
    temp=data$prices;  temp[]=NA;     temp[index(res),]=res;    
    res=bt.apply.matrix(temp,ifna.prev)
    #keine short-postionen
    #res=bt.apply.matrix(res,function(x)iif(x < 0,0,x))
    showTargets2(data$prices,res)   
    res
  }
  #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  if (TargetMethod==5) #monthly ntop-Ranking
  {
    topn=5
    res<-  foreach(sym=colnames(data$prices), .combine=cbind) %do%
{ mr=lag(monthlyReturn(data$prices[,sym], type='log'),-1);
  #  mr[mr <0]<-0
}  #zuk�nftige Returns
    ## gib Top n Ranking  matrix
    # work with matrix
    temp = coredata(mret)
    dirMaxMin=T
    
    rank=foreach( i = 1:nrow(temp),.combine= rbind ) %do% {
      x = temp[i,]
      o = sort.list(x, na.last = TRUE, decreasing = dirMaxMin)
      index = which(!is.na(x))
      x[] = NA
      
      if(len(index)>0) {
        n = min(topn, len(index))
        x[o[1:n]] = 1
      }
      x
    }
    mrank=mret
    mrank[] = rank
    colnames(mrank)=colnames(data$prices)
    mrank[is.na(mrank)]<-0
    res = mrank
    
    #fillup: monthly->daily
    temp=data$prices;  temp[]=NA;     temp[index(res),]=res;    
    res=bt.apply.matrix(temp,ifna.prev)
    
    showTargets2(data$prices,res)
  }
  
  res
}
if (F)
  data$Target   <- compute.Target.by.method(data=data, TargetMethod=0)

###########################################################################

mP("########### load target.r")
#source("Mlib/Now.R")
